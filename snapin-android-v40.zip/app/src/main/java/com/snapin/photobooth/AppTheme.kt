package com.snapin.photobooth

import android.app.Activity
import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import androidx.core.view.WindowCompat

/** Tema aplikasi: "pink" (feminin) atau "elegant" (hitam putih, maskulin). Dipakai halaman web, kamera native, dan ikon peluncur. */
object AppTheme {
    private const val PREFS = "snapin_prefs"

    fun isElegant(ctx: Context): Boolean =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("theme", "pink") == "elegant"

    /** Warna status bar / navigation bar mengikuti tema. */
    fun applyBars(a: Activity) {
        val el = isElegant(a)
        val c = if (el) Color.parseColor("#F4F4F5") else Color.parseColor("#FFF7F1")
        a.window.statusBarColor = c
        a.window.navigationBarColor = c
        a.window.setBackgroundDrawable(ColorDrawable(c))
        val ctl = WindowCompat.getInsetsController(a.window, a.window.decorView)
        ctl.isAppearanceLightStatusBars = true
        ctl.isAppearanceLightNavigationBars = true
    }

    /** Simpan pilihan tema dan ganti ikon peluncur (alias Pink / Elegan). */
    fun set(a: Activity, name: String): Boolean {
        val el = name == "elegant"
        a.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString("theme", if (el) "elegant" else "pink").apply()
        a.runOnUiThread { applyBars(a) }
        return try {
            val pm = a.packageManager
            val pink = ComponentName(a.packageName, "com.snapin.photobooth.LauncherPink")
            val elegant = ComponentName(a.packageName, "com.snapin.photobooth.LauncherElegant")
            // aktifkan alias baru dulu, baru matikan yang lama
            pm.setComponentEnabledSetting(if (el) elegant else pink, PackageManager.COMPONENT_ENABLED_STATE_ENABLED, PackageManager.DONT_KILL_APP)
            pm.setComponentEnabledSetting(if (el) pink else elegant, PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP)
            true
        } catch (e: Throwable) {
            false
        }
    }
}
