package com.snapin.photobooth

import android.webkit.JavascriptInterface
import org.json.JSONObject

/**
 * Jembatan web -> kamera native. Di web dipanggil sebagai window.SnapinCamera.
 */
class NativeCameraBridge(
    private val onOpen: (String, Int, String, Int, Int) -> Unit,
    private val onPickGallery: () -> Unit
) {

    @JavascriptInterface
    fun isAvailable(): Boolean = true

    @JavascriptInterface
    fun open(json: String) {
        try {
            val o = JSONObject(json)
            val mode = o.optString("mode", "photo")
            val count = o.optInt("count", 4)
            val facing = o.optString("facing", "user")
            val w = o.optInt("w", 3)
            val h = o.optInt("h", 4)
            val orient = o.optString("orient", "auto")
            CameraSession.orient = if (orient == "portrait" || orient == "landscape") orient else "auto"
            onOpen(mode, count, facing, w, h)
        } catch (e: Exception) {
            // abaikan
        }
    }

    /** Buka pemilih foto galeri bawaan Android (Photo Picker), maksimal 6 foto. */
    @JavascriptInterface
    fun pickGallery() {
        onPickGallery()
    }

    @JavascriptInterface
    fun getPhoto(index: Int): String {
        return if (index >= 0 && index < CameraSession.photos.size) CameraSession.photos[index] else ""
    }
}
