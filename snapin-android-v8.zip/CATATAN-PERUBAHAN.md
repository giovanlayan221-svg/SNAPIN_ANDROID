# Snapin Android - catatan perubahan v2

## Yang diperbaiki
- **Hijau berbekas** pada bingkai berwarna polos: kunci warna baru (lihat README admin). Berlaku juga saat upload "Frame saya" di aplikasi.
- **Tombol back / keluar**: back HP sekarang mundur satu langkah di dalam aplikasi. "Ubah tata letak", "Frame saya", dan stiker
  tidak lagi melempar ke halaman utama; hasil dan stiker tetap ada. Keluar dari hasil yang belum disimpan meminta konfirmasi.
  Di beranda, back dua kali baru keluar aplikasi.
- **Gerakan stiker ala Canva**: 1 jari geser; 2 jari cubit = zoom + putar; pegangan kanan-bawah = ukuran saja; pegangan bulat bawah = putar saja
  (menempel di 0/90/180); pegangan kiri-atas = hapus.
- **Kamera tegak** dibuat selebar/setinggi mungkin (4:3 dan 16:9 terasa besar).

## Fitur baru
- **Rasio** per bingkai (admin). Bingkai hanya muncul bila jumlah foto DAN rasionya cocok.
- **Bingkai tersimpan offline di penyimpanan data** (IndexedDB), bukan cache browser. Sekali terunduh, tetap ada tanpa internet.
- **Stiker bawaan** berupa SVG (tanpa emoji) + tambah stiker dari galeri (tersimpan offline).
- **Bingkai & stiker pada video**: bingkai video (1 lubang, 16:9 tegak/landscape, termasuk animasi) tampil di pratinjau; saat simpan/bagikan video
  dirender ulang di HP (hasil .webm). **Fitur ini perlu dites di HP kamu**: bergantung MediaRecorder WebView, dan proses berjalan real-time sepanjang durasi video.
- **13 tema bingkai bawaan** dengan konsep berbeda: Bunny Pink, Yellow Buddy, Y2K Chrome, Sakura, Party Pop, Retro Film, Neon Night,
  Dreamy Cloud, Summer Ocean, Notebook, Cat Paws, Winter Snow (+ Polos).
- **Toko QRIS tanpa login**: beli bingkai/paket lewat QRIS di dalam aplikasi, atau masukkan kode redeem (ikon tag di My Assets).

## Belum / perlu dicek
- Build APK belum bisa dijalankan di sini: Kotlin diedit hati-hati tapi belum dikompilasi. Jalankan build lalu tes di HP.
- Video berbingkai diekspor sebagai .webm (bukan .mp4).

## v3 (revisi setelah dites di HP)
- **Dihapus**: Studio Bingkai (editor bebas) dan pilihan "Arah hasil" di Setup.
- **Galeri**: sekarang cukup pilih 1 sampai 6 foto, jumlah foto mengikuti yang dipilih (dulu harus pas sama jumlah foto, kalau kurang cuma muncul toast). Foto besar diproses lewat object URL supaya hemat memori.
- **Video kamera belakang gelap**: kecerahan preview dibaca otomatis; kalau terlalu gelap, kompensasi eksposur dinaikkan bertahap (mulai +1.0 EV untuk kamera belakang). Perlu dites di HP kamu.
- **Pratinjau video**: frame pertama ditampilkan walau belum diputar (sebelumnya bisa tampak hitam).
- **Teks "snapin photobooth"**: di semua bingkai bawaan dan bingkai server gratis tampil di pil putih memanjang di tengah bawah. Teks tema lain yang bentrok di area itu dihapus. Bingkai buatan sendiri (Frame saya) tidak diberi teks.
- **Bingkai berbayar**: pil putih berisi mahkota emas (bukan teks) pada hasil, dan lencana mahkota emas di daftar bingkai.

## v3.1
- **Halaman hasil tidak bisa digeser/diketuk**: lapisan stiker menutupi seluruh kanvas dan memblokir sentuhan. Sekarang lapisan itu tembus sentuhan; hanya stiker (dan pegangannya) yang menangkap sentuhan. Dites dengan geser sentuh sungguhan: sebelum perbaikan tidak bergeser, sesudahnya halaman bergeser normal.

## v3.2
- **Galeri**: tombol "Galeri" sekarang memakai pemilih foto bawaan Android (Photo Picker, bisa pilih 1 sampai 6 foto). Foto diperkecil (maks 1800 px), diluruskan sesuai EXIF, dan HEIC dikonversi ke JPEG di sisi native, jadi tidak lagi bergantung pada pemilih file WebView. Di browser tetap memakai input file biasa.
- **Tombol rekam video**: digambar ulang per status. Saat merekam isinya jadi kotak merah kecil membulat di tengah cincin (dulu terlalu besar karena ukuran lapisan tidak dihitung ulang), dengan denyut halus. Ruang di bawah pratinjau ditambah supaya tombol tidak mepet.

## v2.2 (versionCode 12)
Versi aplikasi dinaikkan dan tertulis kecil di bagian bawah Beranda ("Snapin v2.2"). Kalau tulisan itu tidak muncul setelah update, berarti APK yang terpasang masih build lama.

## v2.3 (versionCode 13)
Pemilih galeri native diberi toast ("Memproses n foto...", pesan error) dan cadangan ke pemilih file web kalau pemilih bawaan gagal dibuka.

## v2.4 (versionCode 14)
- **Bingkai muncul di semua HP**: alamat server (https://snapin-server.vercel.app) sudah tertanam di APK lewat `DEFAULT_API_BASE`, jadi semua HP otomatis memuat bingkai.
- **Tahan sinyal lemah**: daftar bingkai dan gambar bingkai punya batas waktu dan diulang otomatis (juga saat sinyal kembali atau aplikasi dibuka lagi). Memilih bingkai yang belum terunduh akan menunggu unduhan selesai, tidak lagi memakai bingkai setengah jalan. Aplikasi tidak lagi tertahan saat start karena menunggu server.
- **Pindah foto** di halaman hasil: ketuk foto pertama lalu foto kedua untuk bertukar posisi (tombol "Pindah foto", muncul bila foto 2 atau lebih).
- **My Assets (Frame saya & Stiker saya)**: upload sekarang memakai pemilih foto bawaan Android, PNG/WebP transparan tetap utuh, bisa pilih beberapa sekaligus.
- **Wajah tidak lagi hijau**: bagian dalam lubang foto dijamin transparan 100%. Bingkai lama yang lubangnya masih berwarna polos dibersihkan otomatis saat diunduh ke HP (tidak perlu upload ulang).
- Versi tertulis "Snapin v2.4" di Beranda (versionCode 15).
- **Tata letak 2 foto**: setelah 2 foto diambil, muncul pilihan Strip (atas-bawah, seperti sebelumnya) atau 2 Kolom (kiri-kanan). Tombol "Ubah tata letak" di halaman hasil juga muncul untuk 2 foto.
- **Timer foto bisa diatur**: pil "Timer" di kanan atas layar kamera, ketuk untuk berganti 0 (langsung foto), 3, 5, 10 detik. Pilihan diingat di HP. Hitung mundur sekarang 1 detik per angka. Versi browser juga punya tombol timer yang sama.
