# Snapin Android - catatan perubahan v2

## Yang diperbaiki
- **Hijau berbekas** pada bingkai berwarna polos: kunci warna baru (lihat README admin). Berlaku juga saat upload "Frame saya" di aplikasi.
- **Tombol back / keluar**: back HP sekarang mundur satu langkah di dalam aplikasi. "Ubah tata letak", "Frame saya", dan stiker
  tidak lagi melempar ke halaman utama; hasil dan stiker tetap ada. Keluar dari hasil yang belum disimpan meminta konfirmasi.
  Di beranda, back dua kali baru keluar aplikasi.
- **Gerakan stiker ala Canva**: 1 jari geser; 2 jari cubit = zoom + putar; pegangan kanan-bawah = ukuran saja; pegangan bulat bawah = putar saja
  (menempel di 0/90/180); pegangan kiri-atas = hapus.
- **Kamera tegak** dibuat selebar/setinggi mungkin (4:3 dan 16:9 terasa besar).

## Fitur baru
- **Rasio** per bingkai (admin). Bingkai hanya muncul bila jumlah foto DAN rasionya cocok.
- **Bingkai tersimpan offline di penyimpanan data** (IndexedDB), bukan cache browser. Sekali terunduh, tetap ada tanpa internet.
- **Stiker bawaan** berupa SVG (tanpa emoji) + tambah stiker dari galeri (tersimpan offline).
- **Bingkai & stiker pada video**: bingkai video (1 lubang, 16:9 tegak/landscape, termasuk animasi) tampil di pratinjau; saat simpan/bagikan video
  dirender ulang di HP (hasil .webm). **Fitur ini perlu dites di HP kamu**: bergantung MediaRecorder WebView, dan proses berjalan real-time sepanjang durasi video.
- **13 tema bingkai bawaan** dengan konsep berbeda: Bunny Pink, Yellow Buddy, Y2K Chrome, Sakura, Party Pop, Retro Film, Neon Night,
  Dreamy Cloud, Summer Ocean, Notebook, Cat Paws, Winter Snow (+ Polos).
- **Toko QRIS tanpa login**: beli bingkai/paket lewat QRIS di dalam aplikasi, atau masukkan kode redeem (ikon tag di My Assets).

## Belum / perlu dicek
- Build APK belum bisa dijalankan di sini: Kotlin diedit hati-hati tapi belum dikompilasi. Jalankan build lalu tes di HP.
- Video berbingkai diekspor sebagai .webm (bukan .mp4).

## v3 (revisi setelah dites di HP)
- **Dihapus**: Studio Bingkai (editor bebas) dan pilihan "Arah hasil" di Setup.
- **Galeri**: sekarang cukup pilih 1 sampai 6 foto, jumlah foto mengikuti yang dipilih (dulu harus pas sama jumlah foto, kalau kurang cuma muncul toast). Foto besar diproses lewat object URL supaya hemat memori.
- **Video kamera belakang gelap**: kecerahan preview dibaca otomatis; kalau terlalu gelap, kompensasi eksposur dinaikkan bertahap (mulai +1.0 EV untuk kamera belakang). Perlu dites di HP kamu.
- **Pratinjau video**: frame pertama ditampilkan walau belum diputar (sebelumnya bisa tampak hitam).
- **Teks "snapin photobooth"**: di semua bingkai bawaan dan bingkai server gratis tampil di pil putih memanjang di tengah bawah. Teks tema lain yang bentrok di area itu dihapus. Bingkai buatan sendiri (Frame saya) tidak diberi teks.
- **Bingkai berbayar**: pil putih berisi mahkota emas (bukan teks) pada hasil, dan lencana mahkota emas di daftar bingkai.

## v3.1
- **Halaman hasil tidak bisa digeser/diketuk**: lapisan stiker menutupi seluruh kanvas dan memblokir sentuhan. Sekarang lapisan itu tembus sentuhan; hanya stiker (dan pegangannya) yang menangkap sentuhan. Dites dengan geser sentuh sungguhan: sebelum perbaikan tidak bergeser, sesudahnya halaman bergeser normal.

## v3.2
- **Galeri**: tombol "Galeri" sekarang memakai pemilih foto bawaan Android (Photo Picker, bisa pilih 1 sampai 6 foto). Foto diperkecil (maks 1800 px), diluruskan sesuai EXIF, dan HEIC dikonversi ke JPEG di sisi native, jadi tidak lagi bergantung pada pemilih file WebView. Di browser tetap memakai input file biasa.
- **Tombol rekam video**: digambar ulang per status. Saat merekam isinya jadi kotak merah kecil membulat di tengah cincin (dulu terlalu besar karena ukuran lapisan tidak dihitung ulang), dengan denyut halus. Ruang di bawah pratinjau ditambah supaya tombol tidak mepet.

## v2.2 (versionCode 12)
Versi aplikasi dinaikkan dan tertulis kecil di bagian bawah Beranda ("Snapin v2.2"). Kalau tulisan itu tidak muncul setelah update, berarti APK yang terpasang masih build lama.

## v2.3 (versionCode 13)
Pemilih galeri native diberi toast ("Memproses n foto...", pesan error) dan cadangan ke pemilih file web kalau pemilih bawaan gagal dibuka.

## v2.4 (versionCode 14)
- **Bingkai muncul di semua HP**: alamat server (https://snapin-server.vercel.app) sudah tertanam di APK lewat `DEFAULT_API_BASE`, jadi semua HP otomatis memuat bingkai.
- **Tahan sinyal lemah**: daftar bingkai dan gambar bingkai punya batas waktu dan diulang otomatis (juga saat sinyal kembali atau aplikasi dibuka lagi). Memilih bingkai yang belum terunduh akan menunggu unduhan selesai, tidak lagi memakai bingkai setengah jalan. Aplikasi tidak lagi tertahan saat start karena menunggu server.
- **Pindah foto** di halaman hasil: ketuk foto pertama lalu foto kedua untuk bertukar posisi (tombol "Pindah foto", muncul bila foto 2 atau lebih).
- **My Assets (Frame saya & Stiker saya)**: upload sekarang memakai pemilih foto bawaan Android, PNG/WebP transparan tetap utuh, bisa pilih beberapa sekaligus.
- **Wajah tidak lagi hijau**: bagian dalam lubang foto dijamin transparan 100%. Bingkai lama yang lubangnya masih berwarna polos dibersihkan otomatis saat diunduh ke HP (tidak perlu upload ulang).
- Versi tertulis "Snapin v2.4" di Beranda (versionCode 15).
- **Tata letak 2 foto**: setelah 2 foto diambil, muncul pilihan Strip (atas-bawah, seperti sebelumnya) atau 2 Kolom (kiri-kanan). Tombol "Ubah tata letak" di halaman hasil juga muncul untuk 2 foto.
- **Timer foto bisa diatur**: pil "Timer" di kanan atas layar kamera, ketuk untuk berganti 0 (langsung foto), 3, 5, 10 detik. Pilihan diingat di HP. Hitung mundur sekarang 1 detik per angka. Versi browser juga punya tombol timer yang sama.

## v2.4 (versionCode 16) - tambahan
- **Tombol hasil foto dirapikan**: Pindah foto, Putar 180°, dan Ambil ulang kini berupa tiga kartu sejajar dengan ikon SVG, bukan lagi tombol bulat besar.
- **Video dari galeri**: di pengaturan, pada mode Video, tombol kiri bawah menjadi "Pilih video". Video dari galeri (maksimal 60 detik dan 300 MB) diproses sama seperti hasil rekaman: dapat diberi bingkai dan stiker, disimpan, dan dibagikan. Layar galeri juga tersedia saat kamera tidak dapat diakses.
- **Teks aplikasi dibuat profesional**: sapaan "Anda", istilah baku (bingkai, stiker, berkas, perangkat, lanskap), dan pesan kesalahan yang lebih jelas, baik di aplikasi maupun di pesan kamera native. "My Assets" menjadi "Aset Saya".

## v10 (versi 2.5)
- **Stiker tidak lagi keluar dari bingkai**: stiker dipotong di tepi bingkai (tidak muncul di atas kartu "Gaya bingkai" dan bagian lain), titik tengah stiker dibatasi di dalam bingkai. Kotak pilihan dan pegangan digambar di lapisan terpisah supaya tetap bisa dipegang walau stiker di tepi.
- **Video kamera depan**: mode cermin bawaan CameraX dan rasio 16:9 dimatikan (sumber layar hitam di sebagian HP). Pembukaan kamera sekarang bertingkat: HD 16:9, lalu SD, lalu kualitas terendah; kalau gambar belum tampil dalam sekitar 3 detik, otomatis turun satu tingkat. Kompensasi eksposur depan dikurangi (+0.5 EV). **Hasil video kamera depan sekarang tidak dicerminkan** (seperti kamera bawaan HP). Kotlin belum bisa dikompilasi di sini, jadi perlu dites di HP.
- **Tombol play/pause pada video berbingkai**: sekarang berada di tengah video (bukan di pinggir bingkai), hilang saat video berjalan, dan muncul sebentar saat layar diketuk.
- **Bingkai bawaan untuk video**: 12 tema bawaan (Bunny Pink, Yellow Buddy, dst.) sekarang juga tersedia di mode video, dengan hiasan tetap di atas video. Dibuat mengikuti rasio video.
- **Bingkai video dari admin**: bingkai berupa video (MP4/WebM, disarankan 10 detik) diulang otomatis selama video pengguna berjalan (20 detik = 2 kali, 25 detik = 2,5 kali). Lubang foto dipotong dengan sudut membulat sesuai pengaturan admin.

## Dites di sini (Chromium, sentuhan nyata)
Geser, ubah ukuran, putar, cubit 2 jari, hapus, stiker diseret jauh keluar bingkai (tertahan di tepi), loop bingkai video (posisi bingkai = waktu video mod durasi bingkai), hasil render video 20 detik (bingkai terbukti berulang), tema bawaan di video.

## v11 (versi 2.6)
- **Kotak abu-abu dengan ikon play besar di bawah preview video**: itu elemen video bingkai (v10) yang ikut tampil saat tidak ada bingkai. Sekarang disembunyikan kecuali bingkai video dipilih. Tinggi preview kembali sama dengan videonya.
- **Kamera depan gelap di malam hari (video)**: eksposur awal depan dikembalikan ke +1.5 EV (di v10 sempat diturunkan) dan penyesuaian otomatis lebih agresif (target lebih terang, langkah sampai +1.5 EV, sampai batas maksimum HP). Rentang FPS target 15-30 diminta supaya eksposur bisa lebih lama di tempat gelap. Kalau setelah beberapa detik masih gelap, muncul **lampu cincin layar** (bingkai putih terang di tepi layar) sebagai penerang wajah, dan sebuah pesan singkat. Lampu dimatikan lagi saat kamera dibalik. Kode Kotlin belum bisa dikompilasi di sini, jadi perlu dites di HP.

## v12 (versi 2.6)
- **Lampu cincin layar dihapus** (kamera depan sudah normal menurut tes di HP). Perbaikan eksposur dan FPS kamera depan tetap dipakai.
- **Tulisan versi di halaman utama**: Snapin v2.6.
- **Layout baru untuk 3 dan 5 foto (bukan strip)**: foto lebar penuh sekarang bisa dipindah ke atas.
  - 3 foto: "1 Atas + 2 Bawah" (1 foto penuh di atas, 2 foto sejajar di bawah). Pilihan lama "2 Atas + 1 Bawah" tetap ada.
  - 5 foto: "1 Atas + 4 Bawah" (1 foto penuh di atas, grid 2x2 di bawah). Pilihan lama "4 Atas + 1 Bawah" tetap ada.
  - Dipilih di halaman Tata letak (dan lewat "Ubah tata letak" di halaman hasil). Foto pertama masuk ke kotak lebar di atas. Hiasan tema dan footer menyesuaikan otomatis.

## v13 (versi 2.6)
- **Durasi video 0 di galeri / lambat dibuka**: hasil render video berbingkai (WebM dari perekam bawaan WebView) tidak memuat durasi di header file. Sekarang durasi dan indeks posisi (Cues) ditulis ke file sebelum disimpan, jadi galeri membaca durasi yang benar dan bisa melompat. Berlaku juga untuk rekaman kamera versi browser. Dites: sebelum diperbaiki durasi tidak terbaca (N/A), sesudahnya 20,0 dan 60,0 detik, bisa dilompati, dan isi video tetap sinkron.
- **Video sampai 1 menit**:
  - Batas rekam kamera dinaikkan dari 30 ke 60 detik (`MAX_VIDEO_SECONDS`). Impor video dari galeri sudah 60 detik sejak awal.
  - Render video berbingkai dites 60 detik: selesai sekitar 61 detik, file sekitar 12 MB, bingkai video 10 detik berulang terus sampai akhir.
  - Bitrate menyesuaikan durasi (5 Mbps sampai 20 detik, 4 Mbps sampai 40 detik, 3,2 Mbps sampai 60 detik) supaya file dan memori tetap kecil.
  - Layar tidak mati selama proses (FLAG_KEEP_SCREEN_ON di MainActivity). Kalau aplikasi dibuka ke latar belakang saat render, perekaman dijeda bersama videonya lalu dilanjutkan, jadi hasil tidak membeku.
  - Teks progres sekarang menampilkan perkiraan sisa waktu.
- Catatan: aplikasi tidak memakai ffmpeg. Render memakai perekam bawaan WebView (MediaRecorder); ffmpeg hanya dipakai untuk memeriksa hasil saat pengujian.

## v14 (versi 2.6) - hanya jalur render video
- Pengiriman frame saat render video dibuat lebih rata: frame digambar tepat saat video punya frame baru (30 kali per detik, bukan 60 kali per detik lewat rAF) dan dikirim ke perekam dengan `requestFrame`. Encoder diubah ke VP8 lebih dulu (lebih ringan di HP daripada VP9). Di tes: jeda panjang antar frame turun dari 44 jadi 20 per 20 detik. Tidak ada perubahan lain (tampilan, kualitas, bitrate, kamera tidak disentuh).
- Diketahui, belum diubah: kamera depan meminta rentang FPS 15-30 (v11, supaya lebih terang di tempat gelap). Di ruangan sangat gelap kamera bisa merekam di sekitar 15 fps, dan itu terlihat patah-patah di hasil. Pilihan: biarkan, atau naikkan batas bawah jadi 24.

## v15 (versi 2.6) - eksposur video dinormalkan
- Video terlalu putih/terang: dorongan eksposur di v11 (+1,5 EV depan, +1,0 EV belakang) dihapus. Eksposur awal video sekarang 0 EV, sama seperti mode foto.
- Penyesuaian otomatis tinggal kecil: naik 0,5 EV per langkah hanya kalau gambar sangat gelap, turun kalau terlalu terang, dibatasi maksimal 1 EV di atas atau di bawah normal (sebelumnya bisa naik terus dan tidak pernah turun di bawah dorongan awal).
- Teks "Siap merekam (maksimal 30 detik)" diperbaiki jadi 60 detik (batasnya sudah 60 sejak v13).
- Tidak diubah: rentang FPS kamera depan, render video, dan bagian lain.

## v16 (versi 2.6) - render video dibangun ulang (stabil, tidak membeku di akhir)
Masalah: video hasil render membeku di akhir. Penyebab: render lama merekam layar secara real-time (MediaRecorder). Frame yang terlambat hilang, dan durasi di header hanya ditebak dari video sumber, jadi video berhenti di 19,7 detik sementara audio dan header menyatakan 20 detik.

Perbaikan (jalur render saja):
- **Engine baru (WebCodecs)**: setiap frame diberi cap waktu dari video sumber, bukan jam dinding. Frame digambar tepat saat video punya frame baru, lalu di-encode. Kalau ada frame terlewat atau antrean encoder menumpuk, putaran otomatis diperlambat (sampai 2x lebih lambat) supaya frame tidak hilang. Hasil render bisa memakan waktu sampai sekitar 2x durasi video di HP yang encodernya lambat.
- **Audio** didekode lalu di-encode terpisah, sinkron per sampel dan dipotong sesuai panjang video. Kalau audio gagal didekode padahal videonya punya suara, otomatis memakai jalur cadangan (tidak pernah menghasilkan video bisu secara diam-diam).
- **Format**: MP4 (H.264 + AAC, indeks di depan file) bila HP mendukung encoder H.264 dan AAC; kalau tidak, WebM (VP8 + Opus). Header (durasi, indeks) ditulis lengkap oleh aplikasi sendiri, jadi galeri membaca durasi yang benar.
- **Jalur cadangan** tetap ada: kalau WebCodecs tidak tersedia atau gagal di tengah, render memakai MediaRecorder seperti sebelumnya. Durasi file cadangan sekarang dibaca dari isi file (waktu blok terakhir), bukan tebakan.
- Bitrate: 4,5 Mbps (sampai 20 detik), 3,5 Mbps (sampai 40 detik), 2,5 Mbps (sampai 60 detik).

Dites (Chromium): 20 detik dan 60 detik, WebM dan MP4, tombol Batal, jalur cadangan, video tanpa suara, kegagalan dekode audio. Durasi tepat (60,000 detik), frame video dan audio berakhir bersamaan, bisa dilompati, tidak ada error decode. Muxer MP4 dengan AAC dites terpisah memakai data H.264/AAC dari ffmpeg (180 frame, 6,0 detik, bisa didekode). Belum dites di HP asli: encoder H.264 dan AAC perangkat keras (hanya ada di HP), jadi pilihan MP4 + AAC di HP-mu perlu dicoba.

## v17 (versi 2.6) - bingkai video: hiasan kembali di depan video
- **Masalah**: pada bingkai video, seluruh kotak lubang dipotong, jadi hiasan yang masuk ke area lubang (kucing di pojok, awan, selotip) ikut hilang dan video terlihat "ngambang" menutupi bingkai.
- **Perbaikan**: hanya warna lubang (hijau, magenta, dst.) yang dibuat transparan, per piksel, lewat WebGL di GPU. Warna lubang dikenali otomatis dari frame video itu sendiri, jadi bingkai video yang sudah diunggah sebelumnya langsung benar tanpa diunggah ulang. Hiasan di dalam area lubang tetap di depan video pengguna. Berlaku untuk pratinjau dan hasil render.
- Video bingkai transparan (WebM alpha) ditampilkan apa adanya. Lubang yang bukan warna polos memakai cara lama (potong kotak lubang).
- **Pengaman**: kalau WebGL terlalu lambat di sebuah HP saat render (rata-rata di atas 60 ms per frame), otomatis pindah ke cara lama supaya video tidak tersendat. Saat render, pratinjau (video, bingkai, WebGL) dihentikan sementara supaya tenaga perangkat dipakai penuh, lalu dilanjutkan setelah selesai.
- Dites di Chromium dengan bingkai uji berhiasan di dalam lubang: pratinjau dan hasil render 20 detik, hiasan terbukti di depan video. WebGL di komputer uji berjalan dengan emulasi perangkat lunak (lebih lambat dari GPU HP), jadi kecepatan di HP asli perlu dicoba.
