plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.snapin.photobooth"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.snapin.photobooth"
        minSdk = 24
        targetSdk = 34
        versionCode = 25
        versionName = "2.6"
    }

    // Kunci tanda tangan tetap: APK versi baru bisa langsung menimpa (update)
    // versi lama tanpa uninstall. Simpan repo ini sebagai PRIVATE.
    signingConfigs {
        create("snapin") {
            storeFile = file("snapin.keystore")
            storePassword = "snapin2026key"
            keyAlias = "snapin"
            keyPassword = "snapin2026key"
        }
    }

    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("snapin")
        }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("snapin")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity:1.9.3")
    implementation("androidx.webkit:webkit:1.8.0")
    implementation("androidx.camera:camera-core:1.3.4")
    implementation("androidx.camera:camera-camera2:1.3.4")
    implementation("androidx.camera:camera-lifecycle:1.3.4")
    implementation("androidx.camera:camera-video:1.3.4")
    implementation("androidx.camera:camera-view:1.3.4")
    implementation("com.google.guava:guava:31.1-android")
}
