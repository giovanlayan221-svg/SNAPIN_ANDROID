package com.snapin.photobooth

import android.app.Activity
import android.app.WallpaperManager
import android.graphics.BitmapFactory
import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.util.Base64
import android.webkit.JavascriptInterface
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File
import java.io.OutputStream

/**
 * Simpan ke galeri & bagikan hasil foto/video. Di web dipanggil sebagai window.SnapinFiles.
 * Video sudah ada sebagai file di HP, jadi tidak perlu dikirim lewat JavaScript.
 */
class FileBridge(private val activity: Activity) {

    @JavascriptInterface
    fun isAvailable(): Boolean = true

    @JavascriptInterface
    fun saveImage(base64: String): Boolean {
        return try {
            val bytes = Base64.decode(base64, Base64.DEFAULT)
            val name = "Snapin_" + System.currentTimeMillis() + ".png"
            val ok = insertAndWrite("image/png", name, false) { out -> out.write(bytes) }
            toast(if (ok) "Foto berhasil disimpan di galeri (Pictures/Snapin)" else "Gagal menyimpan foto")
            ok
        } catch (e: Exception) {
            toast("Gagal menyimpan foto")
            false
        }
    }

    @JavascriptInterface
    fun saveVideo(): Boolean {
        val path = CameraSession.videoPath
        if (path == null) {
            toast("Video belum tersedia")
            return false
        }
        val src = File(path)
        if (!src.exists()) {
            toast("Berkas video tidak ditemukan")
            return false
        }
        val name = "Snapin_" + System.currentTimeMillis() + ".mp4"
        val ok = insertAndWrite("video/mp4", name, true) { out -> src.inputStream().use { it.copyTo(out) } }
        toast(if (ok) "Video berhasil disimpan di galeri (Movies/Snapin)" else "Gagal menyimpan video")
        return ok
    }

    @JavascriptInterface
    fun shareImage(base64: String) {
        try {
            val bytes = Base64.decode(base64, Base64.DEFAULT)
            val dir = File(activity.cacheDir, "shared")
            dir.mkdirs()
            val f = File(dir, "snapin_photobooth.png")
            f.writeBytes(bytes)
            share(f, "image/png")
        } catch (e: Exception) {
            toast("Gagal membagikan foto")
        }
    }

    @JavascriptInterface
    fun shareVideo() {
        val path = CameraSession.videoPath
        if (path == null || !File(path).exists()) {
            toast("Video belum tersedia")
            return
        }
        share(File(path), "video/mp4")
    }

    // ---- terima file besar dari web per potongan (video berbingkai hasil render di WebView) ----
    private var chunkFile: File? = null
    private var chunkOut: java.io.FileOutputStream? = null

    @JavascriptInterface
    fun bytesBegin(): Boolean {
        return try {
            val dir = File(activity.cacheDir, "shared"); dir.mkdirs()
            val f = File(dir, "snapin_framed_" + System.currentTimeMillis() + ".tmp")
            chunkOut?.close()
            chunkFile = f
            chunkOut = java.io.FileOutputStream(f)
            true
        } catch (e: Exception) { false }
    }

    @JavascriptInterface
    fun bytesChunk(base64: String): Boolean {
        return try { chunkOut?.write(Base64.decode(base64, Base64.DEFAULT)); chunkOut != null } catch (e: Exception) { false }
    }

    /** mode: "save" simpan ke galeri, "share" bagikan. ext: mp4 / webm. */
    @JavascriptInterface
    fun bytesEnd(mode: String, ext: String): Boolean {
        val f = chunkFile ?: return false
        try { chunkOut?.close() } catch (e: Exception) { }
        chunkOut = null
        val mime = if (ext == "mp4") "video/mp4" else "video/webm"
        val named = File(f.parentFile, "snapin_framed." + ext)
        try { if (named.exists()) named.delete(); f.renameTo(named) } catch (e: Exception) { return false }
        chunkFile = null
        if (mode == "share") { share(named, mime); return true }
        val name = "Snapin_" + System.currentTimeMillis() + "." + ext
        val ok = insertAndWrite(mime, name, true) { out -> named.inputStream().use { it.copyTo(out) } }
        toast(if (ok) "Video berhasil disimpan di galeri (Movies/Snapin)" else "Gagal menyimpan video")
        return ok
    }

    /**
     * Pasang gambar sebagai wallpaper. target: "home" (layar utama), "lock" (layar kunci), atau "both".
     * Gambar sudah disesuaikan dengan ukuran layar oleh halaman web. Diproses di thread terpisah
     * agar WebView tidak membeku; hasilnya dikirim kembali ke halaman lewat window.__onWallpaperResult(ok).
     */
    @JavascriptInterface
    fun setWallpaper(base64: String, target: String): Boolean {
        Thread {
            var ok = false
            try {
                val bytes = Base64.decode(base64, Base64.DEFAULT)
                val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                if (bmp != null) {
                    val wm = WallpaperManager.getInstance(activity)
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                        val flags = when (target) {
                            "home" -> WallpaperManager.FLAG_SYSTEM
                            "lock" -> WallpaperManager.FLAG_LOCK
                            else -> WallpaperManager.FLAG_SYSTEM or WallpaperManager.FLAG_LOCK
                        }
                        wm.setBitmap(bmp, null, true, flags)
                    } else {
                        wm.setBitmap(bmp)
                    }
                    bmp.recycle()
                    ok = true
                }
            } catch (e: Throwable) {
                ok = false
            }
            val result = ok
            activity.runOnUiThread {
                Toast.makeText(
                    activity,
                    if (result) "Wallpaper berhasil dipasang" else "Gagal memasang wallpaper",
                    Toast.LENGTH_LONG
                ).show()
                try {
                    (activity as? MainActivity)?.evalJs("window.__onWallpaperResult && window.__onWallpaperResult(" + result + ")")
                } catch (e: Throwable) { }
            }
        }.start()
        return true
    }

    /** Ganti tema aplikasi + ikon peluncur: "pink" atau "elegant". */
    @JavascriptInterface
    fun setAppTheme(name: String): Boolean {
        return AppTheme.set(activity, name)
    }

    @JavascriptInterface
    fun getAppTheme(): String = if (AppTheme.isElegant(activity)) "elegant" else "pink"

    @JavascriptInterface
    fun exitApp() {
        activity.runOnUiThread { activity.finish() }
    }

    /** Buka alamat web (mis. halaman admin) di browser HP. */
    @JavascriptInterface
    fun openUrl(url: String) {
        if (!(url.startsWith("https://") || url.startsWith("http://"))) return
        activity.runOnUiThread {
            try {
                activity.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
            } catch (e: Exception) {
                Toast.makeText(activity, "Alamat tidak dapat dibuka", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun share(file: File, mime: String) {
        try {
            val uri = FileProvider.getUriForFile(activity, activity.packageName + ".fileprovider", file)
            val intent = Intent(Intent.ACTION_SEND)
            intent.type = mime
            intent.putExtra(Intent.EXTRA_STREAM, uri)
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            activity.runOnUiThread {
                try {
                    activity.startActivity(Intent.createChooser(intent, "Bagikan"))
                } catch (e: Exception) {
                    Toast.makeText(activity, "Tidak ada aplikasi yang dapat digunakan untuk berbagi", Toast.LENGTH_LONG).show()
                }
            }
        } catch (e: Exception) {
            toast("Gagal membagikan")
        }
    }

    private fun insertAndWrite(
        mime: String,
        name: String,
        isVideo: Boolean,
        writer: (OutputStream) -> Unit
    ): Boolean {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val folder = if (isVideo) Environment.DIRECTORY_MOVIES else Environment.DIRECTORY_PICTURES
                val values = ContentValues()
                values.put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                values.put(MediaStore.MediaColumns.MIME_TYPE, mime)
                values.put(MediaStore.MediaColumns.RELATIVE_PATH, folder + "/Snapin")
                val collection = if (isVideo) {
                    MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                } else {
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                }
                val uri = activity.contentResolver.insert(collection, values) ?: return false
                val out = activity.contentResolver.openOutputStream(uri) ?: return false
                out.use { writer(it) }
            } else {
                val type = if (isVideo) Environment.DIRECTORY_MOVIES else Environment.DIRECTORY_PICTURES
                val dir = activity.getExternalFilesDir(type) ?: activity.filesDir
                File(dir, name).outputStream().use { writer(it) }
            }
            return true
        } catch (e: Exception) {
            return false
        }
    }

    private fun toast(msg: String) {
        activity.runOnUiThread {
            Toast.makeText(activity, msg, Toast.LENGTH_LONG).show()
        }
    }
}
