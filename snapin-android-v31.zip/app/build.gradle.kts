plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.snapin.photobooth"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.snapin.photobooth"
        minSdk = 24
        targetSdk = 34
        versionCode = 29
        versionName = "2.8"
    }

    // Kunci tanda tangan tetap: APK versi baru bisa langsung menimpa (update) versi lama tanpa uninstall.
    // Kunci TIDAK disimpan di repo. Di GitHub Actions kunci dibaca dari Secrets lewat variabel lingkungan
    // (SNAPIN_KEYSTORE_PATH, SNAPIN_STORE_PASSWORD, SNAPIN_KEY_ALIAS, SNAPIN_KEY_PASSWORD).
    // Tanpa kunci, build tetap jalan dan memakai tanda tangan debug bawaan Android.
    val ksFile = file(System.getenv("SNAPIN_KEYSTORE_PATH") ?: "snapin.keystore")
    val ksPass = System.getenv("SNAPIN_STORE_PASSWORD") ?: ""
    val hasKey = ksFile.exists() && ksPass.isNotEmpty()
    signingConfigs {
        if (hasKey) {
            create("snapin") {
                storeFile = ksFile
                storePassword = ksPass
                keyAlias = System.getenv("SNAPIN_KEY_ALIAS") ?: "snapin"
                keyPassword = System.getenv("SNAPIN_KEY_PASSWORD") ?: ksPass
            }
        }
    }

    buildTypes {
        getByName("debug") {
            if (hasKey) signingConfig = signingConfigs.getByName("snapin")
        }
        release {
            isMinifyEnabled = false
            if (hasKey) signingConfig = signingConfigs.getByName("snapin")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity:1.9.3")
    implementation("androidx.webkit:webkit:1.8.0")
    implementation("androidx.camera:camera-core:1.3.4")
    implementation("androidx.camera:camera-camera2:1.3.4")
    implementation("androidx.camera:camera-lifecycle:1.3.4")
    implementation("androidx.camera:camera-video:1.3.4")
    implementation("androidx.camera:camera-view:1.3.4")
    implementation("com.google.guava:guava:31.1-android")
}
