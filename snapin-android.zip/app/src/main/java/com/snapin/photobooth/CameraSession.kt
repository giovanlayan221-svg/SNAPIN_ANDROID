package com.snapin.photobooth

/**
 * Menyimpan keadaan sesi kamera native (foto atau video) supaya tidak hilang
 * kalau layar kamera berputar mengikuti HP.
 */
object CameraSession {
    @Volatile var mode = "photo"      // "photo" | "video"
    @Volatile var count = 4
    @Volatile var facing = "user"
    @Volatile var pw = 3   // lebar rasio potret
    @Volatile var ph = 4   // tinggi rasio potret
    val photos = ArrayList<String>()
    @Volatile var rotationLock: Int? = null
    @Volatile var landscape = false
    @Volatile var videoPath: String? = null

    fun reset(mode: String, count: Int, facing: String, pw: Int, ph: Int) {
        this.mode = mode
        this.count = count
        this.facing = facing
        this.pw = pw
        this.ph = ph
        photos.clear()
        rotationLock = null
        landscape = false
        videoPath = null
    }
}
