package com.snapin.photobooth

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.util.Base64
import android.webkit.JavascriptInterface
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File
import java.io.OutputStream

/**
 * Simpan ke galeri & bagikan hasil foto/video. Di web dipanggil sebagai window.SnapinFiles.
 * Video sudah ada sebagai file di HP, jadi tidak perlu dikirim lewat JavaScript.
 */
class FileBridge(private val activity: Activity) {

    @JavascriptInterface
    fun isAvailable(): Boolean = true

    @JavascriptInterface
    fun saveImage(base64: String): Boolean {
        return try {
            val bytes = Base64.decode(base64, Base64.DEFAULT)
            val name = "Snapin_" + System.currentTimeMillis() + ".png"
            val ok = insertAndWrite("image/png", name, false) { out -> out.write(bytes) }
            toast(if (ok) "Foto tersimpan di galeri (Pictures/Snapin)" else "Gagal menyimpan foto")
            ok
        } catch (e: Exception) {
            toast("Gagal menyimpan foto")
            false
        }
    }

    @JavascriptInterface
    fun saveVideo(): Boolean {
        val path = CameraSession.videoPath
        if (path == null) {
            toast("Belum ada video")
            return false
        }
        val src = File(path)
        if (!src.exists()) {
            toast("File video tidak ditemukan")
            return false
        }
        val name = "Snapin_" + System.currentTimeMillis() + ".mp4"
        val ok = insertAndWrite("video/mp4", name, true) { out -> src.inputStream().use { it.copyTo(out) } }
        toast(if (ok) "Video tersimpan di galeri (Movies/Snapin)" else "Gagal menyimpan video")
        return ok
    }

    @JavascriptInterface
    fun shareImage(base64: String) {
        try {
            val bytes = Base64.decode(base64, Base64.DEFAULT)
            val dir = File(activity.cacheDir, "shared")
            dir.mkdirs()
            val f = File(dir, "snapin_photobooth.png")
            f.writeBytes(bytes)
            share(f, "image/png")
        } catch (e: Exception) {
            toast("Gagal membagikan foto")
        }
    }

    @JavascriptInterface
    fun shareVideo() {
        val path = CameraSession.videoPath
        if (path == null || !File(path).exists()) {
            toast("Belum ada video")
            return
        }
        share(File(path), "video/mp4")
    }

    private fun share(file: File, mime: String) {
        try {
            val uri = FileProvider.getUriForFile(activity, activity.packageName + ".fileprovider", file)
            val intent = Intent(Intent.ACTION_SEND)
            intent.type = mime
            intent.putExtra(Intent.EXTRA_STREAM, uri)
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            activity.runOnUiThread {
                try {
                    activity.startActivity(Intent.createChooser(intent, "Bagikan"))
                } catch (e: Exception) {
                    Toast.makeText(activity, "Tidak ada aplikasi untuk berbagi", Toast.LENGTH_LONG).show()
                }
            }
        } catch (e: Exception) {
            toast("Gagal membagikan")
        }
    }

    private fun insertAndWrite(
        mime: String,
        name: String,
        isVideo: Boolean,
        writer: (OutputStream) -> Unit
    ): Boolean {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val folder = if (isVideo) Environment.DIRECTORY_MOVIES else Environment.DIRECTORY_PICTURES
                val values = ContentValues()
                values.put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                values.put(MediaStore.MediaColumns.MIME_TYPE, mime)
                values.put(MediaStore.MediaColumns.RELATIVE_PATH, folder + "/Snapin")
                val collection = if (isVideo) {
                    MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                } else {
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                }
                val uri = activity.contentResolver.insert(collection, values) ?: return false
                val out = activity.contentResolver.openOutputStream(uri) ?: return false
                out.use { writer(it) }
            } else {
                val type = if (isVideo) Environment.DIRECTORY_MOVIES else Environment.DIRECTORY_PICTURES
                val dir = activity.getExternalFilesDir(type) ?: activity.filesDir
                File(dir, name).outputStream().use { writer(it) }
            }
            return true
        } catch (e: Exception) {
            return false
        }
    }

    private fun toast(msg: String) {
        activity.runOnUiThread {
            Toast.makeText(activity, msg, Toast.LENGTH_LONG).show()
        }
    }
}
