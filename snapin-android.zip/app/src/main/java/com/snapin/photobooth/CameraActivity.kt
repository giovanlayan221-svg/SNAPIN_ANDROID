package com.snapin.photobooth

import android.Manifest
import android.annotation.SuppressLint
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Base64
import android.util.TypedValue
import android.view.Gravity
import android.view.OrientationEventListener
import android.view.Surface
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.AspectRatio
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.FallbackStrategy
import androidx.camera.video.FileOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.core.util.Consumer
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.max
import kotlin.math.min

/**
 * Layar kamera native (CameraX / Camera2) untuk foto dan video. Rotasi diurus
 * lewat metadata kamera seperti aplikasi kamera bawaan.
 */
class CameraActivity : ComponentActivity() {

    private lateinit var previewView: PreviewView
    private lateinit var countText: TextView
    private lateinit var counterText: TextView
    private lateinit var flashView: View
    private lateinit var shutterView: View
    private lateinit var shutterInner: GradientDrawable
    private lateinit var shutterLayers: LayerDrawable

    private var imageCapture: ImageCapture? = null
    private var videoCapture: VideoCapture<Recorder>? = null
    private var recording: Recording? = null
    private var recordStartAt = 0L

    private var currentRotation = Surface.ROTATION_0
    private var busy = false
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var cameraExecutor: ExecutorService
    private var orientationListener: OrientationEventListener? = null

    private val isVideo: Boolean
        get() = CameraSession.mode == "video"

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { _ ->
            if (hasCameraPermission()) {
                bindCamera()
            } else {
                toast("Izin kamera ditolak")
                finish()
            }
        }

    private val tick = object : Runnable {
        override fun run() {
            val s = ((SystemClock.elapsedRealtime() - recordStartAt) / 1000).toInt()
            counterText.text = "REC " + two(s / 60) + ":" + two(s % 60)
            if (s >= MAX_VIDEO_SECONDS) {
                stopRecording()
                return
            }
            handler.postDelayed(this, 250)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        cameraExecutor = Executors.newSingleThreadExecutor()
        buildUi()
        setupOrientationListener()
        if (hasCameraPermission()) {
            bindCamera()
        } else if (isVideo) {
            permissionLauncher.launch(arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO))
        } else {
            permissionLauncher.launch(arrayOf(Manifest.permission.CAMERA))
        }
    }

    private fun hasCameraPermission(): Boolean {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) ==
            PackageManager.PERMISSION_GRANTED
    }

    private fun hasAudioPermission(): Boolean {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
    }

    private fun two(n: Int): String {
        return if (n < 10) "0" + n else n.toString()
    }

    private fun dp(v: Int): Int {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics
        ).toInt()
    }

    private fun circleButton(iconRes: Int): ImageView {
        val v = ImageView(this)
        val bg = GradientDrawable()
        bg.shape = GradientDrawable.OVAL
        bg.setColor(Color.WHITE)
        v.background = bg
        v.setImageResource(iconRes)
        v.setPadding(dp(10), dp(10), dp(10), dp(10))
        v.elevation = dp(3).toFloat()
        v.setColorFilter(PLUM)
        return v
    }

    private fun buildUi() {
        val dm = resources.displayMetrics
        val sw = dm.widthPixels
        val sh = dm.heightPixels
        val landscape = sw > sh
        val s = CameraSession
        val spw = if (isVideo) 9 else s.pw
        val sph = if (isVideo) 16 else s.ph
        val portraitAr = spw.toFloat() / sph.toFloat()
        val boxAr = if (landscape) 1f / portraitAr else portraitAr

        val availW = if (landscape) sw - dp(230) else sw - dp(32)
        val availH = if (landscape) sh - dp(40) else sh - dp(280)
        var bw = availW
        var bh = (bw / boxAr).toInt()
        if (bh > availH) {
            bh = availH
            bw = (bh * boxAr).toInt()
        }

        val root = FrameLayout(this)
        root.setBackgroundColor(CREAM)

        // kotak preview
        val box = FrameLayout(this)
        val boxBg = GradientDrawable()
        boxBg.setColor(Color.BLACK)
        boxBg.cornerRadius = dp(24).toFloat()
        box.background = boxBg
        box.clipToOutline = true
        val boxLp = FrameLayout.LayoutParams(bw, bh)
        if (landscape) {
            boxLp.gravity = Gravity.CENTER_VERTICAL or Gravity.START
            boxLp.leftMargin = dp(16)
        } else {
            boxLp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            boxLp.topMargin = dp(84)
        }
        root.addView(box, boxLp)

        previewView = PreviewView(this)
        previewView.implementationMode = PreviewView.ImplementationMode.COMPATIBLE
        previewView.scaleType = PreviewView.ScaleType.FILL_CENTER
        box.addView(
            previewView,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )

        flashView = View(this)
        flashView.setBackgroundColor(Color.WHITE)
        flashView.alpha = 0f
        box.addView(
            flashView,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )

        countText = TextView(this)
        countText.textSize = 96f
        countText.setTextColor(Color.WHITE)
        countText.typeface = Typeface.DEFAULT_BOLD
        countText.setShadowLayer(12f, 0f, 4f, Color.argb(153, 0, 0, 0))
        countText.visibility = View.GONE
        box.addView(
            countText,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER
            )
        )

        // tombol kembali
        val back = circleButton(R.drawable.ic_back)
        back.setOnClickListener { finish() }
        val backLp = FrameLayout.LayoutParams(dp(44), dp(44))
        backLp.gravity = Gravity.TOP or Gravity.START
        backLp.topMargin = dp(16)
        backLp.leftMargin = dp(16)
        if (landscape) {
            backLp.gravity = Gravity.TOP or Gravity.END
            backLp.leftMargin = 0
            backLp.rightMargin = dp(16)
        }
        root.addView(back, backLp)

        // tombol balik kamera depan/belakang
        val flip = circleButton(R.drawable.ic_flip)
        flip.setOnClickListener { onFlip() }
        val flipLp = FrameLayout.LayoutParams(dp(44), dp(44))
        if (landscape) {
            flipLp.gravity = Gravity.BOTTOM or Gravity.END
            flipLp.bottomMargin = dp(16)
            flipLp.rightMargin = dp(16)
        } else {
            flipLp.gravity = Gravity.TOP or Gravity.END
            flipLp.topMargin = dp(16)
            flipLp.rightMargin = dp(16)
        }
        root.addView(flip, flipLp)

        // penghitung foto / timer video
        counterText = TextView(this)
        counterText.setTextColor(PLUM)
        counterText.textSize = 15f
        counterText.typeface = Typeface.DEFAULT_BOLD
        counterText.setPadding(dp(16), dp(8), dp(16), dp(8))
        val pill = GradientDrawable()
        pill.setColor(Color.WHITE)
        pill.cornerRadius = dp(20).toFloat()
        counterText.background = pill
        val counterLp = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
        )
        if (landscape) {
            counterLp.gravity = Gravity.TOP or Gravity.END
            counterLp.topMargin = dp(72)
            counterLp.rightMargin = dp(16)
        } else {
            counterLp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            counterLp.topMargin = dp(22)
        }
        root.addView(counterText, counterLp)
        updateCounter()

        // tombol jepret / rekam
        val accent = if (isVideo) RED else PINK
        shutterView = View(this)
        val outer = GradientDrawable()
        outer.shape = GradientDrawable.OVAL
        outer.setColor(Color.WHITE)
        outer.setStroke(dp(4), accent)
        shutterInner = GradientDrawable()
        shutterInner.shape = GradientDrawable.OVAL
        shutterInner.setColor(accent)
        shutterLayers = LayerDrawable(arrayOf<Drawable>(outer, shutterInner))
        shutterLayers.setLayerInset(1, dp(8), dp(8), dp(8), dp(8))
        shutterView.background = shutterLayers
        shutterView.setOnClickListener { onShutter() }
        val shutterLp = FrameLayout.LayoutParams(dp(76), dp(76))
        if (landscape) {
            shutterLp.gravity = Gravity.END or Gravity.CENTER_VERTICAL
            shutterLp.rightMargin = dp(60)
        } else {
            shutterLp.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            shutterLp.bottomMargin = dp(52)
        }
        root.addView(shutterView, shutterLp)

        setContentView(root)
    }

    private fun updateCounter() {
        if (isVideo) {
            counterText.text = "Siap merekam (maks 30 detik)"
            return
        }
        val total = CameraSession.count
        val n = min(CameraSession.photos.size + 1, total)
        counterText.text = "Foto " + n + "/" + total
    }

    private fun setShutterRecording(on: Boolean) {
        if (on) {
            shutterInner.shape = GradientDrawable.RECTANGLE
            shutterInner.cornerRadius = dp(8).toFloat()
            shutterLayers.setLayerInset(1, dp(24), dp(24), dp(24), dp(24))
        } else {
            shutterInner.shape = GradientDrawable.OVAL
            shutterLayers.setLayerInset(1, dp(8), dp(8), dp(8), dp(8))
        }
        shutterLayers.invalidateSelf()
        shutterView.invalidate()
    }

    private fun setupOrientationListener() {
        orientationListener = object : OrientationEventListener(this) {
            override fun onOrientationChanged(orientation: Int) {
                if (orientation == OrientationEventListener.ORIENTATION_UNKNOWN) return
                val r = when {
                    orientation >= 315 || orientation < 45 -> Surface.ROTATION_0
                    orientation < 135 -> Surface.ROTATION_270
                    orientation < 225 -> Surface.ROTATION_180
                    else -> Surface.ROTATION_90
                }
                currentRotation = r
                if (CameraSession.rotationLock == null) {
                    imageCapture?.targetRotation = r
                }
                if (recording == null) {
                    videoCapture?.targetRotation = r
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        orientationListener?.enable()
    }

    override fun onPause() {
        orientationListener?.disable()
        super.onPause()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        recording?.stop()
        cameraExecutor.shutdown()
        super.onDestroy()
    }

    private fun bindCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener(Runnable {
            try {
                bindUseCases(future.get())
            } catch (e: Exception) {
                toast("Kamera tidak bisa dibuka")
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun bindUseCases(provider: ProcessCameraProvider) {
        val selector = if (CameraSession.facing == "user") {
            CameraSelector.DEFAULT_FRONT_CAMERA
        } else {
            CameraSelector.DEFAULT_BACK_CAMERA
        }

        if (isVideo) {
            val preview = Preview.Builder()
                .setTargetAspectRatio(AspectRatio.RATIO_16_9)
                .build()
            preview.setSurfaceProvider(previewView.surfaceProvider)
            val recorder = Recorder.Builder()
                .setQualitySelector(
                    QualitySelector.from(
                        Quality.HD,
                        FallbackStrategy.lowerQualityOrHigherThan(Quality.SD)
                    )
                )
                .build()
            // 2 = MIRROR_MODE_ON_FRONT_ONLY: video kamera depan dicerminkan seperti preview
            val vc = VideoCapture.Builder<Recorder>(recorder)
                .setMirrorMode(2)
                .build()
            vc.targetRotation = currentRotation
            provider.unbindAll()
            provider.bindToLifecycle(this, selector, preview, vc)
            videoCapture = vc
            imageCapture = null
        } else {
            val preview = Preview.Builder().build()
            preview.setSurfaceProvider(previewView.surfaceProvider)
            val capture = ImageCapture.Builder()
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                .build()
            val lock = CameraSession.rotationLock
            capture.targetRotation = if (lock != null) lock else currentRotation
            provider.unbindAll()
            provider.bindToLifecycle(this, selector, preview, capture)
            imageCapture = capture
            videoCapture = null
        }
    }

    private fun onFlip() {
        if (busy || recording != null) return
        CameraSession.facing = if (CameraSession.facing == "user") "environment" else "user"
        bindCamera()
    }

    private fun onShutter() {
        if (isVideo) {
            if (recording != null) {
                stopRecording()
            } else if (!busy) {
                busy = true
                startRecording()
            }
            return
        }
        if (busy) return
        busy = true
        shutterView.alpha = 0.5f
        runCountdown(3)
    }

    // ---------------- VIDEO ----------------

    @SuppressLint("MissingPermission")
    private fun startRecording() {
        val vc = videoCapture
        if (vc == null) {
            toast("Kamera belum siap")
            busy = false
            return
        }
        try {
            val dir = File(cacheDir, "snapin_videos")
            dir.mkdirs()
            val old = dir.listFiles()
            if (old != null) {
                for (f in old) f.delete()
            }
            val file = File(dir, "snapin_" + System.currentTimeMillis() + ".mp4")
            val opts = FileOutputOptions.Builder(file).build()
            var pending = vc.output.prepareRecording(this, opts)
            if (hasAudioPermission()) {
                pending = pending.withAudioEnabled()
            }
            vc.targetRotation = currentRotation
            // kunci layar selama merekam supaya activity tidak dibuat ulang saat HP diputar
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LOCKED
            recording = pending.start(
                ContextCompat.getMainExecutor(this),
                Consumer<VideoRecordEvent> { event -> onVideoEvent(event, file) }
            )
            setShutterRecording(true)
            recordStartAt = SystemClock.elapsedRealtime()
            counterText.text = "REC 00:00"
            handler.postDelayed(tick, 250)
        } catch (e: Exception) {
            toast("Gagal memulai rekaman")
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR
            recording = null
            busy = false
        }
    }

    private fun stopRecording() {
        handler.removeCallbacks(tick)
        shutterView.alpha = 0.5f
        counterText.text = "Menyimpan video..."
        recording?.stop()
    }

    private fun onVideoEvent(event: VideoRecordEvent, file: File) {
        if (event is VideoRecordEvent.Finalize) {
            handler.removeCallbacks(tick)
            recording = null
            if (isDestroyed) return
            val ok = file.exists() && (!event.hasError() || file.length() > 50000)
            if (ok) {
                CameraSession.videoPath = file.absolutePath
                setResult(RESULT_OK)
                finish()
            } else {
                toast("Gagal merekam video, coba lagi")
                requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR
                setShutterRecording(false)
                updateCounter()
                resetShutter()
            }
        }
    }

    // ---------------- FOTO ----------------

    private fun runCountdown(n: Int) {
        if (n <= 0) {
            countText.visibility = View.GONE
            takePhoto()
            return
        }
        countText.text = n.toString()
        countText.visibility = View.VISIBLE
        handler.postDelayed({ runCountdown(n - 1) }, 800)
    }

    private fun resetShutter() {
        busy = false
        shutterView.alpha = 1f
    }

    private fun takePhoto() {
        val capture = imageCapture
        if (capture == null) {
            toast("Kamera belum siap")
            resetShutter()
            return
        }
        val front = CameraSession.facing == "user"
        val rot = capture.targetRotation
        capture.takePicture(cameraExecutor, object : ImageCapture.OnImageCapturedCallback() {
            override fun onCaptureSuccess(image: ImageProxy) {
                val result: String? = try {
                    processImage(image, front)
                } catch (e: Exception) {
                    null
                } catch (e: OutOfMemoryError) {
                    null
                } finally {
                    image.close()
                }
                runOnUiThread { onShot(result, rot) }
            }

            override fun onError(exception: ImageCaptureException) {
                runOnUiThread { onShot(null, rot) }
            }
        })
    }

    private fun onShot(dataUrl: String?, rot: Int) {
        if (dataUrl == null) {
            toast("Gagal mengambil foto, coba lagi")
            resetShutter()
            return
        }
        flashView.alpha = 1f
        flashView.animate().alpha(0f).setDuration(320).start()

        if (CameraSession.rotationLock == null) {
            CameraSession.rotationLock = rot
            CameraSession.landscape = (rot == Surface.ROTATION_90 || rot == Surface.ROTATION_270)
        }
        CameraSession.photos.add(dataUrl)
        updateCounter()

        if (CameraSession.photos.size >= CameraSession.count) {
            handler.postDelayed({
                setResult(RESULT_OK)
                finish()
            }, 450)
        } else {
            handler.postDelayed({ resetShutter() }, 700)
        }
    }

    /** Putar sesuai sensor, potong ke rasio, kecilkan, cerminkan kamera depan. */
    private fun processImage(image: ImageProxy, front: Boolean): String {
        val src = image.toBitmap()
        val deg = image.imageInfo.rotationDegrees
        var bmp: Bitmap = src
        if (deg != 0) {
            val m = Matrix()
            m.postRotate(deg.toFloat())
            bmp = Bitmap.createBitmap(src, 0, 0, src.width, src.height, m, true)
            if (bmp !== src) src.recycle()
        }

        val s = CameraSession
        val portraitAr = s.pw.toFloat() / s.ph.toFloat()
        val targetAr = if (bmp.width >= bmp.height) 1f / portraitAr else portraitAr
        val srcAr = bmp.width.toFloat() / bmp.height.toFloat()
        var cw = bmp.width
        var ch = bmp.height
        if (srcAr > targetAr) {
            cw = (bmp.height * targetAr).toInt()
        } else {
            ch = (bmp.width / targetAr).toInt()
        }
        cw = max(1, cw)
        ch = max(1, ch)
        val cx = (bmp.width - cw) / 2
        val cy = (bmp.height - ch) / 2
        val cropped = Bitmap.createBitmap(bmp, cx, cy, cw, ch)
        if (cropped !== bmp) bmp.recycle()

        val longSide = max(cw, ch)
        var out: Bitmap = cropped
        if (longSide > MAX_SIDE) {
            val scale = MAX_SIDE.toFloat() / longSide.toFloat()
            val nw = max(1, (cw * scale).toInt())
            val nh = max(1, (ch * scale).toInt())
            out = Bitmap.createScaledBitmap(cropped, nw, nh, true)
            if (out !== cropped) cropped.recycle()
        }

        if (front) {
            val mm = Matrix()
            mm.postScale(-1f, 1f)
            val mirrored = Bitmap.createBitmap(out, 0, 0, out.width, out.height, mm, true)
            if (mirrored !== out) out.recycle()
            out = mirrored
        }

        val bos = ByteArrayOutputStream()
        out.compress(Bitmap.CompressFormat.JPEG, 90, bos)
        out.recycle()
        return "data:image/jpeg;base64," + Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP)
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
    }

    private companion object {
        const val MAX_SIDE = 1600
        const val MAX_VIDEO_SECONDS = 30
        val CREAM: Int = Color.parseColor("#FFF7F2")
        val PLUM: Int = Color.parseColor("#3B2447")
        val PINK: Int = Color.parseColor("#F76A9E")
        val RED: Int = Color.parseColor("#EF4444")
    }
}
