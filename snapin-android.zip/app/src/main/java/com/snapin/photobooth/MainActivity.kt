package com.snapin.photobooth

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.webkit.WebViewAssetLoader

/**
 * Snapin Photobooth — Android shell.
 *
 * The whole app (UI, filters, frames, stickers, layout, video, assets)
 * is the original single-file web app served from app assets over a
 * secure https:// origin (required for getUserMedia). The one piece the
 * web platform could never do reliably — reading the phone's physical
 * tilt — is provided natively by [TiltBridge] and injected into the page
 * as window.SnapinNative.getTilt(), using the OS-level fused gravity
 * sensor (the same source the built-in camera app uses).
 */
class MainActivity : ComponentActivity() {

    private lateinit var webView: WebView
    private lateinit var tiltBridge: TiltBridge
    private var pendingRequest: PermissionRequest? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this)
        setContentView(webView)
        WebView.setWebContentsDebuggingEnabled(true)

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true          // required for IndexedDB (My Assets)
            databaseEnabled = true
            mediaPlaybackRequiresUserGesture = false
            loadWithOverviewMode = true
            useWideViewPort = true
        }

        tiltBridge = TiltBridge(this)
        webView.addJavascriptInterface(tiltBridge, "SnapinNative")

        // Serve the web app over a secure origin so getUserMedia is allowed.
        val assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView,
                request: WebResourceRequest
            ): WebResourceResponse? = assetLoader.shouldInterceptRequest(request.url)
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest) {
                val needsCam = request.resources.contains(PermissionRequest.RESOURCE_VIDEO_CAPTURE)
                val needsMic = request.resources.contains(PermissionRequest.RESOURCE_AUDIO_CAPTURE)
                val ok = (!needsCam || hasPermission(Manifest.permission.CAMERA)) &&
                        (!needsMic || hasPermission(Manifest.permission.RECORD_AUDIO))
                if (ok) request.grant(request.resources)
                else {
                    pendingRequest = request
                    ensurePermissions()
                }
            }

            override fun onPermissionRequestCanceled(request: PermissionRequest) {
                if (pendingRequest === request) pendingRequest = null
            }
        }

        webView.loadUrl("https://appassets.androidplatform.net/assets/www/index.html")
        ensurePermissions()
    }

    private fun hasPermission(p: String) =
        ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    private fun ensurePermissions() {
        val missing = mutableListOf<String>()
        if (!hasPermission(Manifest.permission.CAMERA)) missing += Manifest.permission.CAMERA
        if (!hasPermission(Manifest.permission.RECORD_AUDIO)) missing += Manifest.permission.RECORD_AUDIO
        if (missing.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, missing.toTypedArray(), REQ_PERMISSIONS)
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != REQ_PERMISSIONS) return
        pendingRequest?.let { req ->
            val ok = req.resources.all { res ->
                when (res) {
                    PermissionRequest.RESOURCE_VIDEO_CAPTURE -> hasPermission(Manifest.permission.CAMERA)
                    PermissionRequest.RESOURCE_AUDIO_CAPTURE -> hasPermission(Manifest.permission.RECORD_AUDIO)
                    else -> true
                }
            }
            if (ok) req.grant(req.resources) else req.deny()
            pendingRequest = null
        }
    }

    override fun onResume() {
        super.onResume()
        tiltBridge.start()
    }

    override fun onPause() {
        tiltBridge.stop()
        super.onPause()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack()
        else super.onBackPressed()
    }

    override fun onDestroy() {
        webView.destroy()
        super.onDestroy()
    }

    private companion object {
        const val REQ_PERMISSIONS = 1001
    }
}
