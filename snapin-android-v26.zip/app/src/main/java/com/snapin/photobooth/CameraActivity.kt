package com.snapin.photobooth

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CaptureRequest
import android.util.Range
import androidx.camera.camera2.interop.Camera2Interop
import androidx.camera.camera2.interop.ExperimentalCamera2Interop
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Base64
import android.util.TypedValue
import android.view.Gravity
import android.view.OrientationEventListener
import android.view.TextureView
import android.view.Surface
import android.view.View
import android.view.WindowManager
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.AspectRatio
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.FallbackStrategy
import androidx.camera.video.FileOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.core.util.Consumer
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.max
import kotlin.math.min

/**
 * Layar kamera native (CameraX / Camera2) untuk foto dan video. Rotasi diurus
 * lewat metadata kamera seperti aplikasi kamera bawaan.
 */
class CameraActivity : ComponentActivity() {

    private lateinit var previewView: PreviewView
    private lateinit var countText: TextView
    private lateinit var counterText: TextView
    private lateinit var flashView: View
    private lateinit var shutterView: View
    private var filterRow: LinearLayout? = null
    private var camera: Camera? = null
    private var landscapeUi = false
    private lateinit var flashPill: FrameLayout      // tombol ikon flash (vektor)
    private lateinit var timerPill: FrameLayout      // tombol ikon timer (vektor) + angka kecil
    private lateinit var timerBadge: TextView
    private lateinit var liveBtn: FrameLayout        // tombol ikon foto live
    private var zoomRow: LinearLayout? = null
    private lateinit var screenFlash: View

    private var imageCapture: ImageCapture? = null
    private var videoCapture: VideoCapture<Recorder>? = null
    private var recording: Recording? = null
    private var recordStartAt = 0L

    private var currentRotation = Surface.ROTATION_0
    private var busy = false
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var cameraExecutor: ExecutorService
    private var orientationListener: OrientationEventListener? = null

    private val isVideo: Boolean
        get() = CameraSession.mode == "video"

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { _ ->
            if (hasCameraPermission()) {
                bindCamera()
            } else {
                toast("Izin kamera ditolak. Aktifkan izin kamera pada pengaturan perangkat.")
                finish()
            }
        }

    private val tick = object : Runnable {
        override fun run() {
            val s = ((SystemClock.elapsedRealtime() - recordStartAt) / 1000).toInt()
            counterText.text = "REC " + two(s / 60) + ":" + two(s % 60)
            if (s >= MAX_VIDEO_SECONDS) {
                stopRecording()
                return
            }
            handler.postDelayed(this, 250)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // orientasi yang dipilih di Setup: Tegak / Landscape / Auto (ikut HP)
        requestedOrientation = sessionOrientation()
        cameraExecutor = Executors.newSingleThreadExecutor()
        buildUi()
        setupOrientationListener()
        if (hasCameraPermission()) {
            bindCamera()
        } else if (isVideo) {
            permissionLauncher.launch(arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO))
        } else {
            permissionLauncher.launch(arrayOf(Manifest.permission.CAMERA))
        }
    }

    private fun sessionOrientation(): Int = when (CameraSession.orient) {
        "portrait" -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
        "landscape" -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        else -> ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR
    }

    private fun hasCameraPermission(): Boolean {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) ==
            PackageManager.PERMISSION_GRANTED
    }

    private fun hasAudioPermission(): Boolean {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
    }

    private fun two(n: Int): String {
        return if (n < 10) "0" + n else n.toString()
    }

    private fun dp(v: Int): Int {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics
        ).toInt()
    }

    private fun circleButton(iconRes: Int): ImageView {
        val v = ImageView(this)
        val bg = GradientDrawable()
        bg.shape = GradientDrawable.OVAL
        bg.setColor(Color.WHITE)
        v.background = bg
        v.setImageResource(iconRes)
        v.setPadding(dp(10), dp(10), dp(10), dp(10))
        v.elevation = dp(3).toFloat()
        v.setColorFilter(PLUM)
        return v
    }

    private fun buildUi() {
        val dm = resources.displayMetrics
        val sw = dm.widthPixels
        val sh = dm.heightPixels
        val landscape = sw > sh
        landscapeUi = landscape
        val s = CameraSession
        val spw = if (isVideo) 9 else s.pw
        val sph = if (isVideo) 16 else s.ph
        val portraitAr = spw.toFloat() / sph.toFloat()
        val boxAr = if (landscape) 1f / portraitAr else portraitAr

        // Posisi tegak: pratinjau dibuat selebar/setinggi mungkin (seperti kamera bawaan),
        // hanya menyisakan ruang untuk tombol atas dan tombol jepret di bawah.
        val availW = if (landscape) sw - dp(185) else sw - dp(4)
        val availH = if (landscape) sh - dp(8) else sh - dp(60) - dp(150)
        var bw = availW
        var bh = (bw / boxAr).toInt()
        if (bh > availH) {
            bh = availH
            bw = (bh * boxAr).toInt()
        }

        val root = FrameLayout(this)
        root.setBackgroundColor(CREAM)

        // kotak preview
        val box = FrameLayout(this)
        val boxBg = GradientDrawable()
        boxBg.setColor(Color.BLACK)
        boxBg.cornerRadius = dp(24).toFloat()
        box.background = boxBg
        box.clipToOutline = true
        val boxLp = FrameLayout.LayoutParams(bw, bh)
        var landscapeRow: LinearLayout? = null
        if (landscape) {
            // area preview = ruang di kiri panel kontrol; kotak preview selalu di TENGAH area itu
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            val area = FrameLayout(this)
            boxLp.gravity = Gravity.CENTER
            area.addView(box, boxLp)
            row.addView(area, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
            root.addView(
                row,
                FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            )
            landscapeRow = row
        } else {
            boxLp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            boxLp.topMargin = dp(60) + maxOf(0, (availH - bh) / 2)
            root.addView(box, boxLp)
        }

        previewView = PreviewView(this)
        previewView.implementationMode = PreviewView.ImplementationMode.COMPATIBLE
        previewView.scaleType = PreviewView.ScaleType.FILL_CENTER
        box.addView(
            previewView,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )

        flashView = View(this)
        flashView.setBackgroundColor(Color.WHITE)
        flashView.alpha = 0f
        box.addView(
            flashView,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )

        countText = TextView(this)
        countText.textSize = 96f
        countText.setTextColor(Color.WHITE)
        countText.typeface = Typeface.DEFAULT_BOLD
        countText.setShadowLayer(12f, 0f, 4f, Color.argb(153, 0, 0, 0))
        countText.visibility = View.GONE
        box.addView(
            countText,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER
            )
        )

        // strip filter (geser kiri-kanan), hanya untuk foto
        if (!isVideo) {
            val scroll = HorizontalScrollView(this)
            scroll.isHorizontalScrollBarEnabled = false
            scroll.overScrollMode = View.OVER_SCROLL_NEVER
            scroll.setBackgroundColor(Color.argb(70, 0, 0, 0))
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.setPadding(dp(8), dp(8), dp(8), dp(8))
            for (i in FILTER_NAMES.indices) {
                val chip = TextView(this)
                chip.text = FILTER_NAMES[i]
                chip.textSize = 13f
                chip.typeface = Typeface.DEFAULT_BOLD
                chip.setPadding(dp(16), dp(8), dp(16), dp(8))
                chip.setOnClickListener {
                    CameraSession.filter = i
                    updateFilterChips()
                    applyPreviewFilter()
                }
                val clp = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
                )
                clp.leftMargin = dp(4)
                clp.rightMargin = dp(4)
                row.addView(chip, clp)
            }
            filterRow = row
            scroll.addView(
                row,
                FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            )
            val scrollLp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            scrollLp.gravity = Gravity.BOTTOM
            box.addView(scroll, scrollLp)
            updateFilterChips()
        }

        val wrap = ViewGroup.LayoutParams.WRAP_CONTENT

        // baris ikon di tengah atas preview: flash (kiri) - foto live (tengah) - timer (kanan). Semua ikon vektor, bukan teks.
        flashPill = toolCircle(R.drawable.ic_flash_off, "Flash")
        flashPill.setOnClickListener { cycleFlash() }

        CameraSession.timer = getSharedPreferences("snapin_prefs", MODE_PRIVATE).getInt("timer", 3)
        if (CameraSession.timer !in TIMERS) CameraSession.timer = 3
        timerPill = toolCircle(R.drawable.ic_timer, "Timer")
        timerBadge = TextView(this)
        timerBadge.textSize = 10f
        timerBadge.typeface = Typeface.DEFAULT_BOLD
        timerBadge.setTextColor(Color.WHITE)
        timerBadge.gravity = Gravity.CENTER
        val badgeBg = GradientDrawable()
        badgeBg.shape = GradientDrawable.OVAL
        badgeBg.setColor(Color.parseColor("#F76A9E"))
        timerBadge.background = badgeBg
        val badgeLp = FrameLayout.LayoutParams(dp(18), dp(18))
        badgeLp.gravity = Gravity.BOTTOM or Gravity.END
        timerPill.addView(timerBadge, badgeLp)
        timerPill.setOnClickListener { cycleTimer() }

        liveBtn = toolCircle(R.drawable.ic_live_off, "Foto live")
        liveBtn.setOnClickListener { switchToLiveCamera() }

        val tools = LinearLayout(this)
        tools.orientation = LinearLayout.HORIZONTAL
        tools.gravity = Gravity.CENTER_VERTICAL
        val toolViews = listOf<View>(flashPill, liveBtn, timerPill)
        for ((i, v) in toolViews.withIndex()) {
            val tlp = LinearLayout.LayoutParams(dp(42), dp(42))
            if (i > 0) tlp.leftMargin = dp(16)
            tools.addView(v, tlp)
        }
        val toolsLp = FrameLayout.LayoutParams(wrap, wrap)
        toolsLp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        toolsLp.topMargin = dp(12)
        box.addView(tools, toolsLp)
        liveBtn.visibility = if (isVideo) View.GONE else View.VISIBLE
        timerPill.visibility = if (isVideo) View.GONE else View.VISIBLE
        updateFlashLabel()
        updateTimerLabel()

        // tombol zoom 1x / 2x / 5x (tengah bawah preview)
        val zrow = LinearLayout(this)
        zrow.orientation = LinearLayout.HORIZONTAL
        for (z in ZOOMS) {
            val chip = TextView(this)
            chip.text = zoomLabel(z)
            chip.textSize = 13f
            chip.typeface = Typeface.DEFAULT_BOLD
            chip.gravity = Gravity.CENTER
            chip.setOnClickListener { setZoom(z) }
            val clp = LinearLayout.LayoutParams(dp(46), dp(34))
            clp.leftMargin = dp(4)
            clp.rightMargin = dp(4)
            zrow.addView(chip, clp)
        }
        zoomRow = zrow
        val zoomLp = FrameLayout.LayoutParams(wrap, wrap)
        zoomLp.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        zoomLp.bottomMargin = if (isVideo) dp(14) else dp(68)
        box.addView(zrow, zoomLp)
        updateZoomChips()

        // ---- kontrol utama ----
        val back = circleButton(R.drawable.ic_back)
        back.setOnClickListener { finish() }
        val flip = circleButton(R.drawable.ic_flip)
        flip.setOnClickListener { onFlip() }

        // penghitung foto / timer video
        counterText = TextView(this)
        counterText.setTextColor(PLUM)
        counterText.textSize = 15f
        counterText.typeface = Typeface.DEFAULT_BOLD
        counterText.setPadding(dp(12), dp(8), dp(12), dp(8))
        val pill = GradientDrawable()
        pill.setColor(Color.WHITE)
        pill.cornerRadius = dp(20).toFloat()
        counterText.background = pill
        updateCounter()

        // tombol jepret / rekam
        shutterView = View(this)
        shutterView.background = shutterDrawable(false)
        shutterView.setOnClickListener { onShutter() }

        if (landscape) {
            // panel kanan rapi: semua tombol sejajar di satu garis tengah
            val panel = FrameLayout(this)
            val backLp = FrameLayout.LayoutParams(dp(44), dp(44))
            backLp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            backLp.topMargin = dp(14)
            panel.addView(back, backLp)
            val counterLp = FrameLayout.LayoutParams(wrap, wrap)
            counterLp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            counterLp.topMargin = dp(70)
            panel.addView(counterText, counterLp)
            val shutterLp = FrameLayout.LayoutParams(dp(76), dp(76))
            shutterLp.gravity = Gravity.CENTER
            panel.addView(shutterView, shutterLp)
            val flipLp = FrameLayout.LayoutParams(dp(44), dp(44))
            flipLp.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            flipLp.bottomMargin = dp(14)
            panel.addView(flip, flipLp)
            val rowRef = landscapeRow
            if (rowRef != null) {
                rowRef.addView(panel, LinearLayout.LayoutParams(dp(120), ViewGroup.LayoutParams.MATCH_PARENT))
            }
        } else {
            val backLp = FrameLayout.LayoutParams(dp(44), dp(44))
            backLp.gravity = Gravity.TOP or Gravity.START
            backLp.topMargin = dp(16)
            backLp.leftMargin = dp(16)
            root.addView(back, backLp)
            val flipLp = FrameLayout.LayoutParams(dp(44), dp(44))
            flipLp.gravity = Gravity.TOP or Gravity.END
            flipLp.topMargin = dp(16)
            flipLp.rightMargin = dp(16)
            root.addView(flip, flipLp)
            val counterLp = FrameLayout.LayoutParams(wrap, wrap)
            counterLp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            counterLp.topMargin = dp(22)
            root.addView(counterText, counterLp)
            val shutterLp = FrameLayout.LayoutParams(dp(76), dp(76))
            shutterLp.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            shutterLp.bottomMargin = dp(52)
            root.addView(shutterView, shutterLp)
        }

        // lapisan putih penuh untuk flash layar (kamera depan)
        screenFlash = View(this)
        screenFlash.setBackgroundColor(Color.WHITE)
        screenFlash.alpha = 0f
        screenFlash.visibility = View.GONE
        root.addView(
            screenFlash,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )

        setContentView(root)
    }

    private fun updateFilterChips() {
        val row = filterRow ?: return
        for (j in 0 until row.childCount) {
            val chip = row.getChildAt(j) as TextView
            val bg = GradientDrawable()
            bg.cornerRadius = dp(18).toFloat()
            if (j == CameraSession.filter) {
                bg.setColor(PINK)
                chip.setTextColor(Color.WHITE)
            } else {
                bg.setColor(Color.argb(215, 255, 255, 255))
                chip.setTextColor(PLUM)
            }
            chip.background = bg
        }
    }

    private fun m(vararg v: Float): ColorMatrix {
        return ColorMatrix(v)
    }

    private fun contrastMatrix(c: Float): ColorMatrix {
        val t = 128f * (1f - c)
        return m(
            c, 0f, 0f, 0f, t,
            0f, c, 0f, 0f, t,
            0f, 0f, c, 0f, t,
            0f, 0f, 0f, 1f, 0f
        )
    }

    /** Matriks warna tiap filter. null = Normal. */
    private fun filterMatrix(index: Int): ColorMatrix? {
        return when (index) {
            1 -> m( // Pink
                1.08f, 0f, 0f, 0f, 8f,
                0f, 0.97f, 0f, 0f, 4f,
                0f, 0f, 1.05f, 0f, 10f,
                0f, 0f, 0f, 1f, 0f
            )
            2 -> m( // Warm
                1.10f, 0f, 0f, 0f, 10f,
                0f, 1.02f, 0f, 0f, 4f,
                0f, 0f, 0.88f, 0f, 0f,
                0f, 0f, 0f, 1f, 0f
            )
            3 -> m( // Cool
                0.92f, 0f, 0f, 0f, 0f,
                0f, 1.0f, 0f, 0f, 4f,
                0f, 0f, 1.10f, 0f, 8f,
                0f, 0f, 0f, 1f, 0f
            )
            4 -> { // B&W
                val bw = ColorMatrix()
                bw.setSaturation(0f)
                bw.postConcat(contrastMatrix(1.08f))
                bw
            }
            5 -> m( // Sepia
                0.393f, 0.769f, 0.189f, 0f, 0f,
                0.349f, 0.686f, 0.168f, 0f, 0f,
                0.272f, 0.534f, 0.131f, 0f, 0f,
                0f, 0f, 0f, 1f, 0f
            )
            6 -> { // Vivid
                val v = ColorMatrix()
                v.setSaturation(1.45f)
                v.postConcat(contrastMatrix(1.08f))
                v
            }
            7 -> { // Fade
                val f = ColorMatrix()
                f.setSaturation(0.8f)
                f.postConcat(
                    m(
                        0.92f, 0f, 0f, 0f, 24f,
                        0f, 0.92f, 0f, 0f, 24f,
                        0f, 0f, 0.92f, 0f, 24f,
                        0f, 0f, 0f, 1f, 0f
                    )
                )
                f
            }
            8 -> { // Vintage
                val vt = ColorMatrix()
                vt.setSaturation(0.7f)
                vt.postConcat(
                    m(
                        1.08f, 0f, 0f, 0f, 12f,
                        0f, 1.0f, 0f, 0f, 6f,
                        0f, 0f, 0.86f, 0f, 0f,
                        0f, 0f, 0f, 1f, 0f
                    )
                )
                vt.postConcat(contrastMatrix(1.06f))
                vt
            }
            else -> null
        }
    }

    private fun findTextureView(v: View): TextureView? {
        if (v is TextureView) return v
        if (v is ViewGroup) {
            for (i in 0 until v.childCount) {
                val r = findTextureView(v.getChildAt(i))
                if (r != null) return r
            }
        }
        return null
    }

    /** Terapkan filter ke preview langsung (TextureView di dalam PreviewView). */
    private fun applyPreviewFilter() {
        if (isVideo) return
        val tv = findTextureView(previewView) ?: return
        val cm = filterMatrix(CameraSession.filter)
        if (cm == null) {
            tv.setLayerPaint(null)
        } else {
            val paint = Paint()
            paint.colorFilter = ColorMatrixColorFilter(cm)
            tv.setLayerPaint(paint)
        }
    }

    private fun scheduleFilterApply() {
        if (isVideo) return
        handler.postDelayed({ applyPreviewFilter() }, 350)
        handler.postDelayed({ applyPreviewFilter() }, 900)
        handler.postDelayed({ applyPreviewFilter() }, 1800)
    }

    private fun applyFilterToBitmap(src: Bitmap): Bitmap {
        val cm = filterMatrix(CameraSession.filter) ?: return src
        val result = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(result)
        val paint = Paint()
        paint.colorFilter = ColorMatrixColorFilter(cm)
        canvas.drawBitmap(src, 0f, 0f, paint)
        src.recycle()
        return result
    }

    private var evIdx = 0
    private var evBase = 0
    private var brightenToken = 0

    /** Naikkan kecerahan (EV) supaya video tidak gelap. Mengembalikan indeks yang dipakai. */
    private fun boostExposure(cam: Camera, evStops: Float): Int {
        try {
            val st = cam.cameraInfo.exposureState
            if (!st.isExposureCompensationSupported) return 0
            val step = st.exposureCompensationStep.toFloat()
            if (step <= 0f) return 0
            val range = st.exposureCompensationRange
            var idx = Math.round(evStops / step)
            idx = max(range.lower, min(range.upper, idx))
            cam.cameraControl.setExposureCompensationIndex(idx)
            return idx
        } catch (e: Exception) {
            return 0
        }
    }

    /** Rata-rata kecerahan (0-255) dari gambar preview saat ini, atau -1 kalau belum bisa dibaca. */
    private fun previewLuma(): Int {
        val bmp = try { previewView.bitmap } catch (e: Exception) { null } ?: return -1
        try {
            val w = bmp.width
            val h = bmp.height
            if (w < 8 || h < 8) return -1
            var sum = 0L
            var n = 0
            val stepX = max(1, w / 24)
            val stepY = max(1, h / 24)
            var y = stepY / 2
            while (y < h) {
                var x = stepX / 2
                while (x < w) {
                    val p = bmp.getPixel(x, y)
                    sum += (Color.red(p) * 299 + Color.green(p) * 587 + Color.blue(p) * 114) / 1000
                    n++
                    x += stepX
                }
                y += stepY
            }
            return if (n == 0) -1 else (sum / n).toInt()
        } finally {
            bmp.recycle()
        }
    }

    /**
     * Penyesuaian kecerahan otomatis untuk video: kalau preview terlalu gelap (kamera belakang sering begini),
     * naikkan kompensasi eksposur bertahap sampai cukup terang. Berhenti sendiri setelah beberapa kali cek.
     */
    private fun autoBrighten() {
        if (!isVideo) return
        val token = ++brightenToken
        var tries = 0
        val task = object : Runnable {
            override fun run() {
                if (token != brightenToken || isFinishing) return
                val cam = camera ?: return
                tries++
                try {
                    val st = cam.cameraInfo.exposureState
                    if (st.isExposureCompensationSupported) {
                        val range = st.exposureCompensationRange
                        val step = max(0.1f, st.exposureCompensationStep.toFloat())
                        val luma = previewLuma()
                        // penyesuaian kecil di sekitar eksposur normal (maksimal 1 EV ke atas atau ke bawah)
                        val stepsOne = max(1, Math.round(1.0f / step))
                        val hi = min(range.upper, evBase + stepsOne)
                        val lo = max(range.lower, evBase - stepsOne)
                        val inc = max(1, Math.round(0.5f / step))
                        if (luma in 0..60 && evIdx < hi) {
                            evIdx = min(hi, evIdx + inc)
                            cam.cameraControl.setExposureCompensationIndex(evIdx)
                        } else if (luma > 175 && evIdx > lo) {
                            evIdx = max(lo, evIdx - inc)
                            cam.cameraControl.setExposureCompensationIndex(evIdx)
                        }
                    }
                } catch (e: Exception) {
                    return
                }
                if (tries < 20) handler.postDelayed(this, 700)
            }
        }
        handler.postDelayed(task, 900)
    }

    private fun updateCounter() {
        if (isVideo) {
            counterText.text = if (landscapeUi) "Siap merekam" else "Siap merekam (maksimal 60 detik)"
            return
        }
        val total = CameraSession.count
        val n = min(CameraSession.photos.size + 1, total)
        counterText.text = "Foto " + n + "/" + total
    }

    /** Cincin putih + isi merah/pink. Saat merekam: isi jadi kotak kecil membulat di tengah cincin (seperti kamera bawaan). */
    private fun shutterDrawable(recording: Boolean): Drawable {
        val accent = if (isVideo) RED else PINK
        val outer = GradientDrawable()
        outer.shape = GradientDrawable.OVAL
        outer.setColor(Color.WHITE)
        outer.setStroke(dp(4), accent)
        val inner = GradientDrawable()
        if (recording) {
            inner.shape = GradientDrawable.RECTANGLE
            inner.cornerRadius = dp(7).toFloat()
        } else {
            inner.shape = GradientDrawable.OVAL
        }
        inner.setColor(accent)
        val layers = LayerDrawable(arrayOf<Drawable>(outer, inner))
        val inset = if (recording) dp(25) else dp(8)
        layers.setLayerInset(1, inset, inset, inset, inset)
        return layers
    }

    private fun setShutterRecording(on: Boolean) {
        shutterView.background = shutterDrawable(on)
        shutterView.animate().cancel()
        if (on) {
            // denyut halus supaya jelas sedang merekam
            shutterView.animate().scaleX(1.08f).scaleY(1.08f).setDuration(450).withEndAction { pulseShutter(false) }.start()
        } else {
            shutterView.scaleX = 1f
            shutterView.scaleY = 1f
        }
    }

    private fun recordingNow(): Boolean = recording != null

    private fun pulseShutter(up: Boolean) {
        if (!recordingNow()) return
        val t = if (up) 1.08f else 1f
        shutterView.animate().scaleX(t).scaleY(t).setDuration(450).withEndAction { pulseShutter(!up) }.start()
    }

    private fun setupOrientationListener() {
        orientationListener = object : OrientationEventListener(this) {
            override fun onOrientationChanged(orientation: Int) {
                if (orientation == OrientationEventListener.ORIENTATION_UNKNOWN) return
                val r = when {
                    orientation >= 315 || orientation < 45 -> Surface.ROTATION_0
                    orientation < 135 -> Surface.ROTATION_270
                    orientation < 225 -> Surface.ROTATION_180
                    else -> Surface.ROTATION_90
                }
                currentRotation = r
                if (CameraSession.rotationLock == null) {
                    imageCapture?.targetRotation = r
                }
                if (recording == null) {
                    videoCapture?.targetRotation = r
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        orientationListener?.enable()
    }

    override fun onPause() {
        orientationListener?.disable()
        super.onPause()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        recording?.stop()
        cameraExecutor.shutdown()
        super.onDestroy()
    }

    private fun bindCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener(Runnable {
            try {
                bindUseCases(future.get())
                scheduleFilterApply()
            } catch (e: Exception) {
                toast("Kamera tidak dapat dibuka")
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun bindUseCases(provider: ProcessCameraProvider) {
        val selector = if (CameraSession.facing == "user") {
            CameraSelector.DEFAULT_FRONT_CAMERA
        } else {
            CameraSelector.DEFAULT_BACK_CAMERA
        }

        if (isVideo) {
            bindVideo(provider, selector, 0)
            return
        } else {
            val preview = Preview.Builder().build()
            preview.setSurfaceProvider(previewView.surfaceProvider)
            val capture = ImageCapture.Builder()
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                .build()
            val lock = CameraSession.rotationLock
            capture.targetRotation = if (lock != null) lock else currentRotation
            provider.unbindAll()
            val cam = provider.bindToLifecycle(this, selector, preview, capture)
            camera = cam
            imageCapture = capture
            videoCapture = null
        }
        afterBind()
    }

    /** Rentang FPS target untuk kamera depan yang memungkinkan eksposur lebih lama (lebih terang di tempat gelap). */
    private fun lowLightFpsRange(): Range<Int>? {
        try {
            val cm = getSystemService(android.content.Context.CAMERA_SERVICE) as CameraManager
            for (id in cm.cameraIdList) {
                val ch = cm.getCameraCharacteristics(id)
                if (ch.get(CameraCharacteristics.LENS_FACING) != CameraCharacteristics.LENS_FACING_FRONT) continue
                val ranges = ch.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES) ?: continue
                var best: Range<Int>? = null
                for (r in ranges) {
                    if (r.upper in 24..30 && r.lower <= 15) {
                        if (best == null || r.lower < best.lower) best = r
                    }
                }
                if (best != null) return best
            }
        } catch (e: Exception) {
            // abaikan
        }
        return null
    }

    @androidx.annotation.OptIn(ExperimentalCamera2Interop::class)
    private fun applyFpsRange(pb: Preview.Builder, r: Range<Int>) {
        try {
            Camera2Interop.Extender(pb).setCaptureRequestOption(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, r)
        } catch (e: Exception) {
            // abaikan
        }
    }

    @androidx.annotation.OptIn(ExperimentalCamera2Interop::class)
    private fun applyFpsRange(vb: VideoCapture.Builder<Recorder>, r: Range<Int>) {
        try {
            Camera2Interop.Extender(vb).setCaptureRequestOption(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, r)
        } catch (e: Exception) {
            // abaikan
        }
    }

    private var bindToken = 0

    /**
     * Membuka kamera untuk video dengan beberapa tingkat cadangan. Kamera depan di sejumlah HP gagal
     * (layar hitam, wajah tidak tampil) bila memakai rasio 16:9, kualitas HD, atau mode cermin bawaan CameraX,
     * jadi: tingkat 0 = HD 16:9, tingkat 1 = SD tanpa rasio khusus, tingkat 2 = kualitas terendah.
     * Mode cermin bawaan tidak dipakai lagi. Bila preview tidak mengalir dalam beberapa detik, otomatis turun satu tingkat.
     */
    private fun bindVideo(provider: ProcessCameraProvider, selector: CameraSelector, level: Int) {
        val token = ++bindToken
        try {
            val pb = Preview.Builder()
            if (level == 0) pb.setTargetAspectRatio(AspectRatio.RATIO_16_9)
            val fpsRange = if (isFront() && level < 2) lowLightFpsRange() else null
            if (fpsRange != null) applyFpsRange(pb, fpsRange)
            val preview = pb.build()
            preview.setSurfaceProvider(previewView.surfaceProvider)
            val quality = when (level) {
                0 -> QualitySelector.from(
                    Quality.HD,
                    FallbackStrategy.lowerQualityOrHigherThan(Quality.SD)
                )
                1 -> QualitySelector.from(
                    Quality.SD,
                    FallbackStrategy.lowerQualityOrHigherThan(Quality.SD)
                )
                else -> QualitySelector.from(
                    Quality.LOWEST,
                    FallbackStrategy.higherQualityThan(Quality.LOWEST)
                )
            }
            val recorder = Recorder.Builder().setQualitySelector(quality).build()
            val vcb = VideoCapture.Builder<Recorder>(recorder)
            if (fpsRange != null) applyFpsRange(vcb, fpsRange)
            val vc = vcb.build()
            vc.targetRotation = currentRotation
            provider.unbindAll()
            val cam = provider.bindToLifecycle(this, selector, preview, vc)
            // eksposur awal normal (0 EV, sama seperti mode foto); autoBrighten hanya menyesuaikan sedikit kalau terlalu gelap / terlalu terang
            evIdx = boostExposure(cam, 0f)
            evBase = evIdx
            camera = cam
            videoCapture = vc
            imageCapture = null
            autoBrighten()
            afterBind()
            // pengawas: kalau gambar kamera belum tampil, coba tingkat berikutnya
            handler.postDelayed({
                if (token != bindToken || isFinishing || isDestroyed || recording != null) return@postDelayed
                val st = previewView.previewStreamState.value
                if (st != PreviewView.StreamState.STREAMING && level < 2) {
                    bindVideo(provider, selector, level + 1)
                }
            }, 2800)
        } catch (e: Exception) {
            if (level < 2) {
                bindVideo(provider, selector, level + 1)
            } else {
                toast("Kamera tidak dapat dibuka")
            }
        }
    }

    /** Terapkan lagi flash dan zoom setiap kali kamera dibuka / dibalik. */
    private fun afterBind() {
        refreshFlashUi()
        applyFlash()
        if (CameraSession.zoom != 1f) {
            setZoom(CameraSession.zoom)
        } else {
            updateZoomChips()
        }
    }

    private fun isFront(): Boolean {
        return CameraSession.facing == "user"
    }

    private fun toolCircle(res: Int, desc: String): FrameLayout {
        val f = FrameLayout(this)
        val bg = GradientDrawable()
        bg.shape = GradientDrawable.OVAL
        bg.setColor(Color.argb(130, 0, 0, 0))
        f.background = bg
        f.contentDescription = desc
        val iv = ImageView(this)
        iv.setImageResource(res)
        f.addView(iv, FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER))
        return f
    }

    private fun updateTimerLabel() {
        val t = CameraSession.timer
        (timerPill.getChildAt(0) as ImageView).setImageResource(if (t <= 0) R.drawable.ic_timer_off else R.drawable.ic_timer)
        timerBadge.text = if (t <= 0) "" else t.toString()
        timerBadge.visibility = if (t <= 0) View.GONE else View.VISIBLE
        timerPill.contentDescription = if (t <= 0) "Timer nonaktif" else "Timer " + t + " detik"
    }

    /** Foto live direkam lewat kamera web (butuh klip), jadi kamera native ditutup dan halaman membuka kamera web. */
    private fun switchToLiveCamera() {
        if (busy) return
        CameraSession.switchToLive = true
        setResult(Activity.RESULT_CANCELED)
        finish()
    }

    private fun cycleTimer() {
        if (busy) return
        val i = TIMERS.indexOf(CameraSession.timer)
        CameraSession.timer = TIMERS[(i + 1) % TIMERS.size]
        getSharedPreferences("snapin_prefs", MODE_PRIVATE).edit().putInt("timer", CameraSession.timer).apply()
        updateTimerLabel()
    }

    private fun cycleFlash() {
        val rearPhoto = !isVideo && !isFront()
        val cur = CameraSession.flash
        CameraSession.flash = if (rearPhoto) (cur + 1) % 3 else (if (cur == 1) 0 else 1)
        updateFlashLabel()
        applyFlash()
    }

    private fun updateFlashLabel() {
        val res = when (CameraSession.flash) {
            1 -> R.drawable.ic_flash_on
            2 -> R.drawable.ic_flash_auto
            else -> R.drawable.ic_flash_off
        }
        (flashPill.getChildAt(0) as ImageView).setImageResource(res)
        flashPill.contentDescription = when (CameraSession.flash) {
            1 -> "Flash aktif"
            2 -> "Flash otomatis"
            else -> "Flash nonaktif"
        }
    }

    /** Kamera belakang: lampu flash. Kamera depan (foto): flash layar. Video: lampu belakang saja. */
    private fun refreshFlashUi() {
        val cam = camera
        val hasUnit = cam != null && cam.cameraInfo.hasFlashUnit()
        val visible = if (isFront()) !isVideo else hasUnit
        flashPill.visibility = if (visible) View.VISIBLE else View.INVISIBLE
        if ((isVideo || isFront()) && CameraSession.flash == 2) {
            CameraSession.flash = 1
        }
        updateFlashLabel()
    }

    private fun applyFlash() {
        val rear = !isFront()
        val cap = imageCapture
        if (cap != null) {
            cap.flashMode = if (rear) {
                when (CameraSession.flash) {
                    1 -> ImageCapture.FLASH_MODE_ON
                    2 -> ImageCapture.FLASH_MODE_AUTO
                    else -> ImageCapture.FLASH_MODE_OFF
                }
            } else {
                ImageCapture.FLASH_MODE_OFF
            }
        }
        val cam = camera
        if (isVideo && cam != null) {
            try {
                cam.cameraControl.enableTorch(rear && CameraSession.flash == 1)
            } catch (e: Exception) {
                // abaikan
            }
        }
    }

    private fun zoomLabel(z: Float): String {
        return z.toInt().toString() + "\u00D7"
    }

    private fun updateZoomChips() {
        val row = zoomRow ?: return
        for (i in 0 until row.childCount) {
            val chip = row.getChildAt(i) as TextView
            val bg = GradientDrawable()
            bg.cornerRadius = dp(17).toFloat()
            if (ZOOMS[i] == CameraSession.zoom) {
                bg.setColor(PINK)
            } else {
                bg.setColor(Color.argb(130, 0, 0, 0))
            }
            chip.background = bg
            chip.setTextColor(Color.WHITE)
        }
    }

    private fun setZoom(z: Float) {
        val cam = camera
        val prev = CameraSession.zoom
        CameraSession.zoom = z
        updateZoomChips()
        if (cam == null) return
        val f = cam.cameraControl.setZoomRatio(z)
        f.addListener(Runnable {
            try {
                f.get()
            } catch (e: Exception) {
                CameraSession.zoom = prev
                updateZoomChips()
                toast("Zoom " + z.toInt() + "x tidak didukung kamera ini")
                try {
                    cam.cameraControl.setZoomRatio(prev)
                } catch (ex: Exception) {
                    // abaikan
                }
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun showScreenFlash() {
        val lp = window.attributes
        lp.screenBrightness = 1f
        window.attributes = lp
        screenFlash.visibility = View.VISIBLE
        screenFlash.animate().alpha(0.95f).setDuration(150).start()
    }

    private fun hideScreenFlash() {
        val lp = window.attributes
        lp.screenBrightness = WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
        window.attributes = lp
        screenFlash.animate().alpha(0f).setDuration(200).withEndAction {
            screenFlash.visibility = View.GONE
        }.start()
    }

    private fun onFlip() {
        if (busy || recording != null) return
        CameraSession.facing = if (CameraSession.facing == "user") "environment" else "user"
        CameraSession.zoom = 1f
        if (CameraSession.flash == 2) CameraSession.flash = 1
        bindCamera()
    }

    private fun onShutter() {
        if (isVideo) {
            if (recording != null) {
                stopRecording()
            } else if (!busy) {
                busy = true
                startRecording()
            }
            return
        }
        if (busy) return
        busy = true
        shutterView.alpha = 0.5f
        runCountdown(CameraSession.timer)
    }

    // ---------------- VIDEO ----------------

    @SuppressLint("MissingPermission")
    private fun startRecording() {
        val vc = videoCapture
        if (vc == null) {
            toast("Kamera belum siap digunakan")
            busy = false
            return
        }
        try {
            val dir = File(cacheDir, "snapin_videos")
            dir.mkdirs()
            val old = dir.listFiles()
            if (old != null) {
                for (f in old) f.delete()
            }
            val file = File(dir, "snapin_" + System.currentTimeMillis() + ".mp4")
            val opts = FileOutputOptions.Builder(file).build()
            var pending = vc.output.prepareRecording(this, opts)
            if (hasAudioPermission()) {
                pending = pending.withAudioEnabled()
            }
            vc.targetRotation = currentRotation
            // kunci layar selama merekam supaya activity tidak dibuat ulang saat HP diputar
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LOCKED
            recording = pending.start(
                ContextCompat.getMainExecutor(this),
                Consumer<VideoRecordEvent> { event -> onVideoEvent(event, file) }
            )
            setShutterRecording(true)
            recordStartAt = SystemClock.elapsedRealtime()
            counterText.text = "REC 00:00"
            handler.postDelayed(tick, 250)
        } catch (e: Exception) {
            toast("Gagal memulai perekaman")
            requestedOrientation = sessionOrientation()
            recording = null
            busy = false
        }
    }

    private fun stopRecording() {
        handler.removeCallbacks(tick)
        shutterView.alpha = 0.5f
        counterText.text = "Menyimpan video..."
        recording?.stop()
    }

    private fun onVideoEvent(event: VideoRecordEvent, file: File) {
        if (event is VideoRecordEvent.Finalize) {
            handler.removeCallbacks(tick)
            recording = null
            if (isDestroyed) return
            val ok = file.exists() && (!event.hasError() || file.length() > 50000)
            if (ok) {
                CameraSession.videoPath = file.absolutePath
                setResult(RESULT_OK)
                finish()
            } else {
                toast("Gagal merekam video. Silakan coba lagi.")
                requestedOrientation = sessionOrientation()
                setShutterRecording(false)
                updateCounter()
                resetShutter()
            }
        }
    }

    // ---------------- FOTO ----------------

    private fun runCountdown(n: Int) {
        if (n <= 0) {
            countText.visibility = View.GONE
            takePhoto()
            return
        }
        countText.text = n.toString()
        countText.visibility = View.VISIBLE
        handler.postDelayed({ runCountdown(n - 1) }, 1000)
    }

    private fun resetShutter() {
        busy = false
        shutterView.alpha = 1f
    }

    private fun takePhoto() {
        val capture = imageCapture
        if (capture == null) {
            toast("Kamera belum siap digunakan")
            resetShutter()
            return
        }
        val front = CameraSession.facing == "user"
        if (front && CameraSession.flash == 1) {
            showScreenFlash()
            handler.postDelayed({ performCapture(capture, front) }, 450)
        } else {
            performCapture(capture, front)
        }
    }

    private fun performCapture(capture: ImageCapture, front: Boolean) {
        val rot = capture.targetRotation
        capture.takePicture(cameraExecutor, object : ImageCapture.OnImageCapturedCallback() {
            override fun onCaptureSuccess(image: ImageProxy) {
                val result: String? = try {
                    processImage(image, front)
                } catch (e: Exception) {
                    null
                } catch (e: OutOfMemoryError) {
                    null
                } finally {
                    image.close()
                }
                runOnUiThread { onShot(result, rot) }
            }

            override fun onError(exception: ImageCaptureException) {
                runOnUiThread { onShot(null, rot) }
            }
        })
    }

    private fun onShot(dataUrl: String?, rot: Int) {
        if (screenFlash.visibility == View.VISIBLE) hideScreenFlash()
        if (dataUrl == null) {
            toast("Gagal mengambil foto. Silakan coba lagi.")
            resetShutter()
            return
        }
        flashView.alpha = 1f
        flashView.animate().alpha(0f).setDuration(320).start()

        if (CameraSession.rotationLock == null) {
            CameraSession.rotationLock = rot
            CameraSession.landscape = (rot == Surface.ROTATION_90 || rot == Surface.ROTATION_270)
        }
        CameraSession.photos.add(dataUrl)
        updateCounter()

        if (CameraSession.photos.size >= CameraSession.count) {
            handler.postDelayed({
                setResult(RESULT_OK)
                finish()
            }, 450)
        } else {
            handler.postDelayed({ resetShutter() }, 700)
        }
    }

    /** Putar sesuai sensor, potong ke rasio, kecilkan, cerminkan kamera depan. */
    private fun processImage(image: ImageProxy, front: Boolean): String {
        val src = image.toBitmap()
        val deg = image.imageInfo.rotationDegrees
        var bmp: Bitmap = src
        if (deg != 0) {
            val m = Matrix()
            m.postRotate(deg.toFloat())
            bmp = Bitmap.createBitmap(src, 0, 0, src.width, src.height, m, true)
            if (bmp !== src) src.recycle()
        }

        val s = CameraSession
        val portraitAr = s.pw.toFloat() / s.ph.toFloat()
        val targetAr = if (bmp.width >= bmp.height) 1f / portraitAr else portraitAr
        val srcAr = bmp.width.toFloat() / bmp.height.toFloat()
        var cw = bmp.width
        var ch = bmp.height
        if (srcAr > targetAr) {
            cw = (bmp.height * targetAr).toInt()
        } else {
            ch = (bmp.width / targetAr).toInt()
        }
        cw = max(1, cw)
        ch = max(1, ch)
        val cx = (bmp.width - cw) / 2
        val cy = (bmp.height - ch) / 2
        val cropped = Bitmap.createBitmap(bmp, cx, cy, cw, ch)
        if (cropped !== bmp) bmp.recycle()

        val longSide = max(cw, ch)
        var out: Bitmap = cropped
        if (longSide > MAX_SIDE) {
            val scale = MAX_SIDE.toFloat() / longSide.toFloat()
            val nw = max(1, (cw * scale).toInt())
            val nh = max(1, (ch * scale).toInt())
            out = Bitmap.createScaledBitmap(cropped, nw, nh, true)
            if (out !== cropped) cropped.recycle()
        }

        out = applyFilterToBitmap(out)

        if (front) {
            val mm = Matrix()
            mm.postScale(-1f, 1f)
            val mirrored = Bitmap.createBitmap(out, 0, 0, out.width, out.height, mm, true)
            if (mirrored !== out) out.recycle()
            out = mirrored
        }

        val bos = ByteArrayOutputStream()
        out.compress(Bitmap.CompressFormat.JPEG, 90, bos)
        out.recycle()
        return "data:image/jpeg;base64," + Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP)
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
    }

    private companion object {
        const val MAX_SIDE = 1600
        const val MAX_VIDEO_SECONDS = 60
        val ZOOMS = floatArrayOf(1f, 2f, 5f)
        val TIMERS = intArrayOf(0, 3, 5, 10)
        val FILTER_NAMES = arrayOf("Normal", "Pink", "Warm", "Cool", "B&W", "Sepia", "Vivid", "Fade", "Vintage")
        val CREAM: Int = Color.parseColor("#FFF7F2")
        val PLUM: Int = Color.parseColor("#3B2447")
        val PINK: Int = Color.parseColor("#F76A9E")
        val RED: Int = Color.parseColor("#EF4444")
    }
}
