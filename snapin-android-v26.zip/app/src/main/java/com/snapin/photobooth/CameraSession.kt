package com.snapin.photobooth

/**
 * Menyimpan keadaan sesi kamera native (foto atau video) supaya tidak hilang
 * kalau layar kamera berputar mengikuti HP.
 */
object CameraSession {
    @Volatile var mode = "photo"      // "photo" | "video"
    @Volatile var count = 4
    @Volatile var facing = "user"
    @Volatile var pw = 3   // lebar rasio potret
    @Volatile var ph = 4   // tinggi rasio potret
    val photos = ArrayList<String>()
    val assets = ArrayList<String>()   // gambar My Assets (bingkai/stiker) dari pemilih galeri
    @Volatile var assetKind = "frame"
    @Volatile var rotationLock: Int? = null
    @Volatile var landscape = false
    @Volatile var videoPath: String? = null
    @Volatile var filter = 0           // indeks filter foto (0 = Normal)
    @Volatile var flash = 0            // 0 mati, 1 nyala, 2 auto (hanya foto kamera belakang)
    @Volatile var zoom = 1f            // 1x, 2x, atau 5x
    @Volatile var switchToLive = false   // ikon foto live diketuk di kamera native: pindah ke kamera web
    @Volatile var timer = 3            // detik hitung mundur sebelum foto: 0, 3, 5, atau 10
    @Volatile var orient = "auto"      // "auto" (ikut HP), "portrait", atau "landscape"

    fun reset(mode: String, count: Int, facing: String, pw: Int, ph: Int) {
        this.mode = mode
        this.count = count
        this.facing = facing
        this.pw = pw
        this.ph = ph
        photos.clear()
        rotationLock = null
        landscape = false
        videoPath = null
        filter = 0
        flash = 0
        zoom = 1f
    }
}
