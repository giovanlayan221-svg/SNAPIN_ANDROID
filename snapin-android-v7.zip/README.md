# Snapin Photobooth — Aplikasi Android

Project Android Studio yang memindahkan **seluruh** website Snapin
(kamera, filter, bingkai, stiker, layout strip/grid, mode video,
My Assets) menjadi aplikasi Android — dan memperbaiki bug rotasi
landscape secara permanen.

## Kenapa versi ini stabil untuk posisi "miring"

Bug yang menghantui versi web bersumber dari `deviceorientation` event
browser yang mentah, tidak terkalibrasi, dan tidak konsisten antar
device. Di aplikasi ini, data tilt dibaca native dari **sensor gravity
level OS** (sumber yang sama dipakai aplikasi kamera bawaan HP) lewat
`TiltBridge`, lalu disuntikkan ke kode web sebagai
`window.SnapinNative.getTilt()`.

- `beta`  = kemiringan layar dari vertikal (0 = layar menghadap atas,
  90 = layar vertical / kamera horizontal, 180 = layar menghadap bawah)
- `gamma` = arah roll (0 = tegak, ±90 = miring, tanda = sisi mana)

Rumus koreksi di web (v4: roll dari gamma + flip 180° dari beta dengan
histeresis 86°/94°) tetap dipakai persis sama — hanya sumber datanya
yang kini andal. Ketika halaman dibuka di browser biasa, aplikasi
otomatis kembali ke sensor web seperti sebelumnya.

## Cara build

1. Install [Android Studio](https://developer.android.com/studio) (versi terbaru stabil).
2. Buka folder project ini (`snapin-android`) di Android Studio.
3. Tunggu Gradle sync selesai (butuh internet pertama kali).
4. Jalankan di HP: sambungkan HP (aktifkan USB debugging) → tombol ▶ Run.
5. Buat APK: **Build → Build Bundle(s)/APK(s) → Build APK(s)**.
   File APK ada di `app/build/outputs/apk/debug/`.
6. Untuk rilis Play Store: **Build → Generate Signed Bundle/APK** (pilih AAB).

## Catatan

- Izin KAMERA dan MIKROFON diminta saat pertama dibuka.
- Semua proses tetap 100% di perangkat — tidak ada server.
- Jaring pengaman lama tetap ada: tombol "↺ Putar 180°" di halaman hasil,
  dan tekan-lama badge orientasi untuk melihat angka β/γ realtime.
- Debug webview: chrome://inspect di Chrome desktop saat HP terhubung.

## Build APK 100% dari HP (tanpa laptop)

Android Studio hanya ada di PC, jadi untuk build dari HP pakai GitHub Actions:

1. Buat akun di **github.com** (gratis) — lewat browser HP.
2. Buat repository baru: tombol **+ → New repository** → nama `snapin-android` → Public → **Create**.
3. Di halaman repo, pilih **uploading an existing file** → **Choose your files** →
   pilih file **`snapin-android.zip`** dari HP kamu → **Commit changes**.
   (Cukup SATU file zip itu saja, jangan diekstrak dulu.)
4. Buka tab **Actions** → kalau diminta, pilih **I understand my workflows, go ahead and enable them**.
5. Jalankan **Build APK** (tombol *Run workflow*), tunggu ±5–10 menit sampai ada centang hijau.
6. Buka run yang selesai → bagian **Artifacts** → unduh **snapin-apk** → itu file APK-nya.
7. Instal di HP: buat izinkan "install dari sumber tidak dikenal" untuk browser/file manager.

Selesai — setiap kali kamu update kode, upload ulang zip-nya dan run workflow lagi.

> Alternatif paling cepat kalau ada akses: 15 menit di warnet/komputer pinjaman
> dengan Android Studio, lalu Build APK seperti biasa.
