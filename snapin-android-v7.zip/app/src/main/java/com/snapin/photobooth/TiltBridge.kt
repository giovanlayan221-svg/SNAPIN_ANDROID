package com.snapin.photobooth

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.webkit.JavascriptInterface
import kotlin.math.acos
import kotlin.math.atan2
import kotlin.math.roundToInt
import kotlin.math.sqrt

/**
 * Feeds the web app tilt data computed from the OS-level gravity sensor —
 * fused and low-pass-filtered by the system, the same source the built-in
 * camera app uses — instead of the browser's raw, uncalibrated and
 * inconsistent `deviceorientation` events (the root cause of the
 * landscape-rotation bug family).
 *
 * Values are converted to the exact beta/gamma convention the web code
 * expects (see the web pipeline: processTiltAngles / compensationDeg):
 *   beta  = tilt of the screen normal from vertical, degrees.
 *           0 = screen faces straight up, 90 = screen vertical
 *           (horizontal camera), 180 = screen faces straight down.
 *   gamma = roll of world-up inside the phone plane, degrees.
 *           0 = phone upright, ±90 = rolled to landscape
 *           (sign = which side), stable through pitching.
 *
 * Gravity is read directly in device coordinates, so there is no rotation
 * matrix / world-frame convention ambiguity of any kind.
 */
class TiltBridge(context: Context) : SensorEventListener {

    private val sensorManager =
        context.getSystemService(Context.SENSOR_SERVICE) as SensorManager

    // TYPE_GRAVITY is a virtual sensor (accelerometer + fused low-pass);
    // fall back to the raw accelerometer if it is missing.
    private val gravitySensor: Sensor? =
        sensorManager.getDefaultSensor(Sensor.TYPE_GRAVITY)
            ?: sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)

    @Volatile var beta = 90.0
        private set
    @Volatile var gamma = 0.0
        private set

    private var started = false

    fun start() {
        if (started) return
        val s = gravitySensor ?: return
        started = sensorManager.registerListener(this, s, SensorManager.SENSOR_DELAY_GAME)
    }

    fun stop() {
        if (!started) return
        started = false
        sensorManager.unregisterListener(this)
    }

    override fun onSensorChanged(event: SensorEvent) {
        val gx = event.values[0].toDouble()
        val gy = event.values[1].toDouble()
        val gz = event.values[2].toDouble()
        val len = sqrt(gx * gx + gy * gy + gz * gz)
        if (len < 0.5) return // ignore free-fall / junk readings

        // beta: angle of the screen normal (device z) from vertical.
        val b = Math.toDegrees(acos((gz / len).coerceIn(-1.0, 1.0)))
        // gamma: direction of world-up within the phone plane
        // (atan2 of the horizontal components against the top axis).
        val g = Math.toDegrees(atan2(gx, gy))

        // Low-pass smoothing — matches the web pipeline's own smoothing.
        beta = beta * 0.7 + b * 0.3
        gamma = gamma * 0.7 + g * 0.3
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    @JavascriptInterface
    fun isNative(): Boolean = true

    @JavascriptInterface
    fun getTilt(): String {
        val b = (beta * 100).roundToInt() / 100.0
        val g = (gamma * 100).roundToInt() / 100.0
        return "{\"beta\":$b,\"gamma\":$g}"
    }
}
