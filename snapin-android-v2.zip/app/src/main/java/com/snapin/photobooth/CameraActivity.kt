package com.snapin.photobooth

import android.Manifest
import android.annotation.SuppressLint
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Base64
import android.util.TypedValue
import android.view.Gravity
import android.view.OrientationEventListener
import android.view.TextureView
import android.view.Surface
import android.view.View
import android.view.WindowManager
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.AspectRatio
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.FallbackStrategy
import androidx.camera.video.FileOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.core.util.Consumer
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.max
import kotlin.math.min

/**
 * Layar kamera native (CameraX / Camera2) untuk foto dan video. Rotasi diurus
 * lewat metadata kamera seperti aplikasi kamera bawaan.
 */
class CameraActivity : ComponentActivity() {

    private lateinit var previewView: PreviewView
    private lateinit var countText: TextView
    private lateinit var counterText: TextView
    private lateinit var flashView: View
    private lateinit var shutterView: View
    private lateinit var shutterInner: GradientDrawable
    private lateinit var shutterLayers: LayerDrawable
    private var filterRow: LinearLayout? = null
    private var camera: Camera? = null
    private var landscapeUi = false
    private lateinit var flashPill: TextView
    private var zoomRow: LinearLayout? = null
    private lateinit var screenFlash: View

    private var imageCapture: ImageCapture? = null
    private var videoCapture: VideoCapture<Recorder>? = null
    private var recording: Recording? = null
    private var recordStartAt = 0L

    private var currentRotation = Surface.ROTATION_0
    private var busy = false
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var cameraExecutor: ExecutorService
    private var orientationListener: OrientationEventListener? = null

    private val isVideo: Boolean
        get() = CameraSession.mode == "video"

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { _ ->
            if (hasCameraPermission()) {
                bindCamera()
            } else {
                toast("Izin kamera ditolak")
                finish()
            }
        }

    private val tick = object : Runnable {
        override fun run() {
            val s = ((SystemClock.elapsedRealtime() - recordStartAt) / 1000).toInt()
            counterText.text = "REC " + two(s / 60) + ":" + two(s % 60)
            if (s >= MAX_VIDEO_SECONDS) {
                stopRecording()
                return
            }
            handler.postDelayed(this, 250)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // orientasi yang dipilih di Setup: Tegak / Landscape / Auto (ikut HP)
        requestedOrientation = sessionOrientation()
        cameraExecutor = Executors.newSingleThreadExecutor()
        buildUi()
        setupOrientationListener()
        if (hasCameraPermission()) {
            bindCamera()
        } else if (isVideo) {
            permissionLauncher.launch(arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO))
        } else {
            permissionLauncher.launch(arrayOf(Manifest.permission.CAMERA))
        }
    }

    private fun sessionOrientation(): Int = when (CameraSession.orient) {
        "portrait" -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
        "landscape" -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        else -> ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR
    }

    private fun hasCameraPermission(): Boolean {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) ==
            PackageManager.PERMISSION_GRANTED
    }

    private fun hasAudioPermission(): Boolean {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
    }

    private fun two(n: Int): String {
        return if (n < 10) "0" + n else n.toString()
    }

    private fun dp(v: Int): Int {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics
        ).toInt()
    }

    private fun circleButton(iconRes: Int): ImageView {
        val v = ImageView(this)
        val bg = GradientDrawable()
        bg.shape = GradientDrawable.OVAL
        bg.setColor(Color.WHITE)
        v.background = bg
        v.setImageResource(iconRes)
        v.setPadding(dp(10), dp(10), dp(10), dp(10))
        v.elevation = dp(3).toFloat()
        v.setColorFilter(PLUM)
        return v
    }

    private fun buildUi() {
        val dm = resources.displayMetrics
        val sw = dm.widthPixels
        val sh = dm.heightPixels
        val landscape = sw > sh
        landscapeUi = landscape
        val s = CameraSession
        val spw = if (isVideo) 9 else s.pw
        val sph = if (isVideo) 16 else s.ph
        val portraitAr = spw.toFloat() / sph.toFloat()
        val boxAr = if (landscape) 1f / portraitAr else portraitAr

        // Posisi tegak: pratinjau dibuat selebar/setinggi mungkin (seperti kamera bawaan),
        // hanya menyisakan ruang untuk tombol atas dan tombol jepret di bawah.
        val availW = if (landscape) sw - dp(185) else sw - dp(4)
        val availH = if (landscape) sh - dp(8) else sh - dp(60) - dp(132)
        var bw = availW
        var bh = (bw / boxAr).toInt()
        if (bh > availH) {
            bh = availH
            bw = (bh * boxAr).toInt()
        }

        val root = FrameLayout(this)
        root.setBackgroundColor(CREAM)

        // kotak preview
        val box = FrameLayout(this)
        val boxBg = GradientDrawable()
        boxBg.setColor(Color.BLACK)
        boxBg.cornerRadius = dp(24).toFloat()
        box.background = boxBg
        box.clipToOutline = true
        val boxLp = FrameLayout.LayoutParams(bw, bh)
        var landscapeRow: LinearLayout? = null
        if (landscape) {
            // area preview = ruang di kiri panel kontrol; kotak preview selalu di TENGAH area itu
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            val area = FrameLayout(this)
            boxLp.gravity = Gravity.CENTER
            area.addView(box, boxLp)
            row.addView(area, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
            root.addView(
                row,
                FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            )
            landscapeRow = row
        } else {
            boxLp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            boxLp.topMargin = dp(60) + maxOf(0, (availH - bh) / 2)
            root.addView(box, boxLp)
        }

        previewView = PreviewView(this)
        previewView.implementationMode = PreviewView.ImplementationMode.COMPATIBLE
        previewView.scaleType = PreviewView.ScaleType.FILL_CENTER
        box.addView(
            previewView,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )

        flashView = View(this)
        flashView.setBackgroundColor(Color.WHITE)
        flashView.alpha = 0f
        box.addView(
            flashView,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )

        countText = TextView(this)
        countText.textSize = 96f
        countText.setTextColor(Color.WHITE)
        countText.typeface = Typeface.DEFAULT_BOLD
        countText.setShadowLayer(12f, 0f, 4f, Color.argb(153, 0, 0, 0))
        countText.visibility = View.GONE
        box.addView(
            countText,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER
            )
        )

        // strip filter (geser kiri-kanan), hanya untuk foto
        if (!isVideo) {
            val scroll = HorizontalScrollView(this)
            scroll.isHorizontalScrollBarEnabled = false
            scroll.overScrollMode = View.OVER_SCROLL_NEVER
            scroll.setBackgroundColor(Color.argb(70, 0, 0, 0))
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.setPadding(dp(8), dp(8), dp(8), dp(8))
            for (i in FILTER_NAMES.indices) {
                val chip = TextView(this)
                chip.text = FILTER_NAMES[i]
                chip.textSize = 13f
                chip.typeface = Typeface.DEFAULT_BOLD
                chip.setPadding(dp(16), dp(8), dp(16), dp(8))
                chip.setOnClickListener {
                    CameraSession.filter = i
                    updateFilterChips()
                    applyPreviewFilter()
                }
                val clp = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
                )
                clp.leftMargin = dp(4)
                clp.rightMargin = dp(4)
                row.addView(chip, clp)
            }
            filterRow = row
            scroll.addView(
                row,
                FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            )
            val scrollLp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            scrollLp.gravity = Gravity.BOTTOM
            box.addView(scroll, scrollLp)
            updateFilterChips()
        }

        val wrap = ViewGroup.LayoutParams.WRAP_CONTENT

        // pil flash (kiri atas preview)
        flashPill = TextView(this)
        flashPill.textSize = 13f
        flashPill.typeface = Typeface.DEFAULT_BOLD
        flashPill.setTextColor(Color.WHITE)
        flashPill.setPadding(dp(14), dp(8), dp(14), dp(8))
        val flashBg = GradientDrawable()
        flashBg.setColor(Color.argb(130, 0, 0, 0))
        flashBg.cornerRadius = dp(18).toFloat()
        flashPill.background = flashBg
        flashPill.setOnClickListener { cycleFlash() }
        val flashLp = FrameLayout.LayoutParams(wrap, wrap)
        flashLp.gravity = Gravity.TOP or Gravity.START
        flashLp.topMargin = dp(12)
        flashLp.leftMargin = dp(12)
        box.addView(flashPill, flashLp)
        updateFlashLabel()

        // tombol zoom 1x / 2x / 5x (tengah bawah preview)
        val zrow = LinearLayout(this)
        zrow.orientation = LinearLayout.HORIZONTAL
        for (z in ZOOMS) {
            val chip = TextView(this)
            chip.text = zoomLabel(z)
            chip.textSize = 13f
            chip.typeface = Typeface.DEFAULT_BOLD
            chip.gravity = Gravity.CENTER
            chip.setOnClickListener { setZoom(z) }
            val clp = LinearLayout.LayoutParams(dp(46), dp(34))
            clp.leftMargin = dp(4)
            clp.rightMargin = dp(4)
            zrow.addView(chip, clp)
        }
        zoomRow = zrow
        val zoomLp = FrameLayout.LayoutParams(wrap, wrap)
        zoomLp.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        zoomLp.bottomMargin = if (isVideo) dp(14) else dp(68)
        box.addView(zrow, zoomLp)
        updateZoomChips()

        // ---- kontrol utama ----
        val back = circleButton(R.drawable.ic_back)
        back.setOnClickListener { finish() }
        val flip = circleButton(R.drawable.ic_flip)
        flip.setOnClickListener { onFlip() }

        // penghitung foto / timer video
        counterText = TextView(this)
        counterText.setTextColor(PLUM)
        counterText.textSize = 15f
        counterText.typeface = Typeface.DEFAULT_BOLD
        counterText.setPadding(dp(12), dp(8), dp(12), dp(8))
        val pill = GradientDrawable()
        pill.setColor(Color.WHITE)
        pill.cornerRadius = dp(20).toFloat()
        counterText.background = pill
        updateCounter()

        // tombol jepret / rekam
        val accent = if (isVideo) RED else PINK
        shutterView = View(this)
        val outer = GradientDrawable()
        outer.shape = GradientDrawable.OVAL
        outer.setColor(Color.WHITE)
        outer.setStroke(dp(4), accent)
        shutterInner = GradientDrawable()
        shutterInner.shape = GradientDrawable.OVAL
        shutterInner.setColor(accent)
        shutterLayers = LayerDrawable(arrayOf<Drawable>(outer, shutterInner))
        shutterLayers.setLayerInset(1, dp(8), dp(8), dp(8), dp(8))
        shutterView.background = shutterLayers
        shutterView.setOnClickListener { onShutter() }

        if (landscape) {
            // panel kanan rapi: semua tombol sejajar di satu garis tengah
            val panel = FrameLayout(this)
            val backLp = FrameLayout.LayoutParams(dp(44), dp(44))
            backLp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            backLp.topMargin = dp(14)
            panel.addView(back, backLp)
            val counterLp = FrameLayout.LayoutParams(wrap, wrap)
            counterLp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            counterLp.topMargin = dp(70)
            panel.addView(counterText, counterLp)
            val shutterLp = FrameLayout.LayoutParams(dp(76), dp(76))
            shutterLp.gravity = Gravity.CENTER
            panel.addView(shutterView, shutterLp)
            val flipLp = FrameLayout.LayoutParams(dp(44), dp(44))
            flipLp.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            flipLp.bottomMargin = dp(14)
            panel.addView(flip, flipLp)
            val rowRef = landscapeRow
            if (rowRef != null) {
                rowRef.addView(panel, LinearLayout.LayoutParams(dp(120), ViewGroup.LayoutParams.MATCH_PARENT))
            }
        } else {
            val backLp = FrameLayout.LayoutParams(dp(44), dp(44))
            backLp.gravity = Gravity.TOP or Gravity.START
            backLp.topMargin = dp(16)
            backLp.leftMargin = dp(16)
            root.addView(back, backLp)
            val flipLp = FrameLayout.LayoutParams(dp(44), dp(44))
            flipLp.gravity = Gravity.TOP or Gravity.END
            flipLp.topMargin = dp(16)
            flipLp.rightMargin = dp(16)
            root.addView(flip, flipLp)
            val counterLp = FrameLayout.LayoutParams(wrap, wrap)
            counterLp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            counterLp.topMargin = dp(22)
            root.addView(counterText, counterLp)
            val shutterLp = FrameLayout.LayoutParams(dp(76), dp(76))
            shutterLp.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            shutterLp.bottomMargin = dp(52)
            root.addView(shutterView, shutterLp)
        }

        // lapisan putih penuh untuk flash layar (kamera depan)
        screenFlash = View(this)
        screenFlash.setBackgroundColor(Color.WHITE)
        screenFlash.alpha = 0f
        screenFlash.visibility = View.GONE
        root.addView(
            screenFlash,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )

        setContentView(root)
    }

    private fun updateFilterChips() {
        val row = filterRow ?: return
        for (j in 0 until row.childCount) {
            val chip = row.getChildAt(j) as TextView
            val bg = GradientDrawable()
            bg.cornerRadius = dp(18).toFloat()
            if (j == CameraSession.filter) {
                bg.setColor(PINK)
                chip.setTextColor(Color.WHITE)
            } else {
                bg.setColor(Color.argb(215, 255, 255, 255))
                chip.setTextColor(PLUM)
            }
            chip.background = bg
        }
    }

    private fun m(vararg v: Float): ColorMatrix {
        return ColorMatrix(v)
    }

    private fun contrastMatrix(c: Float): ColorMatrix {
        val t = 128f * (1f - c)
        return m(
            c, 0f, 0f, 0f, t,
            0f, c, 0f, 0f, t,
            0f, 0f, c, 0f, t,
            0f, 0f, 0f, 1f, 0f
        )
    }

    /** Matriks warna tiap filter. null = Normal. */
    private fun filterMatrix(index: Int): ColorMatrix? {
        return when (index) {
            1 -> m( // Pink
                1.08f, 0f, 0f, 0f, 8f,
                0f, 0.97f, 0f, 0f, 4f,
                0f, 0f, 1.05f, 0f, 10f,
                0f, 0f, 0f, 1f, 0f
            )
            2 -> m( // Warm
                1.10f, 0f, 0f, 0f, 10f,
                0f, 1.02f, 0f, 0f, 4f,
                0f, 0f, 0.88f, 0f, 0f,
                0f, 0f, 0f, 1f, 0f
            )
            3 -> m( // Cool
                0.92f, 0f, 0f, 0f, 0f,
                0f, 1.0f, 0f, 0f, 4f,
                0f, 0f, 1.10f, 0f, 8f,
                0f, 0f, 0f, 1f, 0f
            )
            4 -> { // B&W
                val bw = ColorMatrix()
                bw.setSaturation(0f)
                bw.postConcat(contrastMatrix(1.08f))
                bw
            }
            5 -> m( // Sepia
                0.393f, 0.769f, 0.189f, 0f, 0f,
                0.349f, 0.686f, 0.168f, 0f, 0f,
                0.272f, 0.534f, 0.131f, 0f, 0f,
                0f, 0f, 0f, 1f, 0f
            )
            6 -> { // Vivid
                val v = ColorMatrix()
                v.setSaturation(1.45f)
                v.postConcat(contrastMatrix(1.08f))
                v
            }
            7 -> { // Fade
                val f = ColorMatrix()
                f.setSaturation(0.8f)
                f.postConcat(
                    m(
                        0.92f, 0f, 0f, 0f, 24f,
                        0f, 0.92f, 0f, 0f, 24f,
                        0f, 0f, 0.92f, 0f, 24f,
                        0f, 0f, 0f, 1f, 0f
                    )
                )
                f
            }
            8 -> { // Vintage
                val vt = ColorMatrix()
                vt.setSaturation(0.7f)
                vt.postConcat(
                    m(
                        1.08f, 0f, 0f, 0f, 12f,
                        0f, 1.0f, 0f, 0f, 6f,
                        0f, 0f, 0.86f, 0f, 0f,
                        0f, 0f, 0f, 1f, 0f
                    )
                )
                vt.postConcat(contrastMatrix(1.06f))
                vt
            }
            else -> null
        }
    }

    private fun findTextureView(v: View): TextureView? {
        if (v is TextureView) return v
        if (v is ViewGroup) {
            for (i in 0 until v.childCount) {
                val r = findTextureView(v.getChildAt(i))
                if (r != null) return r
            }
        }
        return null
    }

    /** Terapkan filter ke preview langsung (TextureView di dalam PreviewView). */
    private fun applyPreviewFilter() {
        if (isVideo) return
        val tv = findTextureView(previewView) ?: return
        val cm = filterMatrix(CameraSession.filter)
        if (cm == null) {
            tv.setLayerPaint(null)
        } else {
            val paint = Paint()
            paint.colorFilter = ColorMatrixColorFilter(cm)
            tv.setLayerPaint(paint)
        }
    }

    private fun scheduleFilterApply() {
        if (isVideo) return
        handler.postDelayed({ applyPreviewFilter() }, 350)
        handler.postDelayed({ applyPreviewFilter() }, 900)
        handler.postDelayed({ applyPreviewFilter() }, 1800)
    }

    private fun applyFilterToBitmap(src: Bitmap): Bitmap {
        val cm = filterMatrix(CameraSession.filter) ?: return src
        val result = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(result)
        val paint = Paint()
        paint.colorFilter = ColorMatrixColorFilter(cm)
        canvas.drawBitmap(src, 0f, 0f, paint)
        src.recycle()
        return result
    }

    /** Naikkan kecerahan (EV) supaya video tidak gelap, terutama kamera depan. */
    private fun boostExposure(cam: Camera, evStops: Float) {
        try {
            val st = cam.cameraInfo.exposureState
            if (!st.isExposureCompensationSupported) return
            val step = st.exposureCompensationStep.toFloat()
            if (step <= 0f) return
            val range = st.exposureCompensationRange
            var idx = Math.round(evStops / step)
            idx = max(range.lower, min(range.upper, idx))
            cam.cameraControl.setExposureCompensationIndex(idx)
        } catch (e: Exception) {
            // abaikan
        }
    }

    private fun updateCounter() {
        if (isVideo) {
            counterText.text = if (landscapeUi) "Siap merekam" else "Siap merekam (maks 30 detik)"
            return
        }
        val total = CameraSession.count
        val n = min(CameraSession.photos.size + 1, total)
        counterText.text = "Foto " + n + "/" + total
    }

    private fun setShutterRecording(on: Boolean) {
        if (on) {
            shutterInner.shape = GradientDrawable.RECTANGLE
            shutterInner.cornerRadius = dp(8).toFloat()
            shutterLayers.setLayerInset(1, dp(24), dp(24), dp(24), dp(24))
        } else {
            shutterInner.shape = GradientDrawable.OVAL
            shutterLayers.setLayerInset(1, dp(8), dp(8), dp(8), dp(8))
        }
        shutterLayers.invalidateSelf()
        shutterView.invalidate()
    }

    private fun setupOrientationListener() {
        orientationListener = object : OrientationEventListener(this) {
            override fun onOrientationChanged(orientation: Int) {
                if (orientation == OrientationEventListener.ORIENTATION_UNKNOWN) return
                val r = when {
                    orientation >= 315 || orientation < 45 -> Surface.ROTATION_0
                    orientation < 135 -> Surface.ROTATION_270
                    orientation < 225 -> Surface.ROTATION_180
                    else -> Surface.ROTATION_90
                }
                currentRotation = r
                if (CameraSession.rotationLock == null) {
                    imageCapture?.targetRotation = r
                }
                if (recording == null) {
                    videoCapture?.targetRotation = r
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        orientationListener?.enable()
    }

    override fun onPause() {
        orientationListener?.disable()
        super.onPause()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        recording?.stop()
        cameraExecutor.shutdown()
        super.onDestroy()
    }

    private fun bindCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener(Runnable {
            try {
                bindUseCases(future.get())
                scheduleFilterApply()
            } catch (e: Exception) {
                toast("Kamera tidak bisa dibuka")
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun bindUseCases(provider: ProcessCameraProvider) {
        val selector = if (CameraSession.facing == "user") {
            CameraSelector.DEFAULT_FRONT_CAMERA
        } else {
            CameraSelector.DEFAULT_BACK_CAMERA
        }

        if (isVideo) {
            val preview = Preview.Builder()
                .setTargetAspectRatio(AspectRatio.RATIO_16_9)
                .build()
            preview.setSurfaceProvider(previewView.surfaceProvider)
            val recorder = Recorder.Builder()
                .setQualitySelector(
                    QualitySelector.from(
                        Quality.HD,
                        FallbackStrategy.lowerQualityOrHigherThan(Quality.SD)
                    )
                )
                .build()
            // 2 = MIRROR_MODE_ON_FRONT_ONLY: video kamera depan dicerminkan seperti preview
            val vc = VideoCapture.Builder<Recorder>(recorder)
                .setMirrorMode(2)
                .build()
            vc.targetRotation = currentRotation
            provider.unbindAll()
            val cam = provider.bindToLifecycle(this, selector, preview, vc)
            boostExposure(cam, if (CameraSession.facing == "user") 1.5f else 0.5f)
            camera = cam
            videoCapture = vc
            imageCapture = null
        } else {
            val preview = Preview.Builder().build()
            preview.setSurfaceProvider(previewView.surfaceProvider)
            val capture = ImageCapture.Builder()
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                .build()
            val lock = CameraSession.rotationLock
            capture.targetRotation = if (lock != null) lock else currentRotation
            provider.unbindAll()
            val cam = provider.bindToLifecycle(this, selector, preview, capture)
            camera = cam
            imageCapture = capture
            videoCapture = null
        }
        afterBind()
    }

    /** Terapkan lagi flash dan zoom setiap kali kamera dibuka / dibalik. */
    private fun afterBind() {
        refreshFlashUi()
        applyFlash()
        if (CameraSession.zoom != 1f) {
            setZoom(CameraSession.zoom)
        } else {
            updateZoomChips()
        }
    }

    private fun isFront(): Boolean {
        return CameraSession.facing == "user"
    }

    private fun cycleFlash() {
        val rearPhoto = !isVideo && !isFront()
        val cur = CameraSession.flash
        CameraSession.flash = if (rearPhoto) (cur + 1) % 3 else (if (cur == 1) 0 else 1)
        updateFlashLabel()
        applyFlash()
    }

    private fun updateFlashLabel() {
        flashPill.text = when (CameraSession.flash) {
            1 -> "Flash nyala"
            2 -> "Flash auto"
            else -> "Flash mati"
        }
    }

    /** Kamera belakang: lampu flash. Kamera depan (foto): flash layar. Video: lampu belakang saja. */
    private fun refreshFlashUi() {
        val cam = camera
        val hasUnit = cam != null && cam.cameraInfo.hasFlashUnit()
        val visible = if (isFront()) !isVideo else hasUnit
        flashPill.visibility = if (visible) View.VISIBLE else View.GONE
        if ((isVideo || isFront()) && CameraSession.flash == 2) {
            CameraSession.flash = 1
        }
        updateFlashLabel()
    }

    private fun applyFlash() {
        val rear = !isFront()
        val cap = imageCapture
        if (cap != null) {
            cap.flashMode = if (rear) {
                when (CameraSession.flash) {
                    1 -> ImageCapture.FLASH_MODE_ON
                    2 -> ImageCapture.FLASH_MODE_AUTO
                    else -> ImageCapture.FLASH_MODE_OFF
                }
            } else {
                ImageCapture.FLASH_MODE_OFF
            }
        }
        val cam = camera
        if (isVideo && cam != null) {
            try {
                cam.cameraControl.enableTorch(rear && CameraSession.flash == 1)
            } catch (e: Exception) {
                // abaikan
            }
        }
    }

    private fun zoomLabel(z: Float): String {
        return z.toInt().toString() + "\u00D7"
    }

    private fun updateZoomChips() {
        val row = zoomRow ?: return
        for (i in 0 until row.childCount) {
            val chip = row.getChildAt(i) as TextView
            val bg = GradientDrawable()
            bg.cornerRadius = dp(17).toFloat()
            if (ZOOMS[i] == CameraSession.zoom) {
                bg.setColor(PINK)
            } else {
                bg.setColor(Color.argb(130, 0, 0, 0))
            }
            chip.background = bg
            chip.setTextColor(Color.WHITE)
        }
    }

    private fun setZoom(z: Float) {
        val cam = camera
        val prev = CameraSession.zoom
        CameraSession.zoom = z
        updateZoomChips()
        if (cam == null) return
        val f = cam.cameraControl.setZoomRatio(z)
        f.addListener(Runnable {
            try {
                f.get()
            } catch (e: Exception) {
                CameraSession.zoom = prev
                updateZoomChips()
                toast("Zoom " + z.toInt() + "x tidak didukung kamera ini")
                try {
                    cam.cameraControl.setZoomRatio(prev)
                } catch (ex: Exception) {
                    // abaikan
                }
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun showScreenFlash() {
        val lp = window.attributes
        lp.screenBrightness = 1f
        window.attributes = lp
        screenFlash.visibility = View.VISIBLE
        screenFlash.animate().alpha(0.95f).setDuration(150).start()
    }

    private fun hideScreenFlash() {
        val lp = window.attributes
        lp.screenBrightness = WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
        window.attributes = lp
        screenFlash.animate().alpha(0f).setDuration(200).withEndAction {
            screenFlash.visibility = View.GONE
        }.start()
    }

    private fun onFlip() {
        if (busy || recording != null) return
        CameraSession.facing = if (CameraSession.facing == "user") "environment" else "user"
        CameraSession.zoom = 1f
        if (CameraSession.flash == 2) CameraSession.flash = 1
        bindCamera()
    }

    private fun onShutter() {
        if (isVideo) {
            if (recording != null) {
                stopRecording()
            } else if (!busy) {
                busy = true
                startRecording()
            }
            return
        }
        if (busy) return
        busy = true
        shutterView.alpha = 0.5f
        runCountdown(3)
    }

    // ---------------- VIDEO ----------------

    @SuppressLint("MissingPermission")
    private fun startRecording() {
        val vc = videoCapture
        if (vc == null) {
            toast("Kamera belum siap")
            busy = false
            return
        }
        try {
            val dir = File(cacheDir, "snapin_videos")
            dir.mkdirs()
            val old = dir.listFiles()
            if (old != null) {
                for (f in old) f.delete()
            }
            val file = File(dir, "snapin_" + System.currentTimeMillis() + ".mp4")
            val opts = FileOutputOptions.Builder(file).build()
            var pending = vc.output.prepareRecording(this, opts)
            if (hasAudioPermission()) {
                pending = pending.withAudioEnabled()
            }
            vc.targetRotation = currentRotation
            // kunci layar selama merekam supaya activity tidak dibuat ulang saat HP diputar
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LOCKED
            recording = pending.start(
                ContextCompat.getMainExecutor(this),
                Consumer<VideoRecordEvent> { event -> onVideoEvent(event, file) }
            )
            setShutterRecording(true)
            recordStartAt = SystemClock.elapsedRealtime()
            counterText.text = "REC 00:00"
            handler.postDelayed(tick, 250)
        } catch (e: Exception) {
            toast("Gagal memulai rekaman")
            requestedOrientation = sessionOrientation()
            recording = null
            busy = false
        }
    }

    private fun stopRecording() {
        handler.removeCallbacks(tick)
        shutterView.alpha = 0.5f
        counterText.text = "Menyimpan video..."
        recording?.stop()
    }

    private fun onVideoEvent(event: VideoRecordEvent, file: File) {
        if (event is VideoRecordEvent.Finalize) {
            handler.removeCallbacks(tick)
            recording = null
            if (isDestroyed) return
            val ok = file.exists() && (!event.hasError() || file.length() > 50000)
            if (ok) {
                CameraSession.videoPath = file.absolutePath
                setResult(RESULT_OK)
                finish()
            } else {
                toast("Gagal merekam video, coba lagi")
                requestedOrientation = sessionOrientation()
                setShutterRecording(false)
                updateCounter()
                resetShutter()
            }
        }
    }

    // ---------------- FOTO ----------------

    private fun runCountdown(n: Int) {
        if (n <= 0) {
            countText.visibility = View.GONE
            takePhoto()
            return
        }
        countText.text = n.toString()
        countText.visibility = View.VISIBLE
        handler.postDelayed({ runCountdown(n - 1) }, 800)
    }

    private fun resetShutter() {
        busy = false
        shutterView.alpha = 1f
    }

    private fun takePhoto() {
        val capture = imageCapture
        if (capture == null) {
            toast("Kamera belum siap")
            resetShutter()
            return
        }
        val front = CameraSession.facing == "user"
        if (front && CameraSession.flash == 1) {
            showScreenFlash()
            handler.postDelayed({ performCapture(capture, front) }, 450)
        } else {
            performCapture(capture, front)
        }
    }

    private fun performCapture(capture: ImageCapture, front: Boolean) {
        val rot = capture.targetRotation
        capture.takePicture(cameraExecutor, object : ImageCapture.OnImageCapturedCallback() {
            override fun onCaptureSuccess(image: ImageProxy) {
                val result: String? = try {
                    processImage(image, front)
                } catch (e: Exception) {
                    null
                } catch (e: OutOfMemoryError) {
                    null
                } finally {
                    image.close()
                }
                runOnUiThread { onShot(result, rot) }
            }

            override fun onError(exception: ImageCaptureException) {
                runOnUiThread { onShot(null, rot) }
            }
        })
    }

    private fun onShot(dataUrl: String?, rot: Int) {
        if (screenFlash.visibility == View.VISIBLE) hideScreenFlash()
        if (dataUrl == null) {
            toast("Gagal mengambil foto, coba lagi")
            resetShutter()
            return
        }
        flashView.alpha = 1f
        flashView.animate().alpha(0f).setDuration(320).start()

        if (CameraSession.rotationLock == null) {
            CameraSession.rotationLock = rot
            CameraSession.landscape = (rot == Surface.ROTATION_90 || rot == Surface.ROTATION_270)
        }
        CameraSession.photos.add(dataUrl)
        updateCounter()

        if (CameraSession.photos.size >= CameraSession.count) {
            handler.postDelayed({
                setResult(RESULT_OK)
                finish()
            }, 450)
        } else {
            handler.postDelayed({ resetShutter() }, 700)
        }
    }

    /** Putar sesuai sensor, potong ke rasio, kecilkan, cerminkan kamera depan. */
    private fun processImage(image: ImageProxy, front: Boolean): String {
        val src = image.toBitmap()
        val deg = image.imageInfo.rotationDegrees
        var bmp: Bitmap = src
        if (deg != 0) {
            val m = Matrix()
            m.postRotate(deg.toFloat())
            bmp = Bitmap.createBitmap(src, 0, 0, src.width, src.height, m, true)
            if (bmp !== src) src.recycle()
        }

        val s = CameraSession
        val portraitAr = s.pw.toFloat() / s.ph.toFloat()
        val targetAr = if (bmp.width >= bmp.height) 1f / portraitAr else portraitAr
        val srcAr = bmp.width.toFloat() / bmp.height.toFloat()
        var cw = bmp.width
        var ch = bmp.height
        if (srcAr > targetAr) {
            cw = (bmp.height * targetAr).toInt()
        } else {
            ch = (bmp.width / targetAr).toInt()
        }
        cw = max(1, cw)
        ch = max(1, ch)
        val cx = (bmp.width - cw) / 2
        val cy = (bmp.height - ch) / 2
        val cropped = Bitmap.createBitmap(bmp, cx, cy, cw, ch)
        if (cropped !== bmp) bmp.recycle()

        val longSide = max(cw, ch)
        var out: Bitmap = cropped
        if (longSide > MAX_SIDE) {
            val scale = MAX_SIDE.toFloat() / longSide.toFloat()
            val nw = max(1, (cw * scale).toInt())
            val nh = max(1, (ch * scale).toInt())
            out = Bitmap.createScaledBitmap(cropped, nw, nh, true)
            if (out !== cropped) cropped.recycle()
        }

        out = applyFilterToBitmap(out)

        if (front) {
            val mm = Matrix()
            mm.postScale(-1f, 1f)
            val mirrored = Bitmap.createBitmap(out, 0, 0, out.width, out.height, mm, true)
            if (mirrored !== out) out.recycle()
            out = mirrored
        }

        val bos = ByteArrayOutputStream()
        out.compress(Bitmap.CompressFormat.JPEG, 90, bos)
        out.recycle()
        return "data:image/jpeg;base64," + Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP)
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
    }

    private companion object {
        const val MAX_SIDE = 1600
        const val MAX_VIDEO_SECONDS = 30
        val ZOOMS = floatArrayOf(1f, 2f, 5f)
        val FILTER_NAMES = arrayOf("Normal", "Pink", "Warm", "Cool", "B&W", "Sepia", "Vivid", "Fade", "Vintage")
        val CREAM: Int = Color.parseColor("#FFF7F2")
        val PLUM: Int = Color.parseColor("#3B2447")
        val PINK: Int = Color.parseColor("#F76A9E")
        val RED: Int = Color.parseColor("#EF4444")
    }
}
