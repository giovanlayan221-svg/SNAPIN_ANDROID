package com.snapin.photobooth

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.webkit.PermissionRequest
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.webkit.WebViewAssetLoader
import java.io.File

/**
 * Snapin Photobooth — Android shell.
 *
 * The whole app (UI, filters, frames, stickers, layout, video, assets)
 * is the original single-file web app served from app assets over a
 * secure https:// origin (required for getUserMedia). The one piece the
 * web platform could never do reliably — reading the phone's physical
 * tilt — is provided natively by [TiltBridge] and injected into the page
 * as window.SnapinNative.getTilt(), using the OS-level fused gravity
 * sensor (the same source the built-in camera app uses).
 */
class MainActivity : ComponentActivity() {

    private lateinit var webView: WebView
    private lateinit var tiltBridge: TiltBridge
    private var pendingRequest: PermissionRequest? = null

    // Pemilih file (upload foto dari galeri, upload bingkai/stiker) dari halaman web.
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private val fileChooserLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val cb = fileCallback
            fileCallback = null
            cb?.onReceiveValue(
                WebChromeClient.FileChooserParams.parseResult(result.resultCode, result.data)
            )
        }

    // Hasil foto/video dari layar kamera native (CameraX) dikirim balik ke halaman web.
    private val cameraLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                if (CameraSession.mode == "video") {
                    val path = CameraSession.videoPath
                    if (path != null) {
                        val url = "https://appassets.androidplatform.net/videos/" + File(path).name
                        webView.evaluateJavascript(
                            "window.__onNativeVideo&&window.__onNativeVideo('" + url + "');", null
                        )
                    }
                } else if (CameraSession.photos.isNotEmpty()) {
                    val n = CameraSession.photos.size
                    val aw = if (CameraSession.landscape) CameraSession.ph else CameraSession.pw
                    val ah = if (CameraSession.landscape) CameraSession.pw else CameraSession.ph
                    val js = "window.__onNativePhotos&&window.__onNativePhotos(" +
                        n + "," + aw + "," + ah + ",'" + CameraSession.facing + "');"
                    webView.evaluateJavascript(js, null)
                }
            }
        }

    private fun openNativeCamera(mode: String, count: Int, facing: String, w: Int, h: Int) {
        CameraSession.reset(mode, count, facing, w, h)
        cameraLauncher.launch(Intent(this, CameraActivity::class.java))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        onBackPressedDispatcher.addCallback(this, backCallback)
        webView = WebView(this)
        setContentView(webView)
        WebView.setWebContentsDebuggingEnabled(true)

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true          // required for IndexedDB (My Assets)
            databaseEnabled = true
            mediaPlaybackRequiresUserGesture = false
            loadWithOverviewMode = true
            useWideViewPort = true
        }

        tiltBridge = TiltBridge(this)
        webView.addJavascriptInterface(tiltBridge, "SnapinNative")
        webView.addJavascriptInterface(
            NativeCameraBridge { m, c, f, w, h -> runOnUiThread { openNativeCamera(m, c, f, w, h) } },
            "SnapinCamera"
        )
        webView.addJavascriptInterface(FileBridge(this), "SnapinFiles")

        // Serve the web app over a secure origin so getUserMedia is allowed.
        val videoDir = File(cacheDir, "snapin_videos")
        videoDir.mkdirs()
        val assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .addPathHandler("/videos/", WebViewAssetLoader.InternalStoragePathHandler(this, videoDir))
            .build()

        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView,
                request: WebResourceRequest
            ): WebResourceResponse? = assetLoader.shouldInterceptRequest(request.url)
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest) {
                val needsCam = request.resources.contains(PermissionRequest.RESOURCE_VIDEO_CAPTURE)
                val needsMic = request.resources.contains(PermissionRequest.RESOURCE_AUDIO_CAPTURE)
                val ok = (!needsCam || hasPermission(Manifest.permission.CAMERA)) &&
                        (!needsMic || hasPermission(Manifest.permission.RECORD_AUDIO))
                if (ok) request.grant(request.resources)
                else {
                    pendingRequest = request
                    ensurePermissions()
                }
            }

            override fun onPermissionRequestCanceled(request: PermissionRequest) {
                if (pendingRequest === request) pendingRequest = null
            }

            override fun onShowFileChooser(
                view: WebView,
                filePathCallback: ValueCallback<Array<Uri>>,
                fileChooserParams: WebChromeClient.FileChooserParams
            ): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = filePathCallback
                return try {
                    fileChooserLauncher.launch(fileChooserParams.createIntent())
                    true
                } catch (e: Exception) {
                    fileCallback = null
                    false
                }
            }
        }

        webView.loadUrl("https://appassets.androidplatform.net/assets/www/index.html")
        ensurePermissions()
    }

    private fun hasPermission(p: String) =
        ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    private fun ensurePermissions() {
        val missing = mutableListOf<String>()
        if (!hasPermission(Manifest.permission.CAMERA)) missing += Manifest.permission.CAMERA
        if (!hasPermission(Manifest.permission.RECORD_AUDIO)) missing += Manifest.permission.RECORD_AUDIO
        if (missing.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, missing.toTypedArray(), REQ_PERMISSIONS)
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != REQ_PERMISSIONS) return
        pendingRequest?.let { req ->
            val ok = req.resources.all { res ->
                when (res) {
                    PermissionRequest.RESOURCE_VIDEO_CAPTURE -> hasPermission(Manifest.permission.CAMERA)
                    PermissionRequest.RESOURCE_AUDIO_CAPTURE -> hasPermission(Manifest.permission.RECORD_AUDIO)
                    else -> true
                }
            }
            if (ok) req.grant(req.resources) else req.deny()
            pendingRequest = null
        }
    }

    override fun onResume() {
        super.onResume()
        tiltBridge.start()
    }

    override fun onPause() {
        tiltBridge.stop()
        super.onPause()
    }

    // Tombol back HP: diserahkan dulu ke halaman web (kembali satu langkah di dalam aplikasi).
    // Aplikasi hanya tertutup kalau halaman web bilang sudah tidak ada langkah mundur.
    private val backCallback = object : androidx.activity.OnBackPressedCallback(true) {
        override fun handleOnBackPressed() {
            if (!::webView.isInitialized) { finish(); return }
            webView.evaluateJavascript("(window.__snapinBack ? window.__snapinBack() : false)") { r ->
                if (r != "true") finish()
            }
        }
    }

    override fun onDestroy() {
        webView.destroy()
        super.onDestroy()
    }

    private companion object {
        const val REQ_PERMISSIONS = 1001
    }
}
