# Snapin Android - catatan perubahan v2

## Yang diperbaiki
- **Hijau berbekas** pada bingkai berwarna polos: kunci warna baru (lihat README admin). Berlaku juga saat upload "Frame saya" di aplikasi.
- **Tombol back / keluar**: back HP sekarang mundur satu langkah di dalam aplikasi. "Ubah tata letak", "Frame saya", dan stiker
  tidak lagi melempar ke halaman utama; hasil dan stiker tetap ada. Keluar dari hasil yang belum disimpan meminta konfirmasi.
  Di beranda, back dua kali baru keluar aplikasi.
- **Gerakan stiker ala Canva**: 1 jari geser; 2 jari cubit = zoom + putar; pegangan kanan-bawah = ukuran saja; pegangan bulat bawah = putar saja
  (menempel di 0/90/180); pegangan kiri-atas = hapus.
- **Kamera tegak** dibuat selebar/setinggi mungkin (4:3 dan 16:9 terasa besar).

## Fitur baru
- **Rasio + orientasi** per bingkai (admin) dan pilihan arah di Setup (Ikut HP / Tegak / Landscape). Bingkai hanya muncul bila jumlah foto DAN rasionya cocok.
- **Bingkai tersimpan offline di penyimpanan data** (IndexedDB), bukan cache browser. Sekali terunduh, tetap ada tanpa internet.
- **Studio Bingkai** (Beranda): pilih foto/video, jumlah foto, rasio 1:1 / 4:3 / 16:9, tegak/landscape; upload bingkai + karakter PNG, atur
  presisi (geser/ukuran/putar per langkah, transparan, tengah, balik, urutan layer), bingkai bawaan ditampilkan transparan sebagai acuan,
  foto contoh dari galeri, zoom kanvas. Simpan ke "Frame saya" (offline), PNG, atau kirim ke server.
- **Stiker bawaan** berupa SVG (tanpa emoji) + tambah stiker dari galeri (tersimpan offline).
- **Bingkai & stiker pada video**: bingkai video (1 lubang, 16:9 tegak/landscape, termasuk animasi) tampil di pratinjau; saat simpan/bagikan video
  dirender ulang di HP (hasil .webm). **Fitur ini perlu dites di HP kamu**: bergantung MediaRecorder WebView, dan proses berjalan real-time sepanjang durasi video.
- **13 tema bingkai bawaan** dengan konsep berbeda: Bunny Pink, Yellow Buddy, Y2K Chrome, Sakura, Party Pop, Retro Film, Neon Night,
  Dreamy Cloud, Summer Ocean, Notebook, Cat Paws, Winter Snow (+ Polos).
- **Toko QRIS tanpa login**: beli bingkai/paket lewat QRIS di dalam aplikasi, atau masukkan kode redeem (ikon tag di My Assets).

## Belum / perlu dicek
- Build APK belum bisa dijalankan di sini: Kotlin diedit hati-hati tapi belum dikompilasi. Jalankan build lalu tes di HP.
- Orientasi "Tegak/Landscape" mengunci layar kamera native sesuai pilihan; "Ikut HP" seperti sebelumnya.
- Video berbingkai diekspor sebagai .webm (bukan .mp4).
