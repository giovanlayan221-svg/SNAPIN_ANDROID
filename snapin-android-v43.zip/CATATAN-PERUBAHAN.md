# Snapin Android - catatan perubahan v2

## Yang diperbaiki
- **Hijau berbekas** pada bingkai berwarna polos: kunci warna baru (lihat README admin). Berlaku juga saat upload "Frame saya" di aplikasi.
- **Tombol back / keluar**: back HP sekarang mundur satu langkah di dalam aplikasi. "Ubah tata letak", "Frame saya", dan stiker
  tidak lagi melempar ke halaman utama; hasil dan stiker tetap ada. Keluar dari hasil yang belum disimpan meminta konfirmasi.
  Di beranda, back dua kali baru keluar aplikasi.
- **Gerakan stiker ala Canva**: 1 jari geser; 2 jari cubit = zoom + putar; pegangan kanan-bawah = ukuran saja; pegangan bulat bawah = putar saja
  (menempel di 0/90/180); pegangan kiri-atas = hapus.
- **Kamera tegak** dibuat selebar/setinggi mungkin (4:3 dan 16:9 terasa besar).

## Fitur baru
- **Rasio** per bingkai (admin). Bingkai hanya muncul bila jumlah foto DAN rasionya cocok.
- **Bingkai tersimpan offline di penyimpanan data** (IndexedDB), bukan cache browser. Sekali terunduh, tetap ada tanpa internet.
- **Stiker bawaan** berupa SVG (tanpa emoji) + tambah stiker dari galeri (tersimpan offline).
- **Bingkai & stiker pada video**: bingkai video (1 lubang, 16:9 tegak/landscape, termasuk animasi) tampil di pratinjau; saat simpan/bagikan video
  dirender ulang di HP (hasil .webm). **Fitur ini perlu dites di HP kamu**: bergantung MediaRecorder WebView, dan proses berjalan real-time sepanjang durasi video.
- **13 tema bingkai bawaan** dengan konsep berbeda: Bunny Pink, Yellow Buddy, Y2K Chrome, Sakura, Party Pop, Retro Film, Neon Night,
  Dreamy Cloud, Summer Ocean, Notebook, Cat Paws, Winter Snow (+ Polos).
- **Toko QRIS tanpa login**: beli bingkai/paket lewat QRIS di dalam aplikasi, atau masukkan kode redeem (ikon tag di My Assets).

## Belum / perlu dicek
- Build APK belum bisa dijalankan di sini: Kotlin diedit hati-hati tapi belum dikompilasi. Jalankan build lalu tes di HP.
- Video berbingkai diekspor sebagai .webm (bukan .mp4).

## v3 (revisi setelah dites di HP)
- **Dihapus**: Studio Bingkai (editor bebas) dan pilihan "Arah hasil" di Setup.
- **Galeri**: sekarang cukup pilih 1 sampai 6 foto, jumlah foto mengikuti yang dipilih (dulu harus pas sama jumlah foto, kalau kurang cuma muncul toast). Foto besar diproses lewat object URL supaya hemat memori.
- **Video kamera belakang gelap**: kecerahan preview dibaca otomatis; kalau terlalu gelap, kompensasi eksposur dinaikkan bertahap (mulai +1.0 EV untuk kamera belakang). Perlu dites di HP kamu.
- **Pratinjau video**: frame pertama ditampilkan walau belum diputar (sebelumnya bisa tampak hitam).
- **Teks "snapin photobooth"**: di semua bingkai bawaan dan bingkai server gratis tampil di pil putih memanjang di tengah bawah. Teks tema lain yang bentrok di area itu dihapus. Bingkai buatan sendiri (Frame saya) tidak diberi teks.
- **Bingkai berbayar**: pil putih berisi mahkota emas (bukan teks) pada hasil, dan lencana mahkota emas di daftar bingkai.

## v3.1
- **Halaman hasil tidak bisa digeser/diketuk**: lapisan stiker menutupi seluruh kanvas dan memblokir sentuhan. Sekarang lapisan itu tembus sentuhan; hanya stiker (dan pegangannya) yang menangkap sentuhan. Dites dengan geser sentuh sungguhan: sebelum perbaikan tidak bergeser, sesudahnya halaman bergeser normal.

## v3.2
- **Galeri**: tombol "Galeri" sekarang memakai pemilih foto bawaan Android (Photo Picker, bisa pilih 1 sampai 6 foto). Foto diperkecil (maks 1800 px), diluruskan sesuai EXIF, dan HEIC dikonversi ke JPEG di sisi native, jadi tidak lagi bergantung pada pemilih file WebView. Di browser tetap memakai input file biasa.
- **Tombol rekam video**: digambar ulang per status. Saat merekam isinya jadi kotak merah kecil membulat di tengah cincin (dulu terlalu besar karena ukuran lapisan tidak dihitung ulang), dengan denyut halus. Ruang di bawah pratinjau ditambah supaya tombol tidak mepet.

## v2.2 (versionCode 12)
Versi aplikasi dinaikkan dan tertulis kecil di bagian bawah Beranda ("Snapin v2.2"). Kalau tulisan itu tidak muncul setelah update, berarti APK yang terpasang masih build lama.

## v2.3 (versionCode 13)
Pemilih galeri native diberi toast ("Memproses n foto...", pesan error) dan cadangan ke pemilih file web kalau pemilih bawaan gagal dibuka.

## v2.4 (versionCode 14)
- **Bingkai muncul di semua HP**: alamat server (https://snapin-server.vercel.app) sudah tertanam di APK lewat `DEFAULT_API_BASE`, jadi semua HP otomatis memuat bingkai.
- **Tahan sinyal lemah**: daftar bingkai dan gambar bingkai punya batas waktu dan diulang otomatis (juga saat sinyal kembali atau aplikasi dibuka lagi). Memilih bingkai yang belum terunduh akan menunggu unduhan selesai, tidak lagi memakai bingkai setengah jalan. Aplikasi tidak lagi tertahan saat start karena menunggu server.
- **Pindah foto** di halaman hasil: ketuk foto pertama lalu foto kedua untuk bertukar posisi (tombol "Pindah foto", muncul bila foto 2 atau lebih).
- **My Assets (Frame saya & Stiker saya)**: upload sekarang memakai pemilih foto bawaan Android, PNG/WebP transparan tetap utuh, bisa pilih beberapa sekaligus.
- **Wajah tidak lagi hijau**: bagian dalam lubang foto dijamin transparan 100%. Bingkai lama yang lubangnya masih berwarna polos dibersihkan otomatis saat diunduh ke HP (tidak perlu upload ulang).
- Versi tertulis "Snapin v2.4" di Beranda (versionCode 15).
- **Tata letak 2 foto**: setelah 2 foto diambil, muncul pilihan Strip (atas-bawah, seperti sebelumnya) atau 2 Kolom (kiri-kanan). Tombol "Ubah tata letak" di halaman hasil juga muncul untuk 2 foto.
- **Timer foto bisa diatur**: pil "Timer" di kanan atas layar kamera, ketuk untuk berganti 0 (langsung foto), 3, 5, 10 detik. Pilihan diingat di HP. Hitung mundur sekarang 1 detik per angka. Versi browser juga punya tombol timer yang sama.

## v2.4 (versionCode 16) - tambahan
- **Tombol hasil foto dirapikan**: Pindah foto, Putar 180°, dan Ambil ulang kini berupa tiga kartu sejajar dengan ikon SVG, bukan lagi tombol bulat besar.
- **Video dari galeri**: di pengaturan, pada mode Video, tombol kiri bawah menjadi "Pilih video". Video dari galeri (maksimal 60 detik dan 300 MB) diproses sama seperti hasil rekaman: dapat diberi bingkai dan stiker, disimpan, dan dibagikan. Layar galeri juga tersedia saat kamera tidak dapat diakses.
- **Teks aplikasi dibuat profesional**: sapaan "Anda", istilah baku (bingkai, stiker, berkas, perangkat, lanskap), dan pesan kesalahan yang lebih jelas, baik di aplikasi maupun di pesan kamera native. "My Assets" menjadi "Aset Saya".

## v10 (versi 2.5)
- **Stiker tidak lagi keluar dari bingkai**: stiker dipotong di tepi bingkai (tidak muncul di atas kartu "Gaya bingkai" dan bagian lain), titik tengah stiker dibatasi di dalam bingkai. Kotak pilihan dan pegangan digambar di lapisan terpisah supaya tetap bisa dipegang walau stiker di tepi.
- **Video kamera depan**: mode cermin bawaan CameraX dan rasio 16:9 dimatikan (sumber layar hitam di sebagian HP). Pembukaan kamera sekarang bertingkat: HD 16:9, lalu SD, lalu kualitas terendah; kalau gambar belum tampil dalam sekitar 3 detik, otomatis turun satu tingkat. Kompensasi eksposur depan dikurangi (+0.5 EV). **Hasil video kamera depan sekarang tidak dicerminkan** (seperti kamera bawaan HP). Kotlin belum bisa dikompilasi di sini, jadi perlu dites di HP.
- **Tombol play/pause pada video berbingkai**: sekarang berada di tengah video (bukan di pinggir bingkai), hilang saat video berjalan, dan muncul sebentar saat layar diketuk.
- **Bingkai bawaan untuk video**: 12 tema bawaan (Bunny Pink, Yellow Buddy, dst.) sekarang juga tersedia di mode video, dengan hiasan tetap di atas video. Dibuat mengikuti rasio video.
- **Bingkai video dari admin**: bingkai berupa video (MP4/WebM, disarankan 10 detik) diulang otomatis selama video pengguna berjalan (20 detik = 2 kali, 25 detik = 2,5 kali). Lubang foto dipotong dengan sudut membulat sesuai pengaturan admin.

## Dites di sini (Chromium, sentuhan nyata)
Geser, ubah ukuran, putar, cubit 2 jari, hapus, stiker diseret jauh keluar bingkai (tertahan di tepi), loop bingkai video (posisi bingkai = waktu video mod durasi bingkai), hasil render video 20 detik (bingkai terbukti berulang), tema bawaan di video.

## v11 (versi 2.6)
- **Kotak abu-abu dengan ikon play besar di bawah preview video**: itu elemen video bingkai (v10) yang ikut tampil saat tidak ada bingkai. Sekarang disembunyikan kecuali bingkai video dipilih. Tinggi preview kembali sama dengan videonya.
- **Kamera depan gelap di malam hari (video)**: eksposur awal depan dikembalikan ke +1.5 EV (di v10 sempat diturunkan) dan penyesuaian otomatis lebih agresif (target lebih terang, langkah sampai +1.5 EV, sampai batas maksimum HP). Rentang FPS target 15-30 diminta supaya eksposur bisa lebih lama di tempat gelap. Kalau setelah beberapa detik masih gelap, muncul **lampu cincin layar** (bingkai putih terang di tepi layar) sebagai penerang wajah, dan sebuah pesan singkat. Lampu dimatikan lagi saat kamera dibalik. Kode Kotlin belum bisa dikompilasi di sini, jadi perlu dites di HP.

## v12 (versi 2.6)
- **Lampu cincin layar dihapus** (kamera depan sudah normal menurut tes di HP). Perbaikan eksposur dan FPS kamera depan tetap dipakai.
- **Tulisan versi di halaman utama**: Snapin v2.6.
- **Layout baru untuk 3 dan 5 foto (bukan strip)**: foto lebar penuh sekarang bisa dipindah ke atas.
  - 3 foto: "1 Atas + 2 Bawah" (1 foto penuh di atas, 2 foto sejajar di bawah). Pilihan lama "2 Atas + 1 Bawah" tetap ada.
  - 5 foto: "1 Atas + 4 Bawah" (1 foto penuh di atas, grid 2x2 di bawah). Pilihan lama "4 Atas + 1 Bawah" tetap ada.
  - Dipilih di halaman Tata letak (dan lewat "Ubah tata letak" di halaman hasil). Foto pertama masuk ke kotak lebar di atas. Hiasan tema dan footer menyesuaikan otomatis.

## v13 (versi 2.6)
- **Durasi video 0 di galeri / lambat dibuka**: hasil render video berbingkai (WebM dari perekam bawaan WebView) tidak memuat durasi di header file. Sekarang durasi dan indeks posisi (Cues) ditulis ke file sebelum disimpan, jadi galeri membaca durasi yang benar dan bisa melompat. Berlaku juga untuk rekaman kamera versi browser. Dites: sebelum diperbaiki durasi tidak terbaca (N/A), sesudahnya 20,0 dan 60,0 detik, bisa dilompati, dan isi video tetap sinkron.
- **Video sampai 1 menit**:
  - Batas rekam kamera dinaikkan dari 30 ke 60 detik (`MAX_VIDEO_SECONDS`). Impor video dari galeri sudah 60 detik sejak awal.
  - Render video berbingkai dites 60 detik: selesai sekitar 61 detik, file sekitar 12 MB, bingkai video 10 detik berulang terus sampai akhir.
  - Bitrate menyesuaikan durasi (5 Mbps sampai 20 detik, 4 Mbps sampai 40 detik, 3,2 Mbps sampai 60 detik) supaya file dan memori tetap kecil.
  - Layar tidak mati selama proses (FLAG_KEEP_SCREEN_ON di MainActivity). Kalau aplikasi dibuka ke latar belakang saat render, perekaman dijeda bersama videonya lalu dilanjutkan, jadi hasil tidak membeku.
  - Teks progres sekarang menampilkan perkiraan sisa waktu.
- Catatan: aplikasi tidak memakai ffmpeg. Render memakai perekam bawaan WebView (MediaRecorder); ffmpeg hanya dipakai untuk memeriksa hasil saat pengujian.

## v14 (versi 2.6) - hanya jalur render video
- Pengiriman frame saat render video dibuat lebih rata: frame digambar tepat saat video punya frame baru (30 kali per detik, bukan 60 kali per detik lewat rAF) dan dikirim ke perekam dengan `requestFrame`. Encoder diubah ke VP8 lebih dulu (lebih ringan di HP daripada VP9). Di tes: jeda panjang antar frame turun dari 44 jadi 20 per 20 detik. Tidak ada perubahan lain (tampilan, kualitas, bitrate, kamera tidak disentuh).
- Diketahui, belum diubah: kamera depan meminta rentang FPS 15-30 (v11, supaya lebih terang di tempat gelap). Di ruangan sangat gelap kamera bisa merekam di sekitar 15 fps, dan itu terlihat patah-patah di hasil. Pilihan: biarkan, atau naikkan batas bawah jadi 24.

## v15 (versi 2.6) - eksposur video dinormalkan
- Video terlalu putih/terang: dorongan eksposur di v11 (+1,5 EV depan, +1,0 EV belakang) dihapus. Eksposur awal video sekarang 0 EV, sama seperti mode foto.
- Penyesuaian otomatis tinggal kecil: naik 0,5 EV per langkah hanya kalau gambar sangat gelap, turun kalau terlalu terang, dibatasi maksimal 1 EV di atas atau di bawah normal (sebelumnya bisa naik terus dan tidak pernah turun di bawah dorongan awal).
- Teks "Siap merekam (maksimal 30 detik)" diperbaiki jadi 60 detik (batasnya sudah 60 sejak v13).
- Tidak diubah: rentang FPS kamera depan, render video, dan bagian lain.

## v16 (versi 2.6) - render video dibangun ulang (stabil, tidak membeku di akhir)
Masalah: video hasil render membeku di akhir. Penyebab: render lama merekam layar secara real-time (MediaRecorder). Frame yang terlambat hilang, dan durasi di header hanya ditebak dari video sumber, jadi video berhenti di 19,7 detik sementara audio dan header menyatakan 20 detik.

Perbaikan (jalur render saja):
- **Engine baru (WebCodecs)**: setiap frame diberi cap waktu dari video sumber, bukan jam dinding. Frame digambar tepat saat video punya frame baru, lalu di-encode. Kalau ada frame terlewat atau antrean encoder menumpuk, putaran otomatis diperlambat (sampai 2x lebih lambat) supaya frame tidak hilang. Hasil render bisa memakan waktu sampai sekitar 2x durasi video di HP yang encodernya lambat.
- **Audio** didekode lalu di-encode terpisah, sinkron per sampel dan dipotong sesuai panjang video. Kalau audio gagal didekode padahal videonya punya suara, otomatis memakai jalur cadangan (tidak pernah menghasilkan video bisu secara diam-diam).
- **Format**: MP4 (H.264 + AAC, indeks di depan file) bila HP mendukung encoder H.264 dan AAC; kalau tidak, WebM (VP8 + Opus). Header (durasi, indeks) ditulis lengkap oleh aplikasi sendiri, jadi galeri membaca durasi yang benar.
- **Jalur cadangan** tetap ada: kalau WebCodecs tidak tersedia atau gagal di tengah, render memakai MediaRecorder seperti sebelumnya. Durasi file cadangan sekarang dibaca dari isi file (waktu blok terakhir), bukan tebakan.
- Bitrate: 4,5 Mbps (sampai 20 detik), 3,5 Mbps (sampai 40 detik), 2,5 Mbps (sampai 60 detik).

Dites (Chromium): 20 detik dan 60 detik, WebM dan MP4, tombol Batal, jalur cadangan, video tanpa suara, kegagalan dekode audio. Durasi tepat (60,000 detik), frame video dan audio berakhir bersamaan, bisa dilompati, tidak ada error decode. Muxer MP4 dengan AAC dites terpisah memakai data H.264/AAC dari ffmpeg (180 frame, 6,0 detik, bisa didekode). Belum dites di HP asli: encoder H.264 dan AAC perangkat keras (hanya ada di HP), jadi pilihan MP4 + AAC di HP-mu perlu dicoba.

## v17 (versi 2.6) - bingkai video: hiasan kembali di depan video
- **Masalah**: pada bingkai video, seluruh kotak lubang dipotong, jadi hiasan yang masuk ke area lubang (kucing di pojok, awan, selotip) ikut hilang dan video terlihat "ngambang" menutupi bingkai.
- **Perbaikan**: hanya warna lubang (hijau, magenta, dst.) yang dibuat transparan, per piksel, lewat WebGL di GPU. Warna lubang dikenali otomatis dari frame video itu sendiri, jadi bingkai video yang sudah diunggah sebelumnya langsung benar tanpa diunggah ulang. Hiasan di dalam area lubang tetap di depan video pengguna. Berlaku untuk pratinjau dan hasil render.
- Video bingkai transparan (WebM alpha) ditampilkan apa adanya. Lubang yang bukan warna polos memakai cara lama (potong kotak lubang).
- **Pengaman**: kalau WebGL terlalu lambat di sebuah HP saat render (rata-rata di atas 60 ms per frame), otomatis pindah ke cara lama supaya video tidak tersendat. Saat render, pratinjau (video, bingkai, WebGL) dihentikan sementara supaya tenaga perangkat dipakai penuh, lalu dilanjutkan setelah selesai.
- Dites di Chromium dengan bingkai uji berhiasan di dalam lubang: pratinjau dan hasil render 20 detik, hiasan terbukti di depan video. WebGL di komputer uji berjalan dengan emulasi perangkat lunak (lebih lambat dari GPU HP), jadi kecepatan di HP asli perlu dicoba.

## v18 (versi 2.6) - bingkai video lebih ringan dan tanpa kedip hitam di titik ulang
- **Kedip hitam di awal/akhir durasi bingkai** (titik video bingkai mengulang): saat video bingkai memulai ulang, framenya sesaat belum siap dan render menggambar frame tanpa bingkai (latar hitam). Sekarang frame seperti itu dilewati (satu frame sebelumnya ditahan sedikit lebih lama), atau memakai gambar bingkai terakhir yang masih tersimpan di GPU. Frame pertama bingkai juga disiapkan dulu sebelum perekaman dimulai.
- **HP kelas bawah** (RAM 3 GB atau kurang, atau CPU 4 inti atau kurang): resolusi render dibatasi 960 px sisi terpanjang (normalnya 1280) dan bitrate sedikit diturunkan. HP biasa tidak berubah.
- **Kalau render gagal di tengah** (kehabisan memori, encoder error): otomatis dicoba sekali lagi dengan pengaturan ringan (resolusi maks 800 px, 24 fps, bitrate 70%) sebelum memakai cara cadangan yang lebih berat. Callback frame sekarang juga dilindungi try/catch supaya galat tidak membuat proses macet menunggu.
- Memori GPU: konteks WebGL pemotong warna dilepas setelah render dan saat berganti bingkai; resolusi WebGL pratinjau dibatasi 720 px, di render mengikuti ukuran video hasil.
- Dites (Chromium): render normal 20 detik (tanpa frame gelap), mode HP kelas bawah, dan percobaan ulang ringan setelah kegagalan yang disengaja (hasil 450x800, durasi tepat). Kedip hitam aslinya tidak muncul di komputer uji (baik sebelum maupun sesudah), jadi perbaikan ini berdasarkan penyebab yang paling masuk akal dan perlu dicoba di HP asli.

## v19 (versi 2.7) - pratinjau video dan bingkai lebih stabil
Versi di halaman utama dan build.gradle: 2.7 (versionCode 26).

Penyebab bingkai animasi tiba-tiba diam / error:
- **Alamat blob bingkai dicabut saat masih dipakai.** Setiap unduhan bingkai di latar belakang selesai, daftar bingkai dibuat ulang dan semua alamat blob lama dicabut, padahal bingkai video yang sedang diputar (dan gambar bingkai) masih memakainya. Sekarang alamat dibuat sekali per berkas dan dipakai terus; yang sudah tidak berlaku baru dicabut setelah 60 detik.
- **Video dijeda sistem lalu tidak lanjut** (aplikasi ke latar belakang / layar mati). Sekarang otomatis dilanjutkan saat aplikasi kembali, kecuali pengguna sendiri yang menjeda.
- **Pengawas bingkai**: kalau video utama berjalan tapi bingkai tidak maju sekitar 1 detik, bingkai disinkronkan ulang; kalau masih diam sekitar 3 detik, sumbernya dimuat ulang dan pemotong warna dipasang lagi.
- **Konteks WebGL hilang** (memori GPU habis): pratinjau langsung pindah ke cara hemat tanpa WebGL, tidak membeku.

Penyebab video patah-patah di aplikasi:
- **Sinkron bingkai dengan seek berulang** diganti penyesuaian kecepatan putar kecil (mulus); seek hanya dipakai kalau selisih lebih dari 0,6 detik. Loop sinkron sekarang berjalan tiap 80 ms (sebelumnya tiap frame layar).
- **Pemantau kualitas**: kalau lebih dari 20% frame video terbuang selama 2 jendela (6 detik), beban diturunkan bertahap: tingkat 1 = WebGL 480 px dan gambar tiap 2 frame, tingkat 2 = tanpa WebGL (potong kotak lubang). Hanya turun, tidak naik lagi sampai bingkai dipilih ulang.
- **Unduhan bingkai di latar belakang** ditunda selama video hasil sedang diputar atau diproses (sebelumnya bisa berjalan bersamaan dan membuat tersendat).
- Pratinjau tidak menggambar saat aplikasi di latar belakang.

Dites (Chromium): URL blob tetap sama setelah rehydrate dua kali dan bingkai tetap berjalan; lanjut putar setelah visibilitychange; pemulihan setelah sumber bingkai dicabut paksa (kembali sinkron dalam sekitar 6 detik); penurunan kualitas tingkat 1 dan 2; render 20 detik (bingkai berulang di detik 3 dan 13, tidak ada frame gelap). Kecepatan di HP asli dan perilaku latar belakang WebView Android belum bisa dites di sini.

## v20 (versi 2.7) - UI bingkai premium, WhatsApp admin, dan QRIS
- **Chip bingkai premium dirapikan**: mahkota dan gembok kini lencana kecil (20 px) di sudut atas, tidak menutupi gambar bingkai; harga berupa label kecil di bawah nama (bukan di atas gambar). Label semua chip sejajar di bagian atas.
- **Kartu "Standar/Tebal"** sekarang lebar penuh, sejajar margin halaman, tinggi sama, teks rata atas (sebelumnya terdorong ke tengah karena padding ganda).
- **Nomor WhatsApp admin muncul di aplikasi**: kolom itu sebenarnya sudah tersimpan di server, tetapi aplikasi tidak pernah membacanya. Sekarang tombol "Chat admin via WhatsApp" ada di halaman Toko, di dialog "Buka bingkai berbayar" (Beli kode lewat WhatsApp), dan di dialog saat QRIS gagal dibuat, dengan pesan awal berisi nama bingkai.
- **QRIS gagal dibuat**: dialog sekarang menampilkan tombol Coba lagi dan WhatsApp, plus **kode alasan** (contoh "HTTP 401" atau "NETWORK"), bukan sekadar pesan umum.
- Server QRIS: pemeriksaan biaya terlalu ketat (menolak jawaban PunyaKios yang sah kalau biaya minimum lebih besar dari 3% + Rp300, mis. untuk harga Rp1.000). Sekarang biaya = total - harga dan dibatasi maksimal Rp2.500 atau 5% harga (mana yang lebih besar); angka `fee_amount` tidak lagi dipakai untuk menolak.

## v21 (versi 2.8) - Kreasi Saya, wallpaper, bingkai & stiker baru
Versi di halaman utama dan build.gradle: 2.8 (versionCode 28). Fitur lama tidak diubah; data lama (bingkai/stiker kustom, aset server) tetap dipakai.
- **Kreasi Saya** (ikon di pojok kanan atas beranda + kartu di "Koleksi Anda"): simpan proyek photobooth terstruktur (foto asli sebagai Blob, tata letak, rasio, filter, bingkai, gaya, stiker lengkap dengan posisi/ukuran/putaran). Bisa dibuka & diedit ulang, ganti nama, duplikat, hapus (ada konfirmasi), wallpaper. Disimpan di IndexedDB terpisah `snapin-projects` (daftar hanya membaca data ringan; data penuh dimuat saat dibuka). Video belum bisa disimpan sebagai kreasi.
- **Halaman hasil**: tombol baru "Ganti foto" (ganti foto per slot dari galeri, otomatis dipotong sesuai rasio), "Simpan ke Kreasi / Simpan perubahan", "Wallpaper". Bingkai atau stiker yang sudah dihapus/terkunci saat kreasi dibuka diganti Polos dengan pemberitahuan.
- **Wallpaper**: ukuran mengikuti layar HP, mode "Utuh" (tidak terpotong, zona aman) atau "Penuh layar", latar buram/putih/gelap/warna bingkai, zoom dan geser. "Simpan ke galeri" selalu tersedia. Di APK ada tombol pasang langsung ke layar utama/kunci/keduanya (FileBridge.setWallpaper + izin SET_WALLPAPER) - bagian native ini belum dites di HP asli (tidak ada Android SDK di lingkungan pengujian).
- **Bingkai bawaan**: 22 tema baru (total 34 + Polos) di 10 kategori dengan filter kategori; thumbnail dibuat bertahap supaya HP kelas bawah tidak tersendat. Bingkai lama tidak diubah. Bingkai tema memakai lubang transparan (bukan hijau); pengenalan hijau #00FF00 untuk bingkai unggahan tidak berubah.
- **Bingkai Saya**: nama bingkai diisi pengguna saat unggah (nama berkas hanya saran awal), tersimpan sebagai metadata, tampil di koleksi dan daftar bingkai; pratinjau, ganti nama, hapus dengan konfirmasi.
- **Stiker bawaan**: 107 stiker vektor SVG di 10 kategori + tab "Stiker saya"; gerak/zoom/putar/hapus memakai mesin layer yang sama.
- Dites di Chromium (alur lengkap lewat klik dan unggah berkas): buat, simpan, buka ulang setelah reload, ganti foto/bingkai, tambah/hapus stiker, simpan perubahan, unggah bingkai bernama, ganti nama, pakai bingkai, ekspor PNG, wallpaper, hapus kreasi, empty state. Tanpa galat JavaScript.

## v22 (2.8, revisi) - rapikan bingkai, simpan otomatis, stiker admin
- **Kreasi Saya** dipindah ke bawah tombol "Mulai Photobooth" (ikon di pojok atas dihapus).
- **Simpan otomatis**: tombol "Simpan ke Kreasi" dan "Wallpaper" dihapus dari halaman hasil. Setiap photobooth otomatis masuk Kreasi Saya, dan perubahan (bingkai, stiker, foto, filter) tersimpan otomatis. Wallpaper hanya lewat Kreasi Saya.
- **Bingkai dirapikan**: dekorasi bingkai baru dan 5 bingkai lama (buddy, cloud, ocean, party, winter) tidak lagi menutupi foto, teks pas di dalam pil, dekorasi mengikuti ukuran margin di semua tata letak. Gambar kecil bingkai kini memakai foto contoh dan tata letak yang sedang dipakai (tidak lagi pucat).
- **Hapus latar putih diperkuat** (`sbgRemove`): hanya putih yang tersambung ke tepi yang dihapus, putih di dalam stiker (mata, kilau, tulisan) aman; tepi dihaluskan tanpa garis putih; ada pratinjau, slider kekuatan, dan opsi lubang putih besar. Dipakai saat unggah stiker di Aset Saya dan saat tambah stiker dari galeri.
- **Stiker dari Snapin Admin**: aplikasi mengambil `/api/stickers` dan menyimpannya di perangkat (offline); tampil paling depan di kategorinya.

## v23 - workflow GitHub untuk repo PUBLIC + kunci lewat Secrets
- `.github/workflows/build-apk.yml`: build otomatis di runner gratis (ubuntu-latest), cache Gradle, batalkan build lama, hasil APK `snapin-v<versi>.apk` otomatis masuk **GitHub Releases** (tag `v<versi>`) dan artifact 14 hari.
- Kunci tanda tangan **tidak lagi disimpan di repo** (`app/snapin.keystore` dihapus dari paket, `.gitignore` memblokirnya). Isi 2 Secrets di repo: `SNAPIN_KEYSTORE_BASE64` (isi file SNAPIN_KEYSTORE_BASE64.txt) dan `SNAPIN_STORE_PASSWORD`. Opsional: `SNAPIN_KEY_ALIAS` (default snapin), `SNAPIN_KEY_PASSWORD` (default sama dengan store password).
- Tanpa Secrets build tetap jalan, tetapi APK memakai kunci debug sementara sehingga tidak bisa menimpa aplikasi lama yang terpasang.

## v24 (2.8) - Foto live
- Pengaturan Photobooth > "Foto live": tiap jepretan merekam klip 2 detik (1 dtk sebelum + 1 dtk sesudah jepret). Hasil: kotak bingkai bergerak 2 detik, tiba-tiba diam di foto utama (~1,3 dtk), lalu mengulang. Berlaku untuk bingkai bawaan, bingkai buatan sendiri, dan bingkai gambar dari admin.
- Saat foto live aktif, APK memakai kamera web (WebView) agar klip bisa direkam; HP kelas bawah memakai 10 fps/256 px, lainnya 12 fps/360 px.
- Foto live bawaan HP (Motion Photo Android: JPEG + MP4 di ujung berkas) dibaca dari tombol Galeri; foto biasa tetap diam.
- Tombol "Simpan video live" / "Bagikan video" (MP4 bila didukung, selain itu WebM), ~7 detik dua putaran, stiker ikut. Simpan PNG tetap foto diam.
- Klip ikut tersimpan di Kreasi Saya (kartu berlabel LIVE), ikut saat Pindah foto / Putar 180, dan dibuang bila fotonya diganti dari galeri.

## v25 (2.8) - ikon flash / foto live / timer di kamera
- Kamera native (Kotlin) dan kamera web: flash dan timer kini ikon vektor (bukan teks), dengan ikon **foto live di tengah** di antara flash (kiri) dan timer (kanan). Timer memakai angka kecil di sudut ikon; flash punya ikon mati / nyala / otomatis (native).
- Saklar foto live dipindah dari Pengaturan ke ikon di kamera. Di kamera native, mengetuk ikon foto live menutup kamera native dan membuka kamera web yang bisa merekam klip; mematikannya di kamera web kembali ke kamera native.
- Kamera web punya flash: lampu senter HP (kamera belakang, bila didukung) atau layar putih sesaat (kamera depan).
- Bagian Kotlin (CameraActivity, CameraSession, MainActivity, ikon di res/drawable) belum dikompilasi atau dites di HP.

## v26 - perbaikan build
- CameraActivity.kt: tambah `import android.app.Activity` (build GitHub gagal: "Unresolved reference: Activity").

## v27 (tetap versi 2.8) - foto live di kamera yang sama, flash 3 mode, tema Hitam Elegan
- Versi aplikasi tetap **2.8** (versionName). versionCode tetap 29 supaya bisa menimpa APK yang sudah terpasang (angka kecil ditolak Android).
- **Foto live tanpa pindah kamera**: ikon foto live di kamera native kini merekam di kamera itu juga (ImageAnalysis, 1 detik sebelum + 1 detik sesudah jepret) dan frame dikirim ke halaman lewat `SnapinCamera.clipInfo/clipFrame`. Bila kamera tidak bisa preview + foto + analisis sekaligus, otomatis kembali ke foto biasa dengan pemberitahuan.
- **Flash 3 mode** di kamera web: mati / nyala / otomatis (otomatis menyala bila gambar gelap), ikon vektor; kamera belakang memakai senter, kamera depan memakai layar putih.
- **Tema & ikon**: tombol palet di beranda membuka pemilih "Pink (feminin)" / "Hitam Elegan (maskulin)". Hitam Elegan mengubah warna seluruh halaman, kamera native, status bar, dan ikon aplikasi di layar HP (activity-alias LauncherPink / LauncherElegant, `AppTheme.kt`, `FileBridge.setAppTheme`).
- Catatan: ikon peluncur berpindah lewat alias, jadi ikon lama di layar HP bisa hilang sekali setelah memasang versi ini (buka laci aplikasi lalu tambahkan lagi). Semua kode Kotlin dan manifest belum dikompilasi di sini.

## v28 (tetap versi 2.8, versionCode 29) - menu per kotak foto (butir 3.2)
- Di halaman hasil, mengetuk satu foto membuka menu: **Ganti foto** (galeri, dipotong ke rasio kotak, klip foto live kotak itu dibuang), **Ambil ulang** (kamera hanya untuk kotak itu; foto live ikut bila aktif) dan **Pindah foto** (pilih foto lain untuk ditukar; hanya tampil bila foto lebih dari satu).
- Tombol "Ganti foto" global dihapus. "Pindah foto", "Putar 180" dan "Ambil ulang" (semua foto) tetap ada.
- Ambil ulang satu kotak: kamera web memakai jalur yang sama dengan pengambilan biasa; kamera native dibuka dengan count=1 (tanpa perubahan Kotlin). Tombol kembali dari kamera mengembalikan ke halaman hasil tanpa mengubah foto.
- Posisi kotak (`SLOT_RECTS`) disimpan saat render, termasuk bingkai gambar dari admin.
- Asumsi: foto hasil ambil ulang dipotong ke `state.captureAspect` sesi awal agar bentuk kotak tetap sama.
- Dites (Chromium): menu muncul di kotak yang diketuk, tukar posisi, ambil ulang masuk jalur kamera, kembali ke hasil, tanpa galat JS. Belum dites: jalur kamera native di HP asli, dan hasil jepret ulang sungguhan (headless tanpa kamera).
- Butir 3.1 dan 3.3-3.7 belum dikerjakan di versi ini.

## v29 (tetap versi 2.8, versionCode 29) - animasi printing (butir 3.4)
- Tombol baru **Selesai, cetak strip** di halaman hasil (foto saja; video tidak). Setelah diketuk: layar gelap, celah printer di atas, strip keluar pelan dari ujung atas dengan percikan kecil, teks "Mencetak..." lalu "Simpan!". Ketuk layar untuk melewati animasi.
- Setelah animasi strip tampil di tengah dengan tombol Simpan, Bagikan, Wallpaper (memakai alur simpan/bagikan/wallpaper yang sudah ada) dan Tutup. Tombol kembali menutup layar ini. CSS saja, tanpa pustaka.
- Keterbatasan: strip pada animasi berupa gambar diam, belum bergerak untuk foto live (ekspor video live tetap lewat tombol yang ada).
- Dites (Chromium): animasi berjalan, keadaan siap, tombol muat di layar 390 px, Wallpaper membuka editor. Tanpa galat JS.

## v30 (tetap versi 2.8, versionCode 29) - pembuat tema di aplikasi (butir 3.3, bagian aplikasi)
- Chip **Buat tema** di daftar bingkai halaman hasil membuka editor: 12 pola yang digambar kode (polos, gradasi, linen, denim, satin, rajut, kanvas, garis panjang, garis vertikal, garis diagonal, kotak-kotak, titik), warna utama dan kedua, warna garis tepi foto, ukuran pola, ketebalan/jarak, dan pratinjau langsung.
- Tema disimpan di IndexedDB `snapin-themes` (nama + pengaturan), muncul di kategori **Tema saya**, tetap ada setelah aplikasi dibuka ulang, tersedia offline. Saat tema dipilih muncul tombol Ubah tema, Ganti nama, Hapus tema (hapus ada konfirmasi).
- **Bingkai Polos** kini bisa diganti warnanya (8 warna siap pakai + pemilih warna bebas), diingat di perangkat.
- Tema memakai jalur gambar bingkai bawaan, jadi ikut ekspor PNG dan foto live yang memakai bingkai vektor.
- Belum dikerjakan: tema buatan admin di dashboard (`theme-*` di `api/admin.js`, `/api/themes`), tema untuk mode video.
- Catatan: kreasi lama yang memakai tema sebelum daftar tema selesai dimuat bisa jatuh ke Polos; dibuka ulang akan normal.
- Dites (Chromium): ganti warna Polos, buat tema Denim, ganti ke semua 12 pola tanpa galat, simpan, tampil di hasil, tetap ada setelah reload.

## v31 (tetap versi 2.8, versionCode 29) - tema dari admin dan bingkai hati
- **Tema dari admin**: aplikasi mengunduh `/api/themes` dan menyimpannya offline (RemoteStore, seperti stiker); tema tampil di kategori "Tema saya" (tanpa tombol ubah/hapus karena milik admin). Server: `api/themes.js`, aksi `theme-list/save/update/delete` di `api/admin.js`, `readThemes/writeThemes` di `lib/store.js`; dashboard admin punya bagian "Tema" dengan editor pola yang sama.
- **Bingkai bentuk hati** "Hati Mutiara": lubang foto berbentuk hati dengan tepi mutiara (gradasi radial + bayangan) dan bintang glitter pink/putih. Bentuk lubang non-persegi didukung lewat `holePath()` (klip foto, garis tepi, thumbnail, overlay foto live/video dengan lubang destination-out, ekspor).
- Semua 36 bingkai dirender di tata letak strip 3 foto dan grid 2x2 dan diperiksa lewat lembar kontak; tidak ada galat. Bingkai lama yang sengaja menimpa foto tidak diubah.
- Belum dites: tampilan admin di server asli (hanya sintaks dan API tiruan), foto live/video dengan bingkai hati di HP asli.

## v32 - perbaikan build GitHub Actions
- Build gagal di `CameraActivity.kt` baris 321 dan 339: `Unresolved reference: cycleFlash` / `cycleTimer`. Kedua fungsi dipanggil tombol flash dan timer tetapi tidak ada di file (sudah begitu sejak v27). Ditambahkan: `cycleFlash()` (mati, nyala, otomatis hanya kamera belakang untuk foto) dan `cycleTimer()` (0, 3, 5, 10 detik, tersimpan di `snapin_prefs`). Semua simbol yang dipakai (`busy`, `isFront`, `applyFlash`, `updateFlashLabel`, `updateTimerLabel`, `TIMERS`, `toast`) sudah ada.
- Belum bisa dikompilasi di sini (tanpa Gradle/Android SDK); hanya galat yang tertera di log yang diperbaiki. Bila ada galat lain, kirim log lagi.

## v33 - tampilan maskulin putih, printer 3D, editor wallpaper berlapis
- **Tema elegan (maskulin) dibalik**: sekarang dominan putih (#F4F4F5, kartu putih, teks hitam) dengan aksen hitam; seluruh aturan CSS elegan dibalik otomatis kecuali area kamera/bingkai ponsel pratinjau. Status bar dan bar navigasi native ikut putih dengan ikon gelap; kamera native memakai latar putih dan teks gelap (`AppTheme.kt`, `CameraActivity.applyPalette`).
- **Printing langsung saat Simpan** (foto): tombol "Selesai, cetak strip" dihapus. Simpan menyimpan lalu langsung membuka animasi printing. Tombol **Bagikan** di layar printing dihapus; sisa Wallpaper dan Selesai.
- **Mesin printer 3D (CSS)**: badan dengan sisi atas, muka depan berbayang, LED berkedip, ventilasi, celah gelap; strip keluar dari celah dengan getaran kecil. Elegan = badan hitam di latar putih, Pink = badan pink di latar krem.
- **Editor wallpaper berlapis** (bukan lagi satu gambar): hasil utama, stiker (bawaan, server, milik sendiri), foto dari galeri, dan kreasi tersimpan (bisa beberapa) adalah lapisan yang bisa digeser, dicubit dua jari untuk memperbesar dan memutar (min 4%), dihapus, dibawa ke depan, dan diatur ukurannya dengan slider. Latar baru: Pola (12 pola, dua warna) dan Galeri; pratinjau layar kunci (jam dan tanggal). Menu Kreasi Saya mendapat **Wallpaper baru** (kanvas kosong) dan **Tema (kolase)** dengan ukuran kanvas Layar HP, 1:1, 4:5, 9:16.
- Keterbatasan: foto live pada kreasi yang ditempel menjadi gambar diam; menempel kreasi memuat proyek itu ke memori sehingga tombol kembali menuju daftar Kreasi.
- Dites (Chromium): tema elegan dan pink, animasi printing, lapisan stiker/foto/pola, simpan wallpaper tanpa galat. Belum dites: gestur cubit di HP asli, build Gradle.

## v34 - unsur semi-realistis (butir 3.6)
- Kategori stiker baru **Realistis** (16 stiker digambar kode, tanpa berkas gambar): mawar berlapis, sakura, daisy, daun dengan urat, ranting, mutiara, untaian mutiara, berlian bersisi, permata hati ruby, pita satin, renda, glitter bintang, label kayu, kertas sobek, washi tape, tambalan denim. Dibuat sekali saat kategori dibuka, tampil di baki stiker hasil foto dan di editor wallpaper.
- Kategori bingkai baru **Realistis**: "Hati Mutiara" dipindah ke sini, ditambah **Mawar & Mutiara** (tepi mutiara tiap foto, mawar, sakura, ranting dan daun di sudut, latar linen).
- Foto yang benar-benar nyata tetap lewat unggah PNG di Snapin Admin (sudah ada).
- Dites (Chromium): semua 16 stiker dirender, stiker masuk ke hasil, bingkai baru dirender, tanpa galat JS. Rangkaian regresi (menu kotak foto, tema, wallpaper berlapis, simpan wallpaper, tema Pink/Elegan, printing) lulus. Tes lama yang memakai tombol "Selesai" sengaja tidak dijalankan karena tombolnya sudah dihapus.
- Belum dikerjakan (opsional, prioritas rendah di prompt): dashboard admin mengikuti tema Pink/Elegan.

## v35 - template wallpaper dan kolase, editor dirapikan
- **Menu Kolase** di sheet tiap kreasi (Buka & edit, Wallpaper, Kolase, Duplikat, Ganti nama, Hapus). Di halaman Kreasi Saya ada Wallpaper baru dan Kolase baru.
- **Pilih template**: memilih Wallpaper atau Kolase membuka halaman template (kartu pratinjau berisi kreasi/foto pengguna yang sudah terpasang). Setelah memilih template, kreasi/foto langsung terisi dan bisa diedit: tambah stiker, foto galeri, kreasi lain, ganti latar, atur ukuran. Paling bawah ada kartu **Buat sendiri dari awal** (editor kosong). Tombol **Template** di editor untuk ganti template.
- **Template bawaan (kode)**: 6 wallpaper (Gingham Merah, Linen Pink, Denim Biru, Hitam Putih, Mawar, Polkadot) dan 7 kolase (Polaroid Gingham, Strip 4 Foto, Empat Hati, Scrapbook, Denim 4 Foto, Film Hitam, Dua Bulat) memakai stiker realistis dan pola dari kode.
- **Kotak foto**: ketuk = menu (galeri, kreasi tersimpan, tampil utuh/penuh, atur ulang, hapus); geser = atur posisi; cubit = zoom.
- **Editor dirapikan**: pratinjau besar, panel bertab (Tambah, Latar, Lapisan, Pengaturan) dengan ubin dan chip yang bisa digulir, tombol simpan di bawah. Kolase tanpa bingkai ponsel; Kolase hanya Simpan kolase (tanpa Jadikan wallpaper).
- **Template dari Snapin Admin**: bagian baru "Template Wallpaper dan Kolase" - unggah PNG/WebP (bagian transparan atau warna polos = lubang foto, terdeteksi otomatis), pilih jenis Wallpaper atau Kolase, ganti nama, pindah jenis, hapus. Server: `api/templates.js`, `api/template-img.js`, aksi `template-list/save/update/delete`. Aplikasi mengunduh dan menyimpan offline (RemoteStore) lalu tampil di picker paling atas.
- Perbaikan: pratinjau editor "Buat tema" kini di tengah.
- Dites (Chromium): picker wallpaper dan kolase, pilih template, isi otomatis dari kreasi/foto, menu kotak foto, simpan; tema maskulin; regresi menu kotak foto per kreasi (nama fungsi bentrok sudah diperbaiki), tema, stiker realistis, wallpaper berlapis. Belum dites: template admin dengan server asli, gestur di HP asli.

## v36 - bingkai dan latar dekor dengan aset yang bisa dipilih
- **14 bingkai + latar baru** (kategori Realistis, digambar kode): Gingham Merah/Hijau/Pink/Biru, Denim Kantong, Linen Krem, Satin Mawar, Polkadot Coklat, Kertas Kraft, Film Hitam, Pastel Lembut, Garis Mint, Satin Lavender, Senja. Latar, garis foto, dan pola semuanya berbasis data (`BASES`), jadi mudah menambah latar baru.
- **8 slot aset di tepi tiap bingkai** (kiri atas, kanan atas, kiri bawah, kanan bawah, tengah kiri, tengah kanan, atas tengah, bawah tengah). Setiap bingkai punya aset bawaan, dan pengguna memilih sendiri lewat **Pilih aset bingkai** (di bawah daftar bingkai): ketuk posisi, pilih dari **Elemen** (29 elemen kode), **Stiker** (bawaan, dari server, dan stiker sendiri), atau **Kosong**. Pilihan tersimpan di perangkat per bingkai; **Atur ulang** mengembalikan bawaan.
- **13 elemen aesthetic baru** di kategori stiker Realistis: tulip, kamera digicam, kancing, hati ganda, apel, bintang denim, pemutar musik, struk, tiket PHOTO TIME, lily, ceri, stroberi, film strip.
- **Cara memasukkan aset kiriman Anda**: unggah PNG berlatar transparan lewat bagian Stiker di Snapin Admin (sudah ada). Otomatis muncul di tab Stiker pada pemilih aset bingkai, di baki stiker, dan di editor wallpaper/kolase.
- Tidak termasuk: bingkai dekor dengan aset terkunci dari admin (belum dibuat; sementara pengguna memilih sendiri).

## v37 - elemen chrome dan mono, template miring per jumlah foto
- Dihapus: tombol **Wallpaper baru** dan **Kolase baru** di halaman Kreasi Saya (sesuai tanda lingkaran). Wallpaper dan Kolase tetap lewat sheet tiap kreasi.
- **18 elemen kiriman Anda** dipotong dari latar (putih, abu-abu, kotak-kotak palsu) menjadi WebP transparan, dikemas di `www/elements.js` (645 KB) dan masuk ke kategori stiker baru **Chrome & Mono**: saturnus, bintang 3, jam meleleh, kilau, not musik, bintang jatuh, bulan bintang, bintang, reaksi emoji, bintang runcing, tanda seru, mata, halftone, bintang kertas, clapperboard, plat MEMORIES, kamera stiker, kamera klasik + foto. Bisa dipakai di hasil foto, editor wallpaper/kolase, dan pemilih aset bingkai.
- **Template miring (polaroid + selotip) untuk setiap jumlah foto 1-6**, wallpaper dan kolase, dua gaya: **Chrome Y2K** (elemen perak) dan **Mono Kamera** (hitam putih: kamera, clapperboard, plat, tanda seru, mata, halftone, bintang kertas). Total 24 template. Latar baru "Kertas kusut" (lipatan terang-gelap).
- **Wallpaper menyesuaikan jumlah foto**: dari sheet kreasi, picker hanya menampilkan template yang kotaknya sama dengan jumlah foto kreasi, dan tiap foto langsung mengisi satu kotak (strip lama tetap tersedia untuk template strip).
- Dites (Chromium): picker wallpaper 4 foto dan kolase 3 foto terisi dan tampil, regresi lain lulus.
- Catatan kualitas: elemen berasal dari JPG, potongan tepi bisa sedikit kasar; PNG transparan asli akan lebih rapi.

## v38 - set Merah, Biru, Pink, Jeans + kartu pemutar musik + koleksi latar
- **68 elemen baru** dari kiriman Anda dipotong dari latar dan dikemas di `www/elements2.js` (1,6 MB). Masuk kategori stiker **Biru, Merah, Pink, Jeans**. Tidak dipakai: gambar referensi cewek, kartu pemutar bawaan (diganti buatan kode), dan elemen bewatermark pngtree.
- **12 latar penuh layar** dikemas di `www/bg.js` (1,2 MB) dan tersedia sebagai chip **Koleksi** di tab Latar editor wallpaper/kolase (denim, gingham, pusaran pink, piksel biru, chrome, loker).
- **Template baru**: Merah, Biru, Pink, Jeans, masing-masing 1 wallpaper + 1 kolase yang menyesuaikan 1 sampai 6 foto (48 template), polaroid miring + selotip + elemen warna set + elemen di sudut foto. Chrome Y2K kini memakai latar chrome (bintang perak untuk wallpaper, jelly untuk kolase). Mono tetap.
- **Kartu pemutar musik buatan kode** (gambar sendiri, bukan salinan): sampul = kotak foto pengguna, judul "our memories", bar progres, tombol acak/mundur/jeda/maju/ulang, plus piringan vinyl di sudut. Empat tema warna (pink, merah, biru, denim). Dipakai di wallpaper 1 foto dan kolase 1 sampai 2 foto, digambar paling atas agar kontrolnya terlihat.
- **Dua template bingkai tempel (kolase 1 foto)**: bingkai denim berkancing (Jeans) dan bingkai Instagram berhati (Pink). Lubang bingkai terdeteksi otomatis dan jadi kotak foto.
- Dites (Chromium): semua template dirender, picker wallpaper dan kolase, pemilihan template, regresi lama lulus.
- Belum ada: penghapus latar otomatis untuk foto orang (kolase gaya referensi cewek); kolase tetap memakai foto utuh di polaroid.
- Catatan: latar berukuran 640 px (sumber 736 px) sehingga sedikit lembut di wallpaper; beberapa elemen membawa karakter atau merek pihak lain (Stitch, Prada, Taylor Swift, The 1975, Canon, Sony, Sonny Angel, Miffy, Leica, Squier) - pertimbangkan sebelum dipublikasikan.

## v39 - foto live halus dan tidak terpotong, strip, bingkai premium bawaan, deteksi lubang miring
- **Foto live tidak lagi memotong elemen**: penyebab garis memotong elemen adalah garis tepi foto live yang setengahnya jatuh di luar kotak dan tidak ikut ditimpa elemen. Sekarang area sekitar kotak dipulihkan dulu dari tampilan statis, foto digambar, garis tepi, lalu elemen bingkai digambar ulang di atasnya (area diperluas 6 px).
- **Foto live di bingkai berbentuk hati** kini dipotong mengikuti hati (sebelumnya kotak persegi sehingga foto keluar dari hati).
- **Foto live halus (tidak patah-patah)**: bingkai rekaman dicampur (cross-fade 5 tingkat) di antara dua bingkai, pemutaran digambar sekitar 33 fps (perangkat ringan 21 fps) alih-alih 14 fps, dan rekaman 15 fps di perangkat normal (10 fps perangkat ringan). Berlaku juga untuk ekspor video live.
- **Elemen bingkai realistis dikecilkan** sekitar 35 persen (14 bingkai dekor dan Mawar & Mutiara).
- **Ikon mahkota diperbaiki** (SVG emas dengan permata, di lencana premium) dan versi kanvas untuk gambar.
- **Bingkai bawaan bisa dijadikan premium dari server**: kartu baru "Bingkai bawaan premium" di Snapin Admin (daftar 50 bingkai bawaan, centang + harga). Bingkai terpilih tampil dengan mahkota dan terkunci; dibuka lewat QRIS per bingkai (harga dari admin), kode redeem, atau paket "Semua bingkai berbayar". Server: aksi `builtin-get` dan `builtin-save`, katalog QRIS memuat `builtin`, pembelian bingkai bawaan didukung.
- **Template STRIP**: 1 strip dan 2 strip untuk wallpaper dan kolase (kolase 9:16) di semua set (Merah, Biru, Pink, Jeans, Chrome, Mono). Isinya hasil kreasi utuh; ketuk strip lalu "Dari kreasi tersimpan" untuk menggantinya ke kreasi lain. Set Jeans memasang kantong jeans di depan strip.
- **Unggah template di admin mendukung lubang miring dan layar hijau**: deteksi lubang memakai analisis komponen + orientasi (PCA) sehingga mendapat posisi dan sudut putar tiap lubang (nomor sesuai urutan baca); warna kunci hijau, magenta, cyan, kuning tetap dikenali. Sudut disimpan di server (`rot`) dan dipakai aplikasi.
- Dites (Chromium): live di hati, kehalusan (30 keadaan per 2 detik), strip, deteksi miring (-8 dan 6,2 derajat akurat), regresi lama lulus. Belum dites di HP dan Gradle.

## v40 - kolase lebih lega dan aesthetic, foto live lebih ringan
- **Foto live lebih ringan dan stabil**: versi v39 memang lebih berat (campur bingkai + pemulihan area besar tiap bingkai) sehingga di HP justru lebih patah-patah. Perbaikan: overlay elemen hanya digambar ulang di petak 64 px yang benar-benar berisi elemen (bukan seluruh kotak), area kotak tidak lagi dipulihkan penuh tiap bingkai (hanya saat jeda), kecepatan gambar menyesuaikan beban perangkat (28-80 ms per bingkai, diukur terus), dan campur bingkai halus otomatis dimatikan saat perangkat berat (dengan histeresis supaya tidak berkedip). Uji headless: 21,4 ms menjadi 13,4 ms per bingkai pada kanvas 4 foto 820x4230.
- **Jarak foto di kolase dan wallpaper diperlebar**: tata letak dibuat ulang (jarak antar foto, kemiringan hanya sekitar 2 derajat). Kolase 3 sampai 6 foto memakai kanvas 9:16 (1080x1920) agar lega; 1 sampai 2 foto tetap 4:5.
- **Gaya bingkai foto baru**: **perangko** (kartu krem bergerigi dengan garis putus-putus), **film** (strip hitam berlubang), selain polaroid. Merah dan Pink memakai perangko, Jeans dan Mono memakai film, Biru dan Chrome polaroid.
- **Varian B** untuk setiap template (gaya bingkai ditukar dan hiasan dicerminkan), jadi 2 pilihan tiap set per jumlah foto. Total template bawaan sekarang lebih dari 160.
- Dites (Chromium): render kolase dan wallpaper tiap set, live di bingkai hati, regresi lama lulus.

## v41 - strip lebih besar
- Template strip (1 dan 2 strip) diperbesar mengikuti referensi Pinterest: wallpaper 2 strip masing-masing sekitar 50% lebar dan 70% tinggi layar (saling menumpuk sedikit), 1 strip sekitar 62% lebar dan 73% tinggi; kolase 9:16 hampir setinggi kanvas (91-93%). Elemen hiasan dikecilkan 20% agar tidak menutupi strip, selotip lebih lebar, dan kantong jeans dipasang lebih rendah di depan strip.

## v42 - banyak tata letak berbeda untuk tiap jumlah foto
- **Sistem tata letak baru**: setiap jumlah foto 1 sampai 6 punya 5-6 susunan yang benar-benar berbeda (bukan satu tata letak diulang): perangko besar, oval renda, kertas bergaris + klip + polaroid, film tunggal, pemutar musik, dua perangko serong, besar + kecil, dua oval, film ganda, perangko bertumpuk (seperti Pinterest), satu besar + dua kecil, dua atas + oval bawah, polaroid kipas, kartu maroon empat tegak, kartu dua strip tiga foto, piramida, tangga, zigzag, grid 2x2/2x3, film 3x2, dan lainnya. Dikalikan 6 set warna (Merah, Biru, Pink, Jeans, Chrome Y2K, Mono Kamera): sekitar 390 template kolase + wallpaper, ditambah template strip.
- **Ukuran kotak mengikuti rasio foto kreasi**: kreasi 4:3 menghasilkan kotak 4:3, kreasi 3:4 kotak tegak, 16:9 kotak lebar; tinggi dan lebar disesuaikan, lalu seluruh kartu (termasuk tepi perangko dan polaroid) dipastikan muat di kanvas.
- **Hiasan yang bervariasi**: tiap tata letak punya pola penempatan elemen sendiri (tepi, bawah, samping, atas-bawah, sudut) dan urutan elemen yang diputar per tata letak dan set, selotip mengikuti posisi polaroid, kertas bergaris atau kartu berwarna dengan klip, tulisan tangan (photo time, say cheese, lovesick, dll), dan cap tanggal otomatis.
- **Filter set warna** di halaman pilih template (Semua, Merah, Biru, dst). Kolase kini selalu 9:16.
- Elemen tinggi (telepon, gitar, buket) dibatasi tingginya agar tidak raksasa.
- Dites (Chromium): render banyak tata letak pada rasio 3:4 dan 4:3, wallpaper dan kolase, regresi lama lulus.

## v43 - printing keluar dari mesin, template rapi, jam layar kunci, menu flash/timer
- **Animasi printing**: strip kini benar-benar meluncur keluar dari celah mesin (bergeser turun, ada jeda tersendat seperti kertas tercetak), bukan lagi terbuka dari atas.
- **Hiasan tidak menutupi foto**: tata letak otomatis menempatkan hiasan di ruang kosong (menghindari kotak foto, tulisan, dan jam); jika sempit, hiasan dikecilkan atau dilewati.
- **Jam dan tanggal ala layar kunci** di semua wallpaper bawaan, 5 gaya berbeda, warna teks menyesuaikan latar.
- **10 tema baru** (Matcha, Sakura, Sunset, Ocean, Coffee, Lavender, Strawberry, Galaxy, Retro Film, Citrus), kolase dan wallpaper, semua tata letak 1 sampai 6 foto.
- **Kamera**: flash di tepi kiri, timer di tepi kanan, ketuk membuka menu dropdown beranimasi (flash: Mati, Nyala, Otomatis; timer: Mati, 3, 5, 10 detik).
- **Upload foto galeri**: foto disimpan ke berkas sementara (bukan string besar lewat jembatan), otomatis dicoba ulang dengan ukuran lebih kecil jika memori kurang.
- **Bingkai bawaan**: hiasan semua tema kini dipotong di area foto sehingga tidak menutupi foto.
