package com.snapin.photobooth

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.util.Base64
import android.widget.Toast
import androidx.activity.result.PickVisualMediaRequest
import java.io.ByteArrayOutputStream
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.webkit.PermissionRequest
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.webkit.WebViewAssetLoader
import java.io.File

/**
 * Snapin Photobooth — Android shell.
 *
 * The whole app (UI, filters, frames, stickers, layout, video, assets)
 * is the original single-file web app served from app assets over a
 * secure https:// origin (required for getUserMedia). The one piece the
 * web platform could never do reliably — reading the phone's physical
 * tilt — is provided natively by [TiltBridge] and injected into the page
 * as window.SnapinNative.getTilt(), using the OS-level fused gravity
 * sensor (the same source the built-in camera app uses).
 */
class MainActivity : ComponentActivity() {

    private lateinit var webView: WebView
    private lateinit var tiltBridge: TiltBridge
    private var pendingRequest: PermissionRequest? = null

    // Pemilih file (upload foto dari galeri, upload bingkai/stiker) dari halaman web.
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private val fileChooserLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val cb = fileCallback
            fileCallback = null
            cb?.onReceiveValue(
                WebChromeClient.FileChooserParams.parseResult(result.resultCode, result.data)
            )
        }

    // Foto dari galeri: pemilih foto bawaan Android, lalu diperkecil & diluruskan (EXIF) di sini
    // supaya foto resolusi besar atau format HEIC tetap aman diproses halaman web.
    private val galleryLauncher =
        registerForActivityResult(ActivityResultContracts.PickMultipleVisualMedia(6)) { uris ->
            if (uris.isNullOrEmpty()) return@registerForActivityResult
            Toast.makeText(this, "Memproses " + uris.size + " foto...", Toast.LENGTH_SHORT).show()
            Thread {
                val list = ArrayList<String>()
                for (u in uris.take(6)) {
                    val d = decodeGalleryImage(u)
                    if (d != null) list.add(d)
                }
                runOnUiThread {
                    if (list.isEmpty()) {
                        Toast.makeText(this, "Foto tidak bisa dibuka (format tidak didukung)", Toast.LENGTH_LONG).show()
                    } else {
                        CameraSession.photos.clear()
                        CameraSession.photos.addAll(list)
                        webView.evaluateJavascript(
                            "window.__onNativeGallery&&window.__onNativeGallery(" + list.size + ");", null
                        )
                    }
                }
            }.start()
        }

    private fun decodeGalleryImage(uri: Uri, maxSide: Int = 1800): String? {
        return try {
            val cr = contentResolver
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
            var sample = 1
            while (maxOf(bounds.outWidth, bounds.outHeight) / (sample * 2) >= maxSide) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            var bmp = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return null
            val orientation = try {
                cr.openInputStream(uri)?.use {
                    ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
                } ?: ExifInterface.ORIENTATION_NORMAL
            } catch (e: Exception) {
                ExifInterface.ORIENTATION_NORMAL
            }
            val mx = Matrix()
            when (orientation) {
                ExifInterface.ORIENTATION_ROTATE_90 -> mx.postRotate(90f)
                ExifInterface.ORIENTATION_ROTATE_180 -> mx.postRotate(180f)
                ExifInterface.ORIENTATION_ROTATE_270 -> mx.postRotate(270f)
                ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> mx.postScale(-1f, 1f)
                ExifInterface.ORIENTATION_FLIP_VERTICAL -> mx.postScale(1f, -1f)
                ExifInterface.ORIENTATION_TRANSPOSE -> { mx.postRotate(90f); mx.postScale(-1f, 1f) }
                ExifInterface.ORIENTATION_TRANSVERSE -> { mx.postRotate(270f); mx.postScale(-1f, 1f) }
            }
            val longest = maxOf(bmp.width, bmp.height)
            if (longest > maxSide) {
                val k = maxSide.toFloat() / longest
                mx.postScale(k, k)
            }
            if (!mx.isIdentity) {
                val nb = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, mx, true)
                if (nb !== bmp) { bmp.recycle(); bmp = nb }
            }
            val out = ByteArrayOutputStream()
            bmp.compress(Bitmap.CompressFormat.JPEG, 90, out)
            bmp.recycle()
            "data:image/jpeg;base64," + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
        } catch (e: Throwable) {
            null
        }
    }

    // Hasil foto/video dari layar kamera native (CameraX) dikirim balik ke halaman web.
    private val cameraLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                if (CameraSession.mode == "video") {
                    val path = CameraSession.videoPath
                    if (path != null) {
                        val url = "https://appassets.androidplatform.net/videos/" + File(path).name
                        webView.evaluateJavascript(
                            "window.__onNativeVideo&&window.__onNativeVideo('" + url + "');", null
                        )
                    }
                } else if (CameraSession.photos.isNotEmpty()) {
                    val n = CameraSession.photos.size
                    val aw = if (CameraSession.landscape) CameraSession.ph else CameraSession.pw
                    val ah = if (CameraSession.landscape) CameraSession.pw else CameraSession.ph
                    val js = "window.__onNativePhotos&&window.__onNativePhotos(" +
                        n + "," + aw + "," + ah + ",'" + CameraSession.facing + "');"
                    webView.evaluateJavascript(js, null)
                }
            }
        }

    private fun openNativeCamera(mode: String, count: Int, facing: String, w: Int, h: Int) {
        CameraSession.reset(mode, count, facing, w, h)
        cameraLauncher.launch(Intent(this, CameraActivity::class.java))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        onBackPressedDispatcher.addCallback(this, backCallback)
        webView = WebView(this)
        setContentView(webView)
        WebView.setWebContentsDebuggingEnabled(true)

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true          // required for IndexedDB (My Assets)
            databaseEnabled = true
            mediaPlaybackRequiresUserGesture = false
            loadWithOverviewMode = true
            useWideViewPort = true
        }

        tiltBridge = TiltBridge(this)
        webView.addJavascriptInterface(tiltBridge, "SnapinNative")
        webView.addJavascriptInterface(
            NativeCameraBridge(
                { m, c, f, w, h -> runOnUiThread { openNativeCamera(m, c, f, w, h) } },
                {
                    runOnUiThread {
                        try {
                            galleryLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        } catch (e: Exception) {
                            // pemilih bawaan tidak bisa dibuka: pakai pemilih file halaman web sebagai cadangan
                            Toast.makeText(this, "Pemilih galeri gagal: " + (e.message ?: "tidak diketahui"), Toast.LENGTH_LONG).show()
                            webView.evaluateJavascript("window.__galleryFallback&&window.__galleryFallback();", null)
                        }
                    }
                }
            ),
            "SnapinCamera"
        )
        webView.addJavascriptInterface(FileBridge(this), "SnapinFiles")

        // Serve the web app over a secure origin so getUserMedia is allowed.
        val videoDir = File(cacheDir, "snapin_videos")
        videoDir.mkdirs()
        val assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .addPathHandler("/videos/", WebViewAssetLoader.InternalStoragePathHandler(this, videoDir))
            .build()

        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView,
                request: WebResourceRequest
            ): WebResourceResponse? = assetLoader.shouldInterceptRequest(request.url)
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest) {
                val needsCam = request.resources.contains(PermissionRequest.RESOURCE_VIDEO_CAPTURE)
                val needsMic = request.resources.contains(PermissionRequest.RESOURCE_AUDIO_CAPTURE)
                val ok = (!needsCam || hasPermission(Manifest.permission.CAMERA)) &&
                        (!needsMic || hasPermission(Manifest.permission.RECORD_AUDIO))
                if (ok) request.grant(request.resources)
                else {
                    pendingRequest = request
                    ensurePermissions()
                }
            }

            override fun onPermissionRequestCanceled(request: PermissionRequest) {
                if (pendingRequest === request) pendingRequest = null
            }

            override fun onShowFileChooser(
                view: WebView,
                filePathCallback: ValueCallback<Array<Uri>>,
                fileChooserParams: WebChromeClient.FileChooserParams
            ): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = filePathCallback
                return try {
                    fileChooserLauncher.launch(fileChooserParams.createIntent())
                    true
                } catch (e: Exception) {
                    fileCallback = null
                    false
                }
            }
        }

        webView.loadUrl("https://appassets.androidplatform.net/assets/www/index.html")
        ensurePermissions()
    }

    private fun hasPermission(p: String) =
        ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    private fun ensurePermissions() {
        val missing = mutableListOf<String>()
        if (!hasPermission(Manifest.permission.CAMERA)) missing += Manifest.permission.CAMERA
        if (!hasPermission(Manifest.permission.RECORD_AUDIO)) missing += Manifest.permission.RECORD_AUDIO
        if (missing.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, missing.toTypedArray(), REQ_PERMISSIONS)
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != REQ_PERMISSIONS) return
        pendingRequest?.let { req ->
            val ok = req.resources.all { res ->
                when (res) {
                    PermissionRequest.RESOURCE_VIDEO_CAPTURE -> hasPermission(Manifest.permission.CAMERA)
                    PermissionRequest.RESOURCE_AUDIO_CAPTURE -> hasPermission(Manifest.permission.RECORD_AUDIO)
                    else -> true
                }
            }
            if (ok) req.grant(req.resources) else req.deny()
            pendingRequest = null
        }
    }

    override fun onResume() {
        super.onResume()
        tiltBridge.start()
    }

    override fun onPause() {
        tiltBridge.stop()
        super.onPause()
    }

    // Tombol back HP: diserahkan dulu ke halaman web (kembali satu langkah di dalam aplikasi).
    // Aplikasi hanya tertutup kalau halaman web bilang sudah tidak ada langkah mundur.
    private val backCallback = object : androidx.activity.OnBackPressedCallback(true) {
        override fun handleOnBackPressed() {
            if (!::webView.isInitialized) { finish(); return }
            webView.evaluateJavascript("(window.__snapinBack ? window.__snapinBack() : false)") { r ->
                if (r != "true") finish()
            }
        }
    }

    override fun onDestroy() {
        webView.destroy()
        super.onDestroy()
    }

    private companion object {
        const val REQ_PERMISSIONS = 1001
    }
}
